# TP AWK - Suite (Niveaux 3-6)
## Variables, Fonctions, Avancé et Projet

---

<a name="niveau-3"></a>
## 🟠 NIVEAU 3 : VARIABLES ET OPÉRATEURS (3-4 heures)

### Objectifs
- Maîtriser les variables utilisateur
- Utiliser les opérateurs
- Comprendre l'incrémentation
- Gérer les variables globales

---

### Partie 3.1 : Variables Utilisateur

```bash
echo "=== VARIABLES UTILISATEUR ==="

# Variables AWK : pas de déclaration nécessaire

# 1. Variable simple
awk '{
    nom = $1
    age = $2
    print nom, "a", age, "ans"
}' data.txt

# 2. Accumulation
awk '{
    total = total + $NF
}
END {
    print "Total:", total
}' data.txt

# 3. Variables avec BEGIN
awk 'BEGIN {
    count = 0
    sum = 0
}
{
    count++
    sum += $2
}
END {
    print "Moyenne:", sum/count
}' data.txt

# 4. Variables passées en ligne de commande
awk -v seuil=50000 '$NF > seuil {print}' data.txt

# 5. Plusieurs variables externes
awk -v min=25 -v max=30 '
    $2 >= min && $2 <= max {print}
' data.txt

# 6. Variable depuis shell
VAR="Developer"
awk -v job="$VAR" '$4 == job {print}' users_extended.txt
```

---

### Partie 3.2 : Opérateurs Arithmétiques

```bash
echo "=== OPÉRATEURS ARITHMÉTIQUES ==="

# + - * / % (modulo) ^ (puissance)

cat << 'EOF' > calculs.txt
10 20
15 5
100 10
7 3
EOF

# 1. Addition
awk '{print $1, "+", $2, "=", $1 + $2}' calculs.txt

# 2. Soustraction
awk '{print $1, "-", $2, "=", $1 - $2}' calculs.txt

# 3. Multiplication
awk '{print $1, "*", $2, "=", $1 * $2}' calculs.txt

# 4. Division
awk '{print $1, "/", $2, "=", $1 / $2}' calculs.txt

# 5. Modulo
awk '{print $1, "%", $2, "=", $1 % $2}' calculs.txt

# 6. Puissance
awk '{print $1, "^", $2, "=", $1 ^ $2}' calculs.txt

# 7. Opérations combinées
awk '{
    result = ($1 + $2) * 2
    print "(" $1 " + " $2 ") * 2 =", result
}' calculs.txt

# 8. Calculs sur salaires
awk '{
    salaire = $NF
    augmentation = salaire * 0.10
    nouveau = salaire + augmentation
    printf "%s: %.2f € -> %.2f € (+10%%)\n", $1, salaire, nouveau
}' data.txt
```

---

### Partie 3.3 : Opérateurs d'Incrémentation

```bash
echo "=== OPÉRATEURS D'INCRÉMENTATION ==="

# ++ -- += -= *= /=

# 1. Incrémentation simple
awk '{count++} END {print "Total:", count}' data.txt

# 2. Pré/Post incrémentation
awk 'BEGIN {
    i = 5
    print "i =", i
    print "i++ =", i++  # Affiche 5, puis i devient 6
    print "i =", i
    print "++i =", ++i  # i devient 7, puis affiche 7
    print "i =", i
}'

# 3. Opérateurs d'assignation
awk '{
    total += $NF      # total = total + $NF
    count++
}
END {
    print "Total:", total
    print "Moyenne:", total/count
}' data.txt

# 4. Autres opérateurs d'assignation
awk 'BEGIN {
    x = 10
    x += 5   # x = 15
    x -= 3   # x = 12
    x *= 2   # x = 24
    x /= 4   # x = 6
    print "Résultat:", x
}'

# 5. Compteurs multiples
awk '{
    total_general++
    if ($3 == "F") femmes++
    if ($3 == "M") hommes++
}
END {
    print "Total:", total_general
    print "Femmes:", femmes
    print "Hommes:", hommes
}' users_extended.txt
```

---

### Partie 3.4 : Opérateurs de Chaînes

```bash
echo "=== OPÉRATEURS DE CHAÎNES ==="

# Concaténation : espace ou rien
# length() : longueur
# substr() : sous-chaîne
# index() : position
# toupper/tolower() : casse

# 1. Concaténation
awk '{
    nom_complet = $1 " " $2 " ans"
    print nom_complet
}' data.txt

# 2. Longueur
awk '{print $1, ":", length($1), "caractères"}' data.txt

# 3. Sous-chaîne
awk '{print substr($1, 1, 3)}' data.txt  # 3 premiers caractères

# 4. Position
awk '{print $1, "- Position de '\''a'\'':", index($1, "a")}' data.txt

# 5. Majuscules/minuscules
awk '{print toupper($1)}' data.txt
awk '{print tolower($1)}' data.txt

# 6. Formatage de noms
awk '{
    premiere_lettre = substr($1, 1, 1)
    reste = substr($1, 2)
    nom_formate = toupper(premiere_lettre) tolower(reste)
    print nom_formate
}' data.txt

# 7. Extraction domaine email
echo "alice@example.com" | awk -F'@' '{
    print "User:", $1
    print "Domain:", $2
}'

# 8. Masquage de données sensibles
awk '{
    masked = substr($1, 1, 1) "***"
    print masked, $2, $3
}' data.txt
```

---

### Partie 3.5 : Variables Spéciales Avancées

```bash
echo "=== VARIABLES SPÉCIALES AVANCÉES ==="

# ARGC : nombre d'arguments
# ARGV : tableau des arguments
# ENVIRON : variables d'environnement
# RSTART, RLENGTH : résultats de match()
# FNR : numéro de ligne dans fichier actuel
# PROCINFO : infos processus (GAWK)

# 1. ARGC et ARGV
awk 'BEGIN {
    print "Nombre d'\''arguments:", ARGC
    for (i = 0; i < ARGC; i++) {
        print "ARGV[" i "]:", ARGV[i]
    }
}' data.txt emails.txt

# 2. Variables d'environnement
awk 'BEGIN {
    print "USER:", ENVIRON["USER"]
    print "HOME:", ENVIRON["HOME"]
    print "PATH:", ENVIRON["PATH"]
}'

# 3. FNR vs NR (plusieurs fichiers)
awk '{
    print "NR=" NR, "FNR=" FNR, ":", $0
}' data.txt emails.txt

# 4. match() avec RSTART et RLENGTH
awk '{
    if (match($0, /[0-9]+/)) {
        print "Trouvé:", substr($0, RSTART, RLENGTH)
        print "Position:", RSTART
        print "Longueur:", RLENGTH
    }
}' data.txt

# 5. PROCINFO (GNU awk)
awk 'BEGIN {
    print "Version:", PROCINFO["version"]
    print "PID:", PROCINFO["pid"]
    print "UID:", PROCINFO["uid"]
}'
```

---

### 🎯 QUIZ NIVEAU 3

1. Comment passer une variable au script AWK ?
2. Que fait `total += $1` ?
3. Différence entre `i++` et `++i` ?
4. Comment concaténer deux chaînes ?
5. Que retourne `length("Hello")` ?

**Réponses :**
1. `awk -v var=valeur`
2. `total = total + $1`
3. `i++` renvoie puis incrémente, `++i` incrémente puis renvoie
4. `str1 str2` ou `str1 " " str2`
5. 5

---

<a name="niveau-4"></a>
## 🔴 NIVEAU 4 : FONCTIONS ET TABLEAUX (4-5 heures)

### Objectifs
- Maîtriser les tableaux associatifs
- Utiliser les fonctions intégrées
- Créer des fonctions personnalisées
- Manipuler les tableaux multidimensionnels

---

### Partie 4.1 : Tableaux Associatifs

```bash
echo "=== TABLEAUX ASSOCIATIFS ==="

# Tableaux AWK = dictionnaires (clé-valeur)

# 1. Tableau simple
awk 'BEGIN {
    ages["Alice"] = 25
    ages["Bob"] = 30
    ages["Charlie"] = 28
    
    print "Alice a", ages["Alice"], "ans"
    print "Bob a", ages["Bob"], "ans"
}'

# 2. Compter occurrences
awk '{count[$4]++}
END {
    for (job in count) {
        print job ":", count[job]
    }
}' users_extended.txt

# 3. Somme par catégorie
awk '{
    total[$4] += $NF
    count[$4]++
}
END {
    for (job in total) {
        avg = total[job] / count[job]
        printf "%s: %.2f€ (moyenne)\n", job, avg
    }
}' users_extended.txt

# 4. Test d'existence
awk '{ville[$5]++}
END {
    if ("Paris" in ville) {
        print "Paris:", ville["Paris"], "personnes"
    }
    if ("Tokyo" in ville) {
        print "Tokyo trouvé"
    } else {
        print "Tokyo non trouvé"
    }
}' users_extended.txt

# 5. Supprimer élément
awk 'BEGIN {
    data["a"] = 1
    data["b"] = 2
    data["c"] = 3
    
    delete data["b"]
    
    for (key in data) {
        print key ":", data[key]
    }
}'

# 6. Tableau comme liste
awk '{
    names[NR] = $1
}
END {
    print "Liste des noms:"
    for (i = 1; i <= NR; i++) {
        print i ":", names[i]
    }
}' data.txt
```

---

### Partie 4.2 : Fonctions Intégrées

```bash
echo "=== FONCTIONS INTÉGRÉES ==="

# MATHÉMATIQUES
awk 'BEGIN {
    print "int(3.7):", int(3.7)              # 3
    print "sqrt(16):", sqrt(16)              # 4
    print "exp(1):", exp(1)                  # e
    print "log(10):", log(10)                # ln(10)
    print "sin(0):", sin(0)                  # 0
    print "cos(0):", cos(0)                  # 1
    print "rand():", rand()                  # 0-1 aléatoire
    srand()
    print "int(rand()*100):", int(rand()*100)  # 0-99
}'

# CHAÎNES
awk 'BEGIN {
    str = "Hello World"
    print "length:", length(str)
    print "substr:", substr(str, 1, 5)
    print "index:", index(str, "World")
    print "tolower:", tolower(str)
    print "toupper:", toupper(str)
}'

# split() - Diviser chaîne en tableau
awk 'BEGIN {
    str = "one,two,three,four"
    n = split(str, arr, ",")
    print "Nombre d'\''éléments:", n
    for (i = 1; i <= n; i++) {
        print i ":", arr[i]
    }
}'

# gsub() et sub() - Remplacer
awk '{
    gsub(/Paris/, "PARIS")   # Remplacer tout
    print
}' users_extended.txt

awk '{
    sub(/e/, "E")   # Remplacer première occurrence
    print
}' data.txt

# match() - Chercher pattern
awk '{
    if (match($0, /[0-9]+/)) {
        print "Nombre trouvé:", substr($0, RSTART, RLENGTH)
    }
}' data.txt

# sprintf() - Formater sans afficher
awk '{
    formatted = sprintf("%-10s : %3d ans", $1, $2)
    print formatted
}' data.txt
```

---

### Partie 4.3 : Fonctions Personnalisées

```bash
echo "=== FONCTIONS PERSONNALISÉES ==="

# Syntaxe: function nom(params) { corps }

# 1. Fonction simple
cat << 'AWKSCRIPT' > functions.awk
function double(x) {
    return x * 2
}

{
    result = double($2)
    print $1, ":", $2, "->", result
}
AWKSCRIPT

awk -f functions.awk data.txt

# 2. Fonction avec plusieurs paramètres
cat << 'AWKSCRIPT' > calc.awk
function calculer_bonus(salaire, pourcentage) {
    return salaire * pourcentage / 100
}

{
    bonus = calculer_bonus($NF, 10)
    total = $NF + bonus
    printf "%s: %.2f€ + %.2f€ = %.2f€\n", $1, $NF, bonus, total
}
AWKSCRIPT

awk -f calc.awk data.txt

# 3. Fonction modifiant tableau
cat << 'AWKSCRIPT' > array_func.awk
function fill_stats(arr, val) {
    arr["min"] = val
    arr["max"] = val
    arr["sum"] = val
    arr["count"] = 1
}

function update_stats(arr, val) {
    if (val < arr["min"]) arr["min"] = val
    if (val > arr["max"]) arr["max"] = val
    arr["sum"] += val
    arr["count"]++
}

BEGIN {
    first = 1
}

{
    if (first) {
        fill_stats(stats, $2)
        first = 0
    } else {
        update_stats(stats, $2)
    }
}

END {
    print "Min:", stats["min"]
    print "Max:", stats["max"]
    print "Moyenne:", stats["sum"] / stats["count"]
}
AWKSCRIPT

awk -f array_func.awk data.txt

# 4. Fonction récursive (factorielle)
awk 'BEGIN {
    function factorial(n) {
        if (n <= 1)
            return 1
        else
            return n * factorial(n-1)
    }
    
    for (i = 1; i <= 5; i++) {
        print i "! =", factorial(i)
    }
}'

# 5. Fonction de validation
cat << 'AWKSCRIPT' > validate.awk
function is_email(str) {
    return match(str, /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)
}

{
    if (is_email($0)) {
        print "✓", $0
    } else {
        print "✗", $0
    }
}
AWKSCRIPT

awk -f validate.awk emails.txt
```

---

### Partie 4.4 : Tableaux Multidimensionnels

```bash
echo "=== TABLEAUX MULTIDIMENSIONNELS ==="

# AWK simule les tableaux 2D avec SUBSEP (défaut: \034)

# 1. Tableau 2D basique
awk 'BEGIN {
    # Créer une matrice 3x3
    for (i = 1; i <= 3; i++) {
        for (j = 1; j <= 3; j++) {
            matrix[i,j] = i * j
        }
    }
    
    # Afficher
    for (i = 1; i <= 3; i++) {
        for (j = 1; j <= 3; j++) {
            printf "%3d ", matrix[i,j]
        }
        print ""
    }
}'

# 2. Statistiques par ville et job
awk '{
    stats[$5, $4]++
    salaires[$5, $4] += $NF
}
END {
    print "Statistiques Ville-Job:"
    for (key in stats) {
        split(key, parts, SUBSEP)
        ville = parts[1]
        job = parts[2]
        count = stats[key]
        total = salaires[key]
        avg = total / count
        printf "  %s - %s: %d personnes, %.2f€ moy\n", 
               ville, job, count, avg
    }
}' users_extended.txt

# 3. Tableau 2D depuis fichier
cat << 'EOF' > matrix.txt
1 2 3
4 5 6
7 8 9
EOF

awk '{
    for (i = 1; i <= NF; i++) {
        matrix[NR, i] = $i
        max_col = (i > max_col) ? i : max_col
    }
    max_row = NR
}
END {
    print "Matrice", max_row "x" max_col ":"
    for (i = 1; i <= max_row; i++) {
        for (j = 1; j <= max_col; j++) {
            printf "%3d ", matrix[i, j]
        }
        print ""
    }
}' matrix.txt

# 4. Test existence clé composée
awk '{
    data[$5, $4] = $1
}
END {
    if ((("Paris", "Developer") in data)) {
        print "Paris-Developer existe:", data["Paris", "Developer"]
    }
}' users_extended.txt
```

---

### 🎯 QUIZ NIVEAU 4

1. Comment créer un tableau en AWK ?
2. Que fait `array[key]++` ?
3. Comment parcourir un tableau ?
4. Syntaxe pour créer une fonction ?
5. Comment simuler un tableau 2D ?

**Réponses :**
1. `array[key] = value`
2. Incrémente la valeur (0 si inexistante)
3. `for (key in array) { ... }`
4. `function nom(params) { corps }`
5. `array[i, j] = value` (avec SUBSEP)

---

<a name="niveau-5"></a>
## ⚫ NIVEAU 5 : AWK AVANCÉ (4-5 heures)

### Objectifs
- Maîtriser les entrées/sorties
- Utiliser les pipes et redirections
- Optimiser les performances
- Techniques avancées

---

### Partie 5.1 : Entrées/Sorties Avancées

```bash
echo "=== ENTRÉES/SORTIES AVANCÉES ==="

# 1. Lire plusieurs fichiers
awk '{
    print FILENAME ":", $0
}' data.txt emails.txt

# 2. Sortie vers fichier
awk '{
    print $0 > "output.txt"
}' data.txt

# 3. Append (>>)
awk '{
    print $1 >> "names.txt"
}' data.txt

# 4. Sortie conditionnelle vers différents fichiers
awk '{
    if ($3 == "F")
        print > "femmes.txt"
    else
        print > "hommes.txt"
}' users_extended.txt

# 5. Pipe vers commande externe
awk '{
    print $1, $6 | "sort -k2 -n"
}' data.txt

# 6. Lire depuis commande
awk 'BEGIN {
    while (("date" | getline date) > 0) {
        print "Date actuelle:", date
    }
    close("date")
}'

# 7. getline - lire ligne suivante
cat << 'EOF' > pairs.txt
Name: Alice
Age: 25
Name: Bob
Age: 30
EOF

awk '/Name:/ {
    name = $2
    getline
    age = $2
    print name, "a", age, "ans"
}' pairs.txt

# 8. Lire depuis fichier spécifique
awk 'BEGIN {
    while ((getline line < "data.txt") > 0) {
        print "Lu:", line
    }
    close("data.txt")
}'
```

---

### Partie 5.2 : Techniques d'Optimisation

```bash
echo "=== OPTIMISATION ==="

# 1. Éviter les regex inutiles
# ❌ Lent
awk '{if ($0 ~ /pattern/) print}' huge_file.txt

# ✅ Rapide
awk '/pattern/' huge_file.txt

# 2. Pré-compiler les regex (GAWK)
awk 'BEGIN {pattern = /Developer/}
     $0 ~ pattern {print}' users_extended.txt

# 3. Sortir tôt si possible
awk '{
    if (found) exit
    if ($1 == "Alice") {
        print $0
        found = 1
    }
}' users_extended.txt

# 4. Utiliser index() plutôt que regex pour recherche simple
# ❌ Plus lent
awk '{if ($0 ~ /Paris/) print}' users_extended.txt

# ✅ Plus rapide
awk '{if (index($0, "Paris")) print}' users_extended.txt

# 5. Éviter les modifications inutiles de champs
# ❌ Force reconstruction
awk '{$1=$1; print}' huge_file.txt

# ✅ Mieux
awk '{print}' huge_file.txt

# 6. Utiliser mawk pour vitesse pure (sans fonctions GNU)
# mawk est 2-3x plus rapide que gawk
time gawk '{sum+=$2} END{print sum}' huge_data.txt
time mawk '{sum+=$2} END{print sum}' huge_data.txt

# 7. Limiter utilisation de fonctions
# ❌ Appel répété
awk '{print length($0)}' huge_file.txt

# ✅ Stocker
awk '{len=length($0); print len}' huge_file.txt
```

---

### Partie 5.3 : Traitement Multi-Passes

```bash
echo "=== MULTI-PASSES ==="

# Technique: lire le fichier plusieurs fois

# 1. Calculer pourcentage du total
awk 'NR==FNR {
    total += $NF
    next
}
{
    pct = ($NF / total) * 100
    printf "%s: %.2f%%\n", $1, pct
}' data.txt data.txt

# Explication:
# - Premier passage (NR==FNR): calculer total
# - next: passer à ligne suivante sans exécuter reste
# - Deuxième passage: calculer pourcentages

# 2. Normaliser par rapport au maximum
awk 'NR==FNR {
    if ($2 > max) max = $2
    next
}
{
    normalized = $2 / max
    printf "%s: %.2f\n", $1, normalized
}' data.txt data.txt

# 3. Joindre deux fichiers
cat << 'EOF' > file1.txt
1 Alice
2 Bob
3 Charlie
EOF

cat << 'EOF' > file2.txt
1 Developer
2 Designer
3 Manager
EOF

awk 'NR==FNR {
    job[$1] = $2
    next
}
{
    print $1, $2, job[$1]
}' file2.txt file1.txt
```

---

### Partie 5.4 : Formats de Données Complexes

```bash
echo "=== FORMATS COMPLEXES ==="

# 1. JSON simple (lecture)
cat << 'EOF' > simple.json
{"name": "Alice", "age": 25, "city": "Paris"}
{"name": "Bob", "age": 30, "city": "Lyon"}
EOF

awk -F'[":,}]' '{
    for (i=1; i<=NF; i++) {
        gsub(/[{} ]/, "", $i)
        if ($i == "name") print $(i+1)
    }
}' simple.json

# 2. XML simple (extraction)
cat << 'EOF' > simple.xml
<users>
  <user>
    <name>Alice</name>
    <age>25</age>
  </user>
  <user>
    <name>Bob</name>
    <age>30</age>
  </user>
</users>
EOF

awk -F'[<>]' '/name/ {print $3}' simple.xml

# 3. CSV avec guillemets
cat << 'EOF' > complex.csv
"Name","Age","City"
"Alice","25","Paris"
"Bob, Jr","30","Lyon"
"Charlie ""Chuck""","28","Marseille"
EOF

# Parser CSV correct (simplifié)
awk -F'","' '{
    gsub(/"/, "", $1)
    gsub(/"/, "", $NF)
    print $1, $2, $3
}' complex.csv

# 4. Format fixe (colonnes à largeur fixe)
cat << 'EOF' > fixed.txt
Alice     25Developer  
Bob       30Designer   
Charlie   28Manager    
EOF

awk '{
    name = substr($0, 1, 10)
    age = substr($0, 11, 2)
    job = substr($0, 13)
    gsub(/ *$/, "", name)
    gsub(/ *$/, "", job)
    print name, age, job
}' fixed.txt
```

---

### Partie 5.5 : Rapports et Statistiques

```bash
echo "=== RAPPORTS ET STATISTIQUES ==="

# 1. Rapport détaillé avec totaux
cat << 'AWKSCRIPT' > report.awk
BEGIN {
    print "="*60
    print "RAPPORT DE VENTES"
    print "="*60
    printf "\n%-15s %-15s %10s\n", "Vendeur", "Produit", "Montant"
    print "-"*60
}

{
    vendeur = $3
    produit = $2
    montant = $4
    
    printf "%-15s %-15s %10.2f €\n", vendeur, produit, montant
    
    total_vendeur[vendeur] += montant
    total_produit[produit] += montant
    total_general += montant
}

END {
    print "="*60
    print "TOTAUX PAR VENDEUR:"
    for (v in total_vendeur) {
        printf "  %-15s : %10.2f €\n", v, total_vendeur[v]
    }
    
    print "\nTOTAUX PAR PRODUIT:"
    for (p in total_produit) {
        printf "  %-15s : %10.2f €\n", p, total_produit[p]
    }
    
    print "\n" "="*60
    printf "TOTAL GÉNÉRAL : %10.2f €\n", total_general
    print "="*60
}
AWKSCRIPT

awk -f report.awk sales_data.txt

# 2. Statistiques avancées
cat << 'AWKSCRIPT' > stats.awk
{
    values[NR] = $2
    sum += $2
    sum_sq += $2 * $2
}

END {
    n = NR
    mean = sum / n
    
    # Écart-type
    variance = (sum_sq / n) - (mean * mean)
    stddev = sqrt(variance)
    
    # Tri pour médiane
    for (i = 1; i <= n; i++) {
        for (j = i+1; j <= n; j++) {
            if (values[i] > values[j]) {
                tmp = values[i]
                values[i] = values[j]
                values[j] = tmp
            }
        }
    }
    
    # Médiane
    if (n % 2 == 0) {
        median = (values[n/2] + values[n/2+1]) / 2
    } else {
        median = values[int(n/2)+1]
    }
    
    print "Statistiques:"
    print "  N:", n
    print "  Min:", values[1]
    print "  Max:", values[n]
    print "  Moyenne:", mean
    print "  Médiane:", median
    print "  Écart-type:", stddev
}
AWKSCRIPT

awk -f stats.awk data.txt
```

---

### 🎯 QUIZ NIVEAU 5

1. Comment rediriger la sortie vers un fichier ?
2. Que fait `NR==FNR` ?
3. Comment exécuter une commande depuis AWK ?
4. Différence entre `>` et `>>` ?
5. Que fait `next` ?

**Réponses :**
1. `print > "fichier.txt"`
2. Vrai lors du premier fichier seulement
3. `"commande" | getline` ou `print | "commande"`
4. `>` écrase, `>>` ajoute
5. Passe à la ligne suivante immédiatement

---

<a name="niveau-6"></a>
## 🏆 NIVEAU 6 : CAS PRATIQUES RÉELS (4-5 heures)

### Partie 6.1 : Analyse de Logs

```bash
# Analyse de logs Apache/Nginx
cat << 'AWKSCRIPT' > log_analyzer.awk
BEGIN {
    print "=== ANALYSE DE LOGS ==="
}

# Parser ligne de log
{
    ip = $1
    date = $4
    method = $6
    url = $7
    code = $9
    size = $10
    
    # Compteurs
    ips[ip]++
    codes[code]++
    urls[url]++
    total_size += (size == "-" ? 0 : size)
    requests++
    
    if (code ~ /^4/) errors_4xx++
    if (code ~ /^5/) errors_5xx++
}

END {
    print "\n=== RÉSUMÉ ==="
    print "Total requêtes:", requests
    print "Erreurs 4xx:", errors_4xx
    print "Erreurs 5xx:", errors_5xx
    printf "Taille totale: %.2f MB\n", total_size/1024/1024
    
    print "\n=== TOP 10 IPs ==="
    PROCINFO["sorted_in"] = "@val_num_desc"
    count = 0
    for (ip in ips) {
        print ip ":", ips[ip]
        if (++count >= 10) break
    }
    
    print "\n=== TOP 10 URLs ==="
    count = 0
    for (url in urls) {
        print url ":", urls[url]
        if (++count >= 10) break
    }
    
    print "\n=== Codes HTTP ==="
    for (code in codes) {
        printf "%s: %d (%.1f%%)\n", code, codes[code], 
               (codes[code]/requests)*100
    }
}
AWKSCRIPT

awk -f log_analyzer.awk access.log
```

---

### Partie 6.2 : Traitement CSV Avancé

```bash
# Analyse de ventes CSV
cat << 'AWKSCRIPT' > csv_analysis.awk
BEGIN {
    FS = ","
    OFS = ","
}

NR == 1 {
    # Headers
    for (i = 1; i <= NF; i++) {
        header[i] = $i
    }
    next
}

{
    # Accumulation données
    for (i = 1; i <= NF; i++) {
        col_sum[i] += $i
        col_count[i]++
        
        if ($i > col_max[i] || col_max[i] == "") {
            col_max[i] = $i
        }
        if ($i < col_min[i] || col_min[i] == "") {
            col_min[i] = $i
        }
    }
    total_rows++
}

END {
    print "=== STATISTIQUES CSV ==="
    print "Lignes:", total_rows
    print "Colonnes:", NF
    print ""
    
    for (i = 1; i <= NF; i++) {
        if (header[i] ~ /[Pp]rice|[Aa]mount|[Ss]alary/) {
            printf "%s:\n", header[i]
            printf "  Min: %.2f\n", col_min[i]
            printf "  Max: %.2f\n", col_max[i]
            printf "  Moy: %.2f\n", col_sum[i]/col_count[i]
            print ""
        }
    }
}
AWKSCRIPT
```

---

### 🎯 PROJET FINAL

Créer un analyseur de données réseau complet qui :
1. Parse des logs réseau
2. Génère des statistiques
3. Détecte des anomalies
4. Produit un rapport HTML

Voir fichier de projet séparé.

---

**FÉLICITATIONS !** 🎉

Vous maîtrisez maintenant AWK de A à Z !

**Durée totale :** 15-20 heures  
**Niveau atteint :** Expert AWK 2026
