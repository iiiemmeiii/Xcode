# PROJET FINAL AWK + GUIDE DE RÉFÉRENCE

---

<a name="projet-final"></a>
## 🏆 PROJET FINAL : ANALYSEUR DE LOGS RÉSEAU

### Objectif
Créer un analyseur complet de logs réseau qui :
- Parse différents formats de logs
- Génère des statistiques avancées
- Détecte des anomalies
- Produit un rapport HTML interactif

---

### Projet : Network Log Analyzer

```bash
#!/bin/bash
# network_analyzer.sh - Projet final AWK

# Créer logs réseau fictifs
cat << 'EOF' > network.log
2026-02-16 10:15:23 192.168.1.100 -> 8.8.8.8:53 DNS QUERY google.com 89 OK
2026-02-16 10:15:24 192.168.1.100 -> 93.184.216.34:443 HTTPS GET /index.html 1523 OK
2026-02-16 10:15:25 192.168.1.101 -> 8.8.8.8:53 DNS QUERY facebook.com 92 OK
2026-02-16 10:15:26 192.168.1.101 -> 157.240.1.35:443 HTTPS GET /home 2341 OK
2026-02-16 10:15:27 192.168.1.102 -> 192.168.1.1:80 HTTP GET /admin 234 DENIED
2026-02-16 10:15:28 192.168.1.103 -> 10.0.0.50:22 SSH LOGIN admin 145 FAILED
2026-02-16 10:15:29 192.168.1.103 -> 10.0.0.50:22 SSH LOGIN admin 145 FAILED
2026-02-16 10:15:30 192.168.1.103 -> 10.0.0.50:22 SSH LOGIN admin 145 FAILED
2026-02-16 10:15:31 192.168.1.104 -> 8.8.8.8:53 DNS QUERY malware.badsite.com 78 OK
2026-02-16 10:15:32 192.168.1.104 -> 185.34.52.12:80 HTTP GET /payload 5678 OK
2026-02-16 10:15:33 192.168.1.100 -> 93.184.216.34:443 HTTPS GET /page2.html 2100 OK
2026-02-16 10:15:34 192.168.1.105 -> 192.168.1.200:445 SMB CONNECT share 567 OK
2026-02-16 10:15:35 192.168.1.106 -> 1.2.3.4:1234 UNKNOWN DATA transfer 9999 SUSPICIOUS
2026-02-16 10:15:36 192.168.1.107 -> 8.8.4.4:53 DNS QUERY example.com 82 OK
2026-02-16 10:15:37 192.168.1.100 -> 93.184.216.34:443 HTTPS POST /api/data 890 OK
EOF

# Script AWK principal
cat << 'AWKSCRIPT' > network_analyzer.awk
#!/usr/bin/awk -f
# Network Log Analyzer - Projet Final AWK 2026

BEGIN {
    print "╔════════════════════════════════════════════════╗"
    print "║   NETWORK LOG ANALYZER v1.0 - 2026            ║"
    print "║   Analyse en cours...                         ║"
    print "╚════════════════════════════════════════════════╝"
    print ""
    
    # Initialisation
    total_traffic = 0
    blocked_count = 0
    failed_auth = 0
    
    # Base de domaines suspects
    split("malware,badsite,evil,hack", blacklist, ",")
}

# Parse chaque ligne
{
    timestamp = $1 " " $2
    src_ip = $3
    arrow = $4
    dest = $5
    protocol = $6
    action = $7
    target = $8
    bytes = $9
    status = $10
    
    # Extraire port de destination
    split(dest, dest_parts, ":")
    dest_ip = dest_parts[1]
    dest_port = dest_parts[2]
    
    # Compteurs globaux
    total_requests++
    total_traffic += bytes
    
    # Par IP source
    ip_requests[src_ip]++
    ip_traffic[src_ip] += bytes
    
    # Par protocole
    protocol_count[protocol]++
    protocol_traffic[protocol] += bytes
    
    # Par port
    port_count[dest_port]++
    
    # Détection anomalies
    if (status == "DENIED" || status == "BLOCKED") {
        blocked_count++
        blocked_ips[src_ip]++
    }
    
    if (status == "FAILED" && protocol == "SSH") {
        failed_auth++
        failed_auth_ips[src_ip]++
    }
    
    if (status == "SUSPICIOUS") {
        suspicious_count++
        suspicious_ips[src_ip]++
        suspicious_log[suspicious_count] = $0
    }
    
    # Vérifier domaine suspect
    if (protocol == "DNS") {
        domain = target
        for (i in blacklist) {
            if (index(domain, blacklist[i])) {
                malicious_dns++
                malicious_domains[domain]++
                alert_ips[src_ip]++
            }
        }
    }
    
    # Détection scan de ports (même IP, plusieurs ports)
    if (src_ip in src_ports) {
        if (!(dest_port in src_ports[src_ip])) {
            src_ports[src_ip][dest_port] = 1
            port_scan_count[src_ip]++
        }
    } else {
        src_ports[src_ip][dest_port] = 1
        port_scan_count[src_ip] = 1
    }
    
    # Timeline
    hour = substr(timestamp, 12, 2)
    timeline[hour]++
}

END {
    # Générer rapport HTML
    html_report()
    
    # Afficher résumé console
    print_console_summary()
}

function html_report() {
    output = "report.html"
    
    print "<!DOCTYPE html>" > output
    print "<html><head>" > output
    print "<meta charset='UTF-8'>" > output
    print "<title>Network Analysis Report</title>" > output
    print "<style>" > output
    print "  body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }" > output
    print "  .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 8px; }" > output
    print "  h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }" > output
    print "  h2 { color: #34495e; margin-top: 30px; }" > output
    print "  .stat-box { display: inline-block; background: #ecf0f1; padding: 15px; margin: 10px; border-radius: 5px; min-width: 200px; }" > output
    print "  .stat-label { font-size: 12px; color: #7f8c8d; }" > output
    print "  .stat-value { font-size: 24px; font-weight: bold; color: #2c3e50; }" > output
    print "  .alert { background: #e74c3c; color: white; padding: 15px; border-radius: 5px; margin: 10px 0; }" > output
    print "  .warning { background: #f39c12; color: white; padding: 15px; border-radius: 5px; margin: 10px 0; }" > output
    print "  .info { background: #3498db; color: white; padding: 15px; border-radius: 5px; margin: 10px 0; }" > output
    print "  table { width: 100%; border-collapse: collapse; margin: 20px 0; }" > output
    print "  th { background: #34495e; color: white; padding: 12px; text-align: left; }" > output
    print "  td { padding: 10px; border-bottom: 1px solid #ddd; }" > output
    print "  tr:hover { background: #f8f9fa; }" > output
    print "</style>" > output
    print "</head><body>" > output
    print "<div class='container'>" > output
    
    # Titre
    print "<h1>📊 Network Traffic Analysis Report</h1>" > output
    print "<p><strong>Generated:</strong> " strftime("%Y-%m-%d %H:%M:%S") "</p>" > output
    
    # Statistiques générales
    print "<h2>📈 General Statistics</h2>" > output
    print "<div class='stat-box'>" > output
    print "  <div class='stat-label'>Total Requests</div>" > output
    print "  <div class='stat-value'>" total_requests "</div>" > output
    print "</div>" > output
    print "<div class='stat-box'>" > output
    print "  <div class='stat-label'>Total Traffic</div>" > output
    printf "  <div class='stat-value'>%.2f KB</div>\n", total_traffic/1024 > output
    print "</div>" > output
    print "<div class='stat-box'>" > output
    print "  <div class='stat-label'>Unique IPs</div>" > output
    print "  <div class='stat-value'>" length(ip_requests) "</div>" > output
    print "</div>" > output
    
    # Alertes
    if (suspicious_count > 0 || malicious_dns > 0 || failed_auth > 3) {
        print "<h2>⚠️ Security Alerts</h2>" > output
        
        if (suspicious_count > 0) {
            print "<div class='alert'>" > output
            print "  <strong>SUSPICIOUS ACTIVITY:</strong> " suspicious_count " suspicious connections detected" > output
            print "</div>" > output
        }
        
        if (malicious_dns > 0) {
            print "<div class='alert'>" > output
            print "  <strong>MALICIOUS DNS:</strong> " malicious_dns " queries to blacklisted domains" > output
            print "</div>" > output
        }
        
        if (failed_auth > 3) {
            print "<div class='warning'>" > output
            print "  <strong>AUTHENTICATION FAILURES:</strong> " failed_auth " failed login attempts" > output
            print "</div>" > output
        }
        
        # Port scan detection
        for (ip in port_scan_count) {
            if (port_scan_count[ip] > 3) {
                print "<div class='warning'>" > output
                print "  <strong>PORT SCAN:</strong> " ip " scanned " port_scan_count[ip] " different ports" > output
                print "</div>" > output
            }
        }
    }
    
    # Top IPs
    print "<h2>🔝 Top Source IPs</h2>" > output
    print "<table>" > output
    print "<tr><th>IP Address</th><th>Requests</th><th>Traffic (KB)</th><th>Status</th></tr>" > output
    
    # Tri par nombre de requêtes
    n = asorti(ip_requests, sorted_ips, "@val_num_desc")
    for (i = 1; i <= (n < 10 ? n : 10); i++) {
        ip = sorted_ips[i]
        status_class = ""
        status_text = "Normal"
        
        if (ip in alert_ips) {
            status_class = "style='background:#fee;'"
            status_text = "⚠️ Alert"
        } else if (ip in blocked_ips) {
            status_class = "style='background:#ffeaa7;'"
            status_text = "⚡ Blocked"
        }
        
        printf "<tr %s><td>%s</td><td>%d</td><td>%.2f</td><td>%s</td></tr>\n", 
               status_class, ip, ip_requests[ip], ip_traffic[ip]/1024, status_text > output
    }
    print "</table>" > output
    
    # Protocoles
    print "<h2>🌐 Protocol Distribution</h2>" > output
    print "<table>" > output
    print "<tr><th>Protocol</th><th>Count</th><th>Traffic (KB)</th><th>%</th></tr>" > output
    
    for (proto in protocol_count) {
        pct = (protocol_count[proto] / total_requests) * 100
        printf "<tr><td>%s</td><td>%d</td><td>%.2f</td><td>%.1f%%</td></tr>\n",
               proto, protocol_count[proto], protocol_traffic[proto]/1024, pct > output
    }
    print "</table>" > output
    
    # Fermeture HTML
    print "</div></body></html>" > output
    
    close(output)
}

function print_console_summary() {
    print ""
    print "╔════════════════════════════════════════════════╗"
    print "║            ANALYSIS COMPLETE                  ║"
    print "╚════════════════════════════════════════════════╝"
    print ""
    print "📊 SUMMARY:"
    print "  Total Requests:", total_requests
    printf "  Total Traffic: %.2f KB\n", total_traffic/1024
    print "  Unique IPs:", length(ip_requests)
    print ""
    
    if (suspicious_count > 0 || malicious_dns > 0 || failed_auth > 0) {
        print "⚠️  SECURITY ALERTS:"
        if (suspicious_count > 0)
            print "  • Suspicious connections:", suspicious_count
        if (malicious_dns > 0)
            print "  • Malicious DNS queries:", malicious_dns
        if (failed_auth > 0)
            print "  • Failed auth attempts:", failed_auth
        print ""
    }
    
    print "📄 Detailed report generated: report.html"
    print "   Open with: firefox report.html"
    print ""
}
AWKSCRIPT

chmod +x network_analyzer.awk

# Exécuter l'analyse
echo "🚀 Lancement de l'analyse..."
awk -f network_analyzer.awk network.log

echo ""
echo "✅ Projet terminé !"
echo "📊 Consultez report.html pour le rapport complet"
```

---

## 📖 GUIDE DE RÉFÉRENCE RAPIDE AWK

### Syntaxe de Base

```bash
# Structure
awk 'pattern { action }' fichier

# Avec BEGIN et END
awk 'BEGIN {...} pattern {action} END {...}' fichier

# Depuis script
awk -f script.awk fichier

# Variables externes
awk -v var=value 'script' fichier
```

---

### Variables Intégrées

```
$0          Ligne entière
$1, $2...   Colonnes/champs
NR          Numéro de ligne (global)
NF          Nombre de champs
FNR         Numéro de ligne (par fichier)
FS          Séparateur de champs (input)
OFS         Séparateur de champs (output)
RS          Séparateur d'enregistrements (input)
ORS         Séparateur d'enregistrements (output)
FILENAME    Nom du fichier
ARGC        Nombre d'arguments
ARGV        Tableau des arguments
ENVIRON     Variables d'environnement
```

---

### Opérateurs

```bash
# Arithmétiques
+  -  *  /  %  ^  ++  --  +=  -=  *=  /=  %=  ^=

# Comparaison
==  !=  <  >  <=  >=

# Logiques
&&  ||  !

# Regex
~   (correspond)
!~  (ne correspond pas)

# Ternaire
condition ? si_vrai : si_faux

# Chaînes
" "  (concaténation - espace ou rien)
```

---

### Patterns Courants

```bash
/regex/                 # Ligne contient regex
$1 == "value"          # Colonne 1 égale à value
$2 > 10                # Colonne 2 > 10
$1 ~ /^A/              # Colonne 1 commence par A
NR > 1                 # Ignorer première ligne
NR == 5, NR == 10      # Lignes 5 à 10
/start/, /end/         # Entre start et end
!pattern               # Négation
pattern1 && pattern2   # ET
pattern1 || pattern2   # OU
```

---

### Fonctions Intégrées

#### Mathématiques
```bash
int(x)       # Partie entière
sqrt(x)      # Racine carrée
exp(x)       # Exponentielle
log(x)       # Logarithme naturel
sin(x)       # Sinus
cos(x)       # Cosinus
atan2(y,x)   # Arctangente
rand()       # Aléatoire 0-1
srand([x])   # Initialiser rand
```

#### Chaînes
```bash
length(s)              # Longueur
substr(s, i [,n])      # Sous-chaîne
index(s, t)            # Position de t dans s
split(s, a [,fs])      # Diviser en tableau
sub(r, s [,t])         # Remplacer 1ère occurrence
gsub(r, s [,t])        # Remplacer toutes
match(s, r)            # Chercher regex
tolower(s)             # Minuscules
toupper(s)             # Majuscules
sprintf(fmt, ...)      # Formater
```

#### Entrées/Sorties
```bash
print                  # Afficher
printf(fmt, ...)       # Afficher formaté
getline                # Lire ligne suivante
close(fichier)         # Fermer fichier
system(cmd)            # Exécuter commande
```

---

### Structures de Contrôle

```bash
# If
if (condition) {
    action
} else if (condition2) {
    action2
} else {
    action3
}

# For
for (i = 1; i <= 10; i++) {
    action
}

# For-in (tableaux)
for (key in array) {
    action
}

# While
while (condition) {
    action
}

# Do-while
do {
    action
} while (condition)

# Break, continue, next, exit
break        # Sortir de boucle
continue     # Iteration suivante
next         # Ligne suivante
exit         # Terminer script
```

---

### Tableaux

```bash
# Déclaration implicite
array[key] = value

# Test existence
if (key in array) { ... }

# Parcours
for (key in array) {
    print key, array[key]
}

# Suppression
delete array[key]
delete array  # Tout supprimer

# Taille (GAWK)
length(array)

# Tri (GAWK)
PROCINFO["sorted_in"] = "@val_num_desc"
for (key in array) { ... }

# Tableau 2D
array[i, j] = value
```

---

### Printf Formatage

```
%s    Chaîne
%d    Entier décimal
%f    Flottant
%e    Scientifique
%x    Hexadécimal
%c    Caractère

Modificateurs:
%-10s   Gauche, largeur 10
%10s    Droite, largeur 10
%.2f    2 décimales
%10.2f  Largeur 10, 2 décimales
```

---

### Exemples One-Liners Utiles

```bash
# Afficher colonne 2
awk '{print $2}' fichier

# Somme colonne 1
awk '{sum+=$1} END {print sum}' fichier

# Moyenne
awk '{sum+=$1; n++} END {print sum/n}' fichier

# Compter lignes
awk 'END {print NR}' fichier

# Lignes > 80 caractères
awk 'length > 80' fichier

# Colonnes en ordre inverse
awk '{for(i=NF;i>0;i--) printf "%s ", $i; print ""}' fichier

# Numéroter lignes
awk '{print NR, $0}' fichier

# Supprimer lignes vides
awk 'NF' fichier

# Supprimer doublons (garder première occurrence)
awk '!seen[$0]++' fichier

# CSV vers TSV
awk -F',' '{print $1 "\t" $2 "\t" $3}' fichier.csv

# Joindre lignes avec délimiteur
awk '{printf "%s%s", sep, $0; sep=","} END {print ""}' fichier

# Top 10 mots fréquents
awk '{for(i=1;i<=NF;i++) count[$i]++} 
     END {for(w in count) print count[w], w}' fichier | 
     sort -rn | head -10

# Statistiques rapides
awk '{sum+=$1; sumsq+=$1^2; n++} 
     END {print "n:", n, "mean:", sum/n, 
          "std:", sqrt(sumsq/n - (sum/n)^2)}' fichier
```

---

### Astuces et Bonnes Pratiques

1. **Performance :**
   - Préférer `/pattern/` à `$0 ~ /pattern/`
   - Utiliser `next` pour éviter traitement inutile
   - mawk est plus rapide, gawk plus riche en fonctionnalités

2. **Debugging :**
   - Ajouter `print` temporaires
   - Utiliser `-v` pour variables de debug
   - Tester avec petits fichiers d'abord

3. **Lisibilité :**
   - Commenter les scripts complexes
   - Utiliser des noms de variables explicites
   - Indenter correctement

4. **Sécurité :**
   - Valider les entrées utilisateur
   - Attention aux injections dans `system()`
   - Ne pas exécuter de code non fiable

---

## 🎓 CHECKLIST DE MAÎTRISE

```
NIVEAU 0 - INTRODUCTION
□ Installer et vérifier AWK
□ Comprendre la structure de base
□ Premier script AWK fonctionnel

NIVEAU 1 - BASES
□ Manipuler colonnes et champs
□ Utiliser variables intégrées (NR, NF, etc.)
□ Maîtriser séparateurs (FS, OFS)
□ Formater sortie avec printf

NIVEAU 2 - PATTERNS
□ Utiliser patterns de sélection
□ Maîtriser expressions régulières
□ Combiner conditions
□ Utiliser plages de patterns

NIVEAU 3 - VARIABLES
□ Créer et utiliser variables
□ Maîtriser opérateurs arithmétiques
□ Utiliser incrémentation
□ Manipuler chaînes

NIVEAU 4 - FONCTIONS
□ Créer et utiliser tableaux
□ Maîtriser fonctions intégrées
□ Écrire fonctions personnalisées
□ Gérer tableaux multidimensionnels

NIVEAU 5 - AVANCÉ
□ Gérer E/S avancées
□ Optimiser performances
□ Traitement multi-passes
□ Parser formats complexes

NIVEAU 6 - PRATIQUE
□ Analyser logs réels
□ Traiter données CSV/JSON
□ Générer rapports
□ Automatiser tâches

PROJET FINAL
□ Analyseur de logs réseau fonctionnel
□ Génération rapport HTML
□ Détection d'anomalies
□ Documentation complète
```

---

## 📚 RESSOURCES COMPLÉMENTAIRES

### Documentation
- `man awk` - Manuel système
- `info gawk` - Documentation GNU Awk
- https://www.gnu.org/software/gawk/manual/

### Livres Recommandés
- "The AWK Programming Language" - Aho, Kernighan, Weinberger
- "Effective awk Programming" - Arnold Robbins
- "sed & awk" - Dale Dougherty, Arnold Robbins

### Outils Complémentaires
- sed : Édition de flux
- grep : Recherche de motifs
- cut/paste : Manipulation de colonnes
- join : Jointure de fichiers

---

## 🎉 FÉLICITATIONS !

**Vous avez terminé le TP AWK complet !**

Vous maîtrisez maintenant :
✅ La syntaxe AWK de base à avancée
✅ Les patterns et expressions régulières
✅ Les variables et tableaux
✅ Les fonctions intégrées et personnalisées
✅ L'optimisation et les bonnes pratiques
✅ Les cas pratiques réels

**Niveau atteint :** Expert AWK 2026 🏆

**Prochaines étapes :**
1. Pratiquer sur vos propres données
2. Automatiser vos tâches quotidiennes
3. Combiner AWK avec sed, grep, bash
4. Contribuer à la communauté AWK

**Bon scripting avec AWK !** 🚀
