# TP COMPLET : MAÎTRISE DE AWK
## De Zéro à Expert - Édition 2026
### Traitement de Texte et Analyse de Données Puissant

**Durée estimée :** 15-20 heures  
**Niveau :** Débutant à Expert  
**Version AWK :** GNU Awk 5.3+ (2026)  
**Système :** Linux/Unix/macOS/WSL

---

## 📋 TABLE DES MATIÈRES

1. [Niveau 0 - Introduction et Installation](#niveau-0)
2. [Niveau 1 - Bases de AWK](#niveau-1)
3. [Niveau 2 - Patterns et Actions](#niveau-2)
4. [Niveau 3 - Variables et Opérateurs](#niveau-3)
5. [Niveau 4 - Fonctions et Tableaux](#niveau-4)
6. [Niveau 5 - AWK Avancé](#niveau-5)
7. [Niveau 6 - Cas Pratiques Réels](#niveau-6)
8. [Projet Final](#projet-final)

---

<a name="niveau-0"></a>
## 🔵 NIVEAU 0 : INTRODUCTION (1-2 heures)

### Objectifs
- Comprendre ce qu'est AWK
- Installer et vérifier AWK
- Premiers pas avec AWK
- Comprendre la philosophie Unix

---

### Partie 0.1 : Qu'est-ce que AWK ?

```
=== AWK : Aho, Weinberger, Kernighan ===

AWK est un langage de programmation conçu pour le traitement de texte
et l'extraction de données.

POURQUOI AWK ?
- Traitement de fichiers texte ligne par ligne
- Extraction de colonnes spécifiques
- Filtrage de données
- Calculs et statistiques
- Transformation de formats
- Génération de rapports

QUAND UTILISER AWK ?
✓ Traiter des logs
✓ Analyser des CSV/TSV
✓ Extraire des colonnes de fichiers
✓ Calculer des statistiques
✓ Reformater des données
✓ Filtrer et transformer du texte

ALTERNATIVES :
- sed : Édition de flux (plus limité)
- grep : Recherche de motifs (pas de traitement)
- Python/Perl : Plus puissants mais plus verbeux
- cut/paste : Extraction simple de colonnes

AWK = Sweet spot entre simplicité et puissance !

VERSIONS AWK EN 2026:
- gawk (GNU AWK) 5.3+ : Version recommandée
- mawk : Plus rapide mais moins de fonctionnalités
- nawk : Version originale améliorée
- BWK awk : Version de Brian Kernighan
```

---

### Partie 0.2 : Installation et Vérification

```bash
#!/bin/bash
# install_check_awk.sh - Vérifier et installer AWK

echo "=== VÉRIFICATION AWK ==="

# 1. Vérifier si AWK est installé
if command -v awk &> /dev/null; then
    echo "✓ AWK est installé"
    
    # Afficher la version
    awk --version
    
    # Identifier le type d'AWK
    if awk --version 2>&1 | grep -q "GNU"; then
        echo "Type: GNU Awk (gawk) - RECOMMANDÉ"
    elif awk --version 2>&1 | grep -q "mawk"; then
        echo "Type: mawk"
    else
        echo "Type: awk standard"
    fi
else
    echo "✗ AWK n'est pas installé"
fi

echo ""
echo "=== INSTALLATION (si nécessaire) ==="

# Ubuntu/Debian
echo "[1] Ubuntu/Debian:"
echo "    sudo apt update && sudo apt install gawk -y"

# Fedora/RHEL
echo "[2] Fedora/RHEL:"
echo "    sudo dnf install gawk -y"

# macOS
echo "[3] macOS:"
echo "    brew install gawk"
echo "    # macOS inclut déjà awk BSD par défaut"

# Arch Linux
echo "[4] Arch Linux:"
echo "    sudo pacman -S gawk"

echo ""
echo "=== TEST RAPIDE ==="

# Test simple
echo "Test simple AWK:"
echo "Alice 25" | awk '{print $1, "a", $2, "ans"}'

# Vérifier les fonctionnalités avancées (gawk)
echo ""
echo "Test fonctionnalités avancées:"
awk 'BEGIN { 
    if (PROCINFO["version"] != "") {
        print "✓ GAWK avec fonctionnalités avancées"
        print "  Version:", PROCINFO["version"]
    } else {
        print "⚠ AWK standard (limité)"
    }
}'

echo ""
echo "=== CONFIGURATION ==="
echo "Créer alias dans ~/.bashrc ou ~/.zshrc:"
echo "alias awk='gawk'  # Forcer GNU Awk si plusieurs versions"
```

**Exécuter :**
```bash
chmod +x install_check_awk.sh
./install_check_awk.sh
```

---

### Partie 0.3 : Premier Programme AWK

```bash
# Structure de base d'AWK
# awk 'pattern { action }' fichier

# Exemple 1: Afficher tout le fichier
echo -e "ligne1\nligne2\nligne3" | awk '{print}'

# Exemple 2: Afficher un message pour chaque ligne
echo -e "ligne1\nligne2" | awk '{print "Traitement:", $0}'

# Exemple 3: Compter les lignes
echo -e "ligne1\nligne2\nligne3" | awk 'END {print NR, "lignes"}'

# Exemple 4: Programme AWK depuis un fichier
cat << 'EOF' > premier.awk
# Mon premier script AWK
BEGIN { 
    print "=== Début du traitement ===" 
}

{ 
    print "Ligne", NR ":", $0 
}

END { 
    print "=== Fin : " NR " lignes traitées ===" 
}
EOF

echo -e "Alice\nBob\nCharlie" | awk -f premier.awk
```

---

### Partie 0.4 : Syntaxe de Base

```bash
# STRUCTURE GÉNÉRALE
# awk 'BEGIN {...} pattern {action} END {...}' fichier

# BEGIN: Exécuté AVANT la première ligne
# pattern {action}: Exécuté pour chaque ligne correspondante
# END: Exécuté APRÈS la dernière ligne

# Créer un fichier de test
cat << 'EOF' > users.txt
Alice 25 Developer
Bob 30 Designer
Charlie 28 Manager
Diana 22 Developer
Eve 35 Designer
EOF

echo "=== Exemples de base ==="

# 1. Afficher tout
awk '{print}' users.txt

# 2. Afficher la première colonne
awk '{print $1}' users.txt

# 3. Afficher première et troisième colonnes
awk '{print $1, $3}' users.txt

# 4. Afficher avec formatage
awk '{print $1 " est " $3}' users.txt

# 5. Avec BEGIN et END
awk 'BEGIN {print "Liste des utilisateurs:"}
     {print "- " $1}
     END {print "Total:", NR}' users.txt
```

---

### 🎯 QUIZ NIVEAU 0

1. Que signifie AWK ?
2. Quelle est la version recommandée d'AWK en 2026 ?
3. Que signifie `$0` dans AWK ?
4. Que fait le bloc `BEGIN` ?
5. Comment afficher uniquement la deuxième colonne ?

**Réponses :**
1. Aho, Weinberger, Kernighan (créateurs)
2. GNU Awk (gawk) 5.3+
3. La ligne entière
4. S'exécute avant le traitement des lignes
5. `awk '{print $2}' fichier`

---

<a name="niveau-1"></a>
## 🟢 NIVEAU 1 : BASES DE AWK (2-3 heures)

### Objectifs
- Maîtriser les colonnes et champs
- Comprendre les variables intégrées
- Utiliser les séparateurs de champs
- Formater la sortie

---

### Partie 1.1 : Colonnes et Champs

```bash
# Créer fichier de données
cat << 'EOF' > data.txt
Alice 25 F Paris 50000
Bob 30 M Lyon 60000
Charlie 28 M Paris 55000
Diana 22 F Marseille 45000
Eve 35 F Lyon 70000
Frank 29 M Paris 52000
EOF

echo "=== COLONNES ET CHAMPS ==="

# $0 : Ligne entière
# $1, $2, $3... : Colonnes (champs)
# $NF : Dernière colonne
# $(NF-1) : Avant-dernière colonne

# 1. Première colonne (nom)
awk '{print $1}' data.txt

# 2. Nom et âge
awk '{print $1, $2}' data.txt

# 3. Nom et dernière colonne (salaire)
awk '{print $1, $NF}' data.txt

# 4. Toutes les colonnes sauf la première
awk '{$1=""; print}' data.txt

# 5. Réorganiser les colonnes
awk '{print $3, $1, $2}' data.txt

# 6. Concaténation
awk '{print $1 "-" $2}' data.txt

# 7. Avec formatage
awk '{print $1 " (" $2 " ans)"}' data.txt
```

---

### Partie 1.2 : Variables Intégrées Essentielles

```bash
echo "=== VARIABLES INTÉGRÉES ==="

# NR : Number of Record (numéro de ligne)
# NF : Number of Fields (nombre de colonnes)
# FS : Field Separator (séparateur de champs)
# OFS : Output Field Separator (séparateur de sortie)
# RS : Record Separator (séparateur d'enregistrements)
# ORS : Output Record Separator
# FILENAME : Nom du fichier

# 1. NR - Numéro de ligne
awk '{print NR, $0}' data.txt

# 2. NF - Nombre de colonnes
awk '{print "Ligne", NR, "a", NF, "colonnes"}' data.txt

# 3. Dernière colonne avec NF
awk '{print $1, "gagne", $NF}' data.txt

# 4. Afficher ligne et nombre de champs
awk '{print NR ":", NF "champs ->", $0}' data.txt

# 5. FILENAME
awk '{print FILENAME, NR, $1}' data.txt

# Script complet utilisant plusieurs variables
cat << 'AWKSCRIPT' > show_vars.awk
BEGIN {
    print "=== Analyse du fichier ==="
    print ""
}

{
    print "Ligne", NR ":", $0
    print "  Nombre de champs:", NF
    print "  Premier champ:", $1
    print "  Dernier champ:", $NF
    print ""
}

END {
    print "Total lignes:", NR
    print "Fichier:", FILENAME
}
AWKSCRIPT

awk -f show_vars.awk data.txt
```

---

### Partie 1.3 : Séparateurs de Champs

```bash
echo "=== SÉPARATEURS DE CHAMPS ==="

# FS (Field Separator) : Par défaut espace/tab
# Peut être changé avec -F ou dans BEGIN

# 1. Données CSV
cat << 'EOF' > employees.csv
Name,Age,Department,Salary
Alice,25,IT,50000
Bob,30,HR,60000
Charlie,28,IT,55000
EOF

# Utiliser -F pour définir le séparateur
awk -F',' '{print $1, $4}' employees.csv

# Ou dans BEGIN
awk 'BEGIN {FS=","} {print $1, $4}' employees.csv

# 2. Données avec plusieurs espaces
cat << 'EOF' > spaced.txt
Alice      25    Developer
Bob        30    Designer
Charlie    28    Manager
EOF

# AWK gère automatiquement les espaces multiples
awk '{print $1, $3}' spaced.txt

# 3. Séparateur personnalisé (:|;)
echo "Alice:25:Developer" | awk -F':' '{print $1, $3}'

# 4. Séparateur régulier (regex)
echo "Alice  25   Developer" | awk -F'[ ]+' '{print $1, $3}'

# 5. Changer le séparateur de sortie (OFS)
awk 'BEGIN {OFS="|"} {print $1, $2, $3}' data.txt

# 6. OFS avec modification de champ
awk 'BEGIN {OFS=","} {$2=$2; print}' data.txt
# Note: $2=$2 force la reconstruction avec OFS
```

---

### Partie 1.4 : Formatage de Sortie

```bash
echo "=== FORMATAGE DE SORTIE ==="

# printf : Format C-style
# print : Format simple

# 1. printf basique
awk '{printf "%s a %d ans\n", $1, $2}' data.txt

# 2. Alignement de colonnes
awk '{printf "%-10s %3d %s\n", $1, $2, $3}' data.txt

# 3. Nombres avec décimales
cat << 'EOF' > numbers.txt
Alice 1234.5678
Bob 567.89
Charlie 12.3456
EOF

awk '{printf "%-10s : %10.2f\n", $1, $2}' numbers.txt

# 4. Formatage monétaire
awk '{printf "%-10s : %10.2f €\n", $1, $NF}' data.txt

# 5. Pourcentages
awk '{printf "%-10s : %3d%%\n", $1, $2}' data.txt

# 6. Largeur dynamique
awk '{printf "%*s\n", 20, $1}' data.txt

# Script de formatage de tableau
cat << 'AWKSCRIPT' > format_table.awk
BEGIN {
    print "+------------+-----+------------+--------+"
    printf "| %-10s | %3s | %-10s | %6s |\n", "Nom", "Age", "Ville", "Salaire"
    print "+------------+-----+------------+--------+"
}

{
    printf "| %-10s | %3d | %-10s | %6d |\n", $1, $2, $4, $5
}

END {
    print "+------------+-----+------------+--------+"
}
AWKSCRIPT

awk -f format_table.awk data.txt
```

---

### Partie 1.5 : Exercices Pratiques Niveau 1

```bash
#!/bin/bash
# exercices_niveau1.sh

echo "=== EXERCICES NIVEAU 1 ==="

# Créer fichier de données
cat << 'EOF' > logs.txt
2026-02-15 10:30:15 INFO User login: alice
2026-02-15 10:31:22 ERROR Connection failed
2026-02-15 10:32:45 INFO User login: bob
2026-02-15 10:35:10 WARNING Low memory
2026-02-15 10:40:33 ERROR Database timeout
2026-02-15 10:42:18 INFO User logout: alice
EOF

echo "Fichier de test créé: logs.txt"
echo ""

# EXERCICE 1: Afficher uniquement les timestamps (colonnes 1 et 2)
echo "EXERCICE 1: Timestamps"
echo "Commande: awk '{print \$1, \$2}' logs.txt"
awk '{print $1, $2}' logs.txt
echo ""

# EXERCICE 2: Afficher le type de log (colonne 3)
echo "EXERCICE 2: Types de log"
echo "Commande: awk '{print \$3}' logs.txt"
awk '{print $3}' logs.txt
echo ""

# EXERCICE 3: Afficher ligne avec numéro
echo "EXERCICE 3: Lignes numérotées"
echo "Commande: awk '{print NR\":\", \$0}' logs.txt"
awk '{print NR":", $0}' logs.txt
echo ""

# EXERCICE 4: Compter les lignes
echo "EXERCICE 4: Compter les lignes"
echo "Commande: awk 'END {print NR}' logs.txt"
awk 'END {print NR}' logs.txt
echo ""

# EXERCICE 5: Formatage personnalisé
echo "EXERCICE 5: Format personnalisé"
echo "Commande: awk '{printf \"[%s %s] %s\n\", \$1, \$2, \$3}' logs.txt"
awk '{printf "[%s %s] %s\n", $1, $2, $3}' logs.txt
echo ""

# Créer fichier CSV pour exercices supplémentaires
cat << 'EOF' > sales.csv
Product,Quantity,Price
Laptop,5,999.99
Mouse,50,19.99
Keyboard,30,49.99
Monitor,10,299.99
Headset,25,79.99
EOF

echo "Fichier CSV créé: sales.csv"
echo ""

# EXERCICE 6: Extraire produit et prix
echo "EXERCICE 6: Produit et prix (CSV)"
echo "Commande: awk -F',' '{print \$1, \$3}' sales.csv"
awk -F',' '{print $1, $3}' sales.csv
echo ""

# EXERCICE 7: Calculer valeur totale par ligne
echo "EXERCICE 7: Valeur totale (Quantité × Prix)"
echo "Commande: awk -F',' 'NR>1 {total=\$2*\$3; printf \"%s: %.2f\n\", \$1, total}' sales.csv"
awk -F',' 'NR>1 {total=$2*$3; printf "%s: %.2f€\n", $1, total}' sales.csv
```

---

### 🎯 QUIZ NIVEAU 1

1. Que représente `$NF` ?
2. Comment changer le séparateur de champs en virgule ?
3. Quelle est la différence entre `print` et `printf` ?
4. Comment afficher uniquement les lignes paires ?
5. Que fait `BEGIN {OFS=","}` ?

**Réponses :**
1. La dernière colonne
2. `awk -F','` ou `BEGIN {FS=","}`
3. `print` ajoute automatiquement un saut de ligne, `printf` nécessite `\n`
4. `awk 'NR%2==0 {print}' fichier`
5. Définit le séparateur de sortie comme virgule

---

<a name="niveau-2"></a>
## 🟡 NIVEAU 2 : PATTERNS ET ACTIONS (3-4 heures)

### Objectifs
- Maîtriser les patterns de sélection
- Utiliser les expressions régulières
- Comprendre les conditions
- Combiner plusieurs patterns

---

### Partie 2.1 : Patterns de Base

```bash
echo "=== PATTERNS DE BASE ==="

# Un pattern détermine QUAND une action est exécutée
# pattern { action }

# Créer fichier de test
cat << 'EOF' > users_extended.txt
Alice 25 F Developer Paris 50000
Bob 30 M Designer Lyon 60000
Charlie 28 M Manager Paris 55000
Diana 22 F Developer Marseille 45000
Eve 35 F Designer Lyon 70000
Frank 29 M Developer Paris 52000
Grace 26 F Manager Marseille 48000
Henry 32 M Designer Paris 65000
EOF

# 1. Pattern simple : lignes contenant "Paris"
awk '/Paris/ {print}' users_extended.txt

# 2. Pattern avec négation : lignes ne contenant PAS "Paris"
awk '!/Paris/ {print}' users_extended.txt

# 3. Pattern sur colonne spécifique
awk '$4 == "Developer" {print}' users_extended.txt

# 4. Pattern numérique
awk '$2 > 28 {print}' users_extended.txt

# 5. Pattern avec plusieurs conditions (ET)
awk '$2 > 25 && $3 == "F" {print}' users_extended.txt

# 6. Pattern avec OU
awk '$5 == "Paris" || $5 == "Lyon" {print}' users_extended.txt

# 7. Pattern sur plage de lignes
awk 'NR >= 2 && NR <= 5 {print}' users_extended.txt

# 8. Pattern BEGIN et END
awk 'BEGIN {print "Début"}
     /Developer/ {print "Dev:", $1}
     END {print "Fin"}' users_extended.txt
```

---

### Partie 2.2 : Expressions Régulières

```bash
echo "=== EXPRESSIONS RÉGULIÈRES ==="

# Syntaxe: /regex/ { action }
# Opérateurs: ~ (correspond), !~ (ne correspond pas)

# 1. Regex simple
awk '/^A/ {print}' users_extended.txt  # Commence par A

# 2. Fin de ligne
awk '/000$/ {print}' users_extended.txt  # Se termine par 000

# 3. Regex sur une colonne
awk '$1 ~ /^[A-D]/ {print}' users_extended.txt  # Nom commence par A-D

# 4. Négation de regex
awk '$1 !~ /^A/ {print}' users_extended.txt  # Nom ne commence pas par A

# 5. Regex complexe
awk '$5 ~ /^(Paris|Lyon)$/ {print}' users_extended.txt

# 6. Ignorer la casse (GAWK)
awk 'tolower($0) ~ /paris/ {print}' users_extended.txt

# Créer fichier email pour tests regex
cat << 'EOF' > emails.txt
alice@example.com
bob@company.co.uk
charlie@test.org
invalid-email
diana@domain.net
eve@site.io
EOF

# 7. Valider format email (basique)
awk '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/ {print "Valid:", $0}
     !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/ {print "Invalid:", $0}' emails.txt

# 8. Extraire domaines
awk -F'@' '/^[a-zA-Z0-9._%+-]+@/ {print $2}' emails.txt

# Créer fichier logs pour extraction
cat << 'EOF' > access.log
192.168.1.10 - - [15/Feb/2026:10:30:15] "GET /index.html HTTP/1.1" 200 1234
192.168.1.20 - - [15/Feb/2026:10:31:22] "POST /api/login HTTP/1.1" 401 567
192.168.1.30 - - [15/Feb/2026:10:32:45] "GET /about.html HTTP/1.1" 200 890
192.168.1.10 - - [15/Feb/2026:10:35:10] "GET /contact.html HTTP/1.1" 404 234
EOF

# 9. Extraire IPs
awk '/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/ {
    match($0, /[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/)
    print substr($0, RSTART, RLENGTH)
}' access.log

# 10. Extraire codes HTTP
awk '/"[A-Z]+ \/[^ ]+ HTTP\/[0-9.]+" ([0-9]+)/ {
    match($0, /" [0-9]+/)
    print substr($0, RSTART+2, RLENGTH-2)
}' access.log
```

---

### Partie 2.3 : Conditions et Comparaisons

```bash
echo "=== CONDITIONS ET COMPARAISONS ==="

# Opérateurs de comparaison:
# == : égal
# != : différent
# <  : inférieur
# >  : supérieur
# <= : inférieur ou égal
# >= : supérieur ou égal
# ~  : correspond à regex
# !~ : ne correspond pas à regex

# 1. Égalité stricte
awk '$2 == 25 {print $1, "a exactement 25 ans"}' users_extended.txt

# 2. Différent
awk '$3 != "M" {print $1, "n'\''est pas un homme"}' users_extended.txt

# 3. Comparaison numérique
awk '$6 >= 60000 {print $1, "gagne", $6}' users_extended.txt

# 4. Comparaison de chaînes
awk '$4 == "Developer" {print}' users_extended.txt

# 5. ET logique (&&)
awk '$2 > 25 && $6 > 50000 {print $1, ":", $2, "ans,", $6, "€"}' users_extended.txt

# 6. OU logique (||)
awk '$5 == "Paris" || $6 > 60000 {print}' users_extended.txt

# 7. NON logique (!)
awk '!($3 == "M") {print $1, "est une femme"}' users_extended.txt

# 8. Conditions imbriquées
awk '{
    if ($2 < 25) 
        category = "Junior"
    else if ($2 < 30) 
        category = "Confirmé"
    else 
        category = "Senior"
    print $1, ":", category
}' users_extended.txt

# 9. Opérateur ternaire
awk '{print $1, ($6 > 55000 ? "Haut" : "Normal")}' users_extended.txt

# 10. Conditions multiples
awk '{
    if ($3 == "F" && $2 < 30 && $6 > 45000) {
        print $1, "correspond aux critères"
    }
}' users_extended.txt
```

---

### Partie 2.4 : Plages de Patterns

```bash
echo "=== PLAGES DE PATTERNS ==="

# Pattern range: pattern1, pattern2
# Active depuis pattern1 jusqu'à pattern2

# Créer fichier avec sections
cat << 'EOF' > sections.txt
START Section1
Data line 1
Data line 2
Data line 3
END Section1
Other line
START Section2
Data line 4
Data line 5
END Section2
Final line
EOF

# 1. Entre START et END
awk '/START/, /END/ {print}' sections.txt

# 2. Entre START et END (exclusif)
awk '/START/, /END/ {
    if (!/START/ && !/END/) print
}' sections.txt

# 3. Lignes 3 à 6
awk 'NR==3, NR==6 {print NR, $0}' sections.txt

# 4. Depuis première occurrence jusqu'à la fin
awk '/Section2/, 0 {print}' sections.txt

# Créer fichier configuration
cat << 'EOF' > config.txt
# Global settings
[NETWORK]
ip=192.168.1.1
port=8080
[DATABASE]
host=localhost
port=5432
user=admin
[CACHE]
enabled=true
ttl=3600
EOF

# 5. Extraire section spécifique
awk '/\[DATABASE\]/, /\[/ {
    if (!/\[/) print
}' config.txt

# 6. Compter lignes dans section
awk '/\[DATABASE\]/, /\[CACHE\]/ {
    if (!/\[/) count++
}
END {print "DATABASE section:", count, "lignes"}' config.txt
```

---

### Partie 2.5 : Patterns Avancés

```bash
echo "=== PATTERNS AVANCÉS ==="

# 1. Pattern avec fonction
awk 'length($0) > 50 {print}' users_extended.txt

# 2. Pattern avec calcul
awk '$2 * 2 > 50 {print $1, "double age >50"}' users_extended.txt

# 3. Plusieurs actions pour un pattern
awk '/Developer/ {
    count++
    total += $6
    print $1, "-", $6
}
END {
    print "Total developers:", count
    print "Salaire moyen:", total/count
}' users_extended.txt

# 4. Patterns multiples
awk '/Paris/ {paris++}
     /Lyon/ {lyon++}
     /Marseille/ {marseille++}
     END {
         print "Paris:", paris
         print "Lyon:", lyon
         print "Marseille:", marseille
     }' users_extended.txt

# 5. Pattern dynamique
awk -v city="Paris" '$5 == city {print}' users_extended.txt

# 6. Fichier de patterns
cat << 'EOF' > patterns.txt
Developer
Manager
EOF

# Lire patterns depuis fichier (GNU awk)
awk 'NR==FNR {patterns[$0]; next}
     {for (p in patterns) if ($4 == p) print}' patterns.txt users_extended.txt

# 7. Pattern avec BEGINFILE/ENDFILE (GNU awk)
cat << 'AWKSCRIPT' > multi_file.awk
BEGINFILE { 
    print "=== Fichier:", FILENAME, "===" 
}

{ 
    print "  ", $0 
}

ENDFILE { 
    print "Lignes:", FNR 
    print ""
}
AWKSCRIPT

awk -f multi_file.awk users_extended.txt emails.txt
```

---

### Partie 2.6 : Exercices Pratiques Niveau 2

```bash
#!/bin/bash
# exercices_niveau2.sh

echo "=== EXERCICES NIVEAU 2 ==="

# Créer fichier de ventes
cat << 'EOF' > sales_data.txt
2026-02-01 Laptop Alice 999.99
2026-02-01 Mouse Bob 19.99
2026-02-02 Keyboard Charlie 49.99
2026-02-02 Monitor Alice 299.99
2026-02-03 Mouse Diana 19.99
2026-02-03 Laptop Bob 999.99
2026-02-04 Headset Alice 79.99
2026-02-04 Keyboard Eve 49.99
2026-02-05 Monitor Bob 299.99
2026-02-05 Mouse Alice 19.99
EOF

echo "Fichier créé: sales_data.txt"
echo ""

# EXERCICE 1: Ventes > 100€
echo "EXERCICE 1: Ventes supérieures à 100€"
awk '$4 > 100 {print $0}' sales_data.txt
echo ""

# EXERCICE 2: Ventes d'Alice
echo "EXERCICE 2: Ventes d'Alice"
awk '$3 == "Alice" {print $0}' sales_data.txt
echo ""

# EXERCICE 3: Ventes de février 2026
echo "EXERCICE 3: Ventes commençant par 2026-02"
awk '/^2026-02/ {print $0}' sales_data.txt
echo ""

# EXERCICE 4: Produits finissant par 'top'
echo "EXERCICE 4: Produits finissant par 'top'"
awk '$2 ~ /top$/ {print $2}' sales_data.txt
echo ""

# EXERCICE 5: Ventes entre 50 et 300€
echo "EXERCICE 5: Ventes entre 50€ et 300€"
awk '$4 >= 50 && $4 <= 300 {print $0}' sales_data.txt
echo ""

# EXERCICE 6: Compter ventes par personne
echo "EXERCICE 6: Nombre de ventes par personne"
awk '{count[$3]++}
     END {for (name in count) print name ":", count[name]}' sales_data.txt
echo ""

# EXERCICE 7: Total des ventes
echo "EXERCICE 7: Total des ventes"
awk '{total += $4}
     END {printf "Total: %.2f€\n", total}' sales_data.txt
```

---

### 🎯 QUIZ NIVEAU 2

1. Que fait `/pattern/ {action}` ?
2. Comment sélectionner les lignes où la colonne 2 > 25 ?
3. Que signifie `$1 ~ /^A/` ?
4. Comment combiner deux conditions avec ET ?
5. Que fait `pattern1, pattern2` ?

**Réponses :**
1. Exécute action si la ligne contient pattern
2. `awk '$2 > 25 {print}' fichier`
3. Colonne 1 commence par A
4. `condition1 && condition2`
5. Active depuis pattern1 jusqu'à pattern2

---

**[Suite avec Niveau 3 - Variables et Opérateurs dans le prochain message...]**

Voulez-vous que je continue avec les niveaux 3 à 6 et le projet final ?
