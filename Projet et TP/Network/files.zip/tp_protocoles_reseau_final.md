# TP COMPLET : MAÎTRISE DES PROTOCOLES RÉSEAU (FIN)
## ANALYSE AVANCÉE • PROJET FINAL
### Partie 3/3 - Niveau 5 et Projet

---

<a name="niveau-5"></a>
## ⚫ NIVEAU 5 : ANALYSE AVANCÉE (6-8 heures)

### Objectifs
- Analyser le trafic réseau en profondeur
- Détecter les anomalies et attaques
- Optimiser les performances réseau
- Automatiser l'analyse

---

### Partie 5.1 : Analyse de Performance Réseau

#### Exercice 5.1.1 : Mesure de bande passante avec iperf3

```bash
# Installation
sudo apt install iperf3 -y

# SERVEUR (sur la machine cible)
iperf3 -s

# CLIENT (sur la machine source)
# Test TCP par défaut
iperf3 -c <server_ip>

# Test UDP avec bande passante spécifiée
iperf3 -c <server_ip> -u -b 100M

# Test reverse (serveur envoie au client)
iperf3 -c <server_ip> -R

# Test bidirectionnel
iperf3 -c <server_ip> --bidir

# Durée personnalisée (secondes)
iperf3 -c <server_ip> -t 30

# Connexions parallèles
iperf3 -c <server_ip> -P 4

# Format de sortie JSON
iperf3 -c <server_ip> -J

# IPv6
iperf3 -c <server_ipv6> -6

# Script de test complet
cat << 'EOF' > network_performance_test.sh
#!/bin/bash
# Test de performance réseau avec iperf3

SERVER="$1"
DURATION=10

if [ -z "$SERVER" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

echo "=== Test de Performance Réseau ==="
echo "Serveur: $SERVER"
echo "Durée: ${DURATION}s"
echo ""

# Test TCP download
echo "[1/5] Test TCP Download..."
iperf3 -c $SERVER -t $DURATION -J > tcp_download.json

# Test TCP upload
echo "[2/5] Test TCP Upload..."
iperf3 -c $SERVER -R -t $DURATION -J > tcp_upload.json

# Test bidirectionnel
echo "[3/5] Test Bidirectionnel..."
iperf3 -c $SERVER --bidir -t $DURATION -J > bidirectional.json

# Test UDP
echo "[4/5] Test UDP..."
iperf3 -c $SERVER -u -b 100M -t $DURATION -J > udp.json

# Test connexions parallèles
echo "[5/5] Test Connexions Parallèles..."
iperf3 -c $SERVER -P 4 -t $DURATION -J > parallel.json

# Analyse des résultats
echo ""
echo "=== Résultats ==="

for file in tcp_download.json tcp_upload.json bidirectional.json udp.json parallel.json; do
    if [ -f "$file" ]; then
        echo ""
        echo "Fichier: $file"
        python3 << PYTHON
import json
with open('$file') as f:
    data = json.load(f)
    
try:
    bw = data['end']['sum_received']['bits_per_second'] / 1000000
    print(f"  Bande passante: {bw:.2f} Mbps")
except:
    try:
        bw = data['end']['sum']['bits_per_second'] / 1000000
        print(f"  Bande passante: {bw:.2f} Mbps")
    except:
        print("  Impossible d'extraire les données")
PYTHON
    fi
done

echo ""
echo "Fichiers JSON créés pour analyse détaillée"
EOF

chmod +x network_performance_test.sh
```

---

#### Exercice 5.1.2 : Mesure de latence et jitter

```python
#!/usr/bin/env python3
# latency_jitter_analysis.py - Analyser latence et jitter

import subprocess
import re
import statistics
import time

def ping_analysis(host, count=100):
    """Analyser la latence avec ping"""
    
    print(f"Analyse de latence vers {host} ({count} pings)...")
    
    # Exécuter ping
    cmd = ['ping', '-c', str(count), '-i', '0.2', host]
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    # Extraire les temps
    times = []
    for line in result.stdout.split('\n'):
        match = re.search(r'time=([\d.]+)', line)
        if match:
            times.append(float(match.group(1)))
    
    if not times:
        print("Erreur: Aucune donnée")
        return
    
    # Calculer statistiques
    min_time = min(times)
    max_time = max(times)
    avg_time = statistics.mean(times)
    median_time = statistics.median(times)
    stdev_time = statistics.stdev(times)
    
    # Calculer jitter (variation de latence)
    jitter_values = [abs(times[i] - times[i-1]) for i in range(1, len(times))]
    avg_jitter = statistics.mean(jitter_values)
    max_jitter = max(jitter_values)
    
    # Pertes de paquets
    match = re.search(r'(\d+)% packet loss', result.stdout)
    packet_loss = float(match.group(1)) if match else 0
    
    # Afficher résultats
    print("\n=== RÉSULTATS ===")
    print(f"Paquets envoyés: {count}")
    print(f"Perte de paquets: {packet_loss}%")
    print(f"\nLatence:")
    print(f"  Minimum:     {min_time:.2f} ms")
    print(f"  Maximum:     {max_time:.2f} ms")
    print(f"  Moyenne:     {avg_time:.2f} ms")
    print(f"  Médiane:     {median_time:.2f} ms")
    print(f"  Écart-type:  {stdev_time:.2f} ms")
    print(f"\nJitter:")
    print(f"  Moyen:       {avg_jitter:.2f} ms")
    print(f"  Maximum:     {max_jitter:.2f} ms")
    
    # Classification
    print(f"\n=== ÉVALUATION ===")
    if avg_time < 20:
        print("Latence: Excellente")
    elif avg_time < 50:
        print("Latence: Bonne")
    elif avg_time < 100:
        print("Latence: Acceptable")
    else:
        print("Latence: Médiocre")
    
    if avg_jitter < 5:
        print("Jitter: Excellent")
    elif avg_jitter < 15:
        print("Jitter: Bon")
    elif avg_jitter < 30:
        print("Jitter: Acceptable")
    else:
        print("Jitter: Problématique")
    
    if packet_loss == 0:
        print("Perte de paquets: Aucune")
    elif packet_loss < 1:
        print("Perte de paquets: Négligeable")
    elif packet_loss < 5:
        print("Perte de paquets: Acceptable")
    else:
        print("Perte de paquets: Problématique")
    
    return {
        'min': min_time,
        'max': max_time,
        'avg': avg_time,
        'median': median_time,
        'stdev': stdev_time,
        'jitter_avg': avg_jitter,
        'jitter_max': max_jitter,
        'packet_loss': packet_loss
    }

def continuous_monitoring(host, interval=60):
    """Monitoring continu de la latence"""
    
    print(f"Monitoring continu de {host}")
    print(f"Intervalle: {interval}s")
    print("Ctrl+C pour arrêter\n")
    
    with open('latency_log.csv', 'w') as f:
        f.write("timestamp,min,max,avg,jitter,packet_loss\n")
    
    try:
        while True:
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
            stats = ping_analysis(host, count=20)
            
            if stats:
                with open('latency_log.csv', 'a') as f:
                    f.write(f"{timestamp},{stats['min']},{stats['max']},"
                           f"{stats['avg']},{stats['jitter_avg']},{stats['packet_loss']}\n")
                
                print(f"[{timestamp}] Latence: {stats['avg']:.2f}ms, "
                      f"Jitter: {stats['jitter_avg']:.2f}ms, "
                      f"Perte: {stats['packet_loss']}%")
            
            time.sleep(interval)
            
    except KeyboardInterrupt:
        print("\n\nMonitoring arrêté")
        print("Données sauvegardées dans latency_log.csv")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage:")
        print(f"  {sys.argv[0]} <host>                 # Analyse unique")
        print(f"  {sys.argv[0]} <host> --monitor      # Monitoring continu")
        sys.exit(1)
    
    host = sys.argv[1]
    
    if len(sys.argv) > 2 and sys.argv[2] == '--monitor':
        continuous_monitoring(host, interval=60)
    else:
        ping_analysis(host, count=100)
```

```bash
chmod +x latency_jitter_analysis.py
python3 latency_jitter_analysis.py 8.8.8.8
```

---

#### Exercice 5.1.3 : Analyse de MTU et fragmentation

```bash
#!/bin/bash
# mtu_discovery.sh - Découvrir le MTU optimal

TARGET="${1:-8.8.8.8}"

echo "=== Découverte MTU vers $TARGET ==="

# Test avec différentes tailles de paquets
# MTU = Taille données + 28 (20 IP + 8 ICMP)

echo "Test de fragmentation..."

for size in 1472 1500 2000 3000 4000 8000; do
    echo -n "Taille $size octets: "
    
    # -M do : Don't Fragment
    # -c 1 : 1 paquet
    # -s : taille des données
    if ping -M do -c 1 -s $size -W 2 $TARGET > /dev/null 2>&1; then
        echo "✓ OK"
    else
        echo "✗ Échoué (fragmentation nécessaire)"
    fi
done

# Recherche binaire du MTU optimal
echo ""
echo "Recherche du MTU optimal..."

min_size=0
max_size=9000
optimal=0

while [ $((max_size - min_size)) -gt 1 ]; do
    test_size=$(( (min_size + max_size) / 2 ))
    
    if ping -M do -c 1 -s $test_size -W 1 $TARGET > /dev/null 2>&1; then
        min_size=$test_size
        optimal=$test_size
    else
        max_size=$test_size
    fi
done

echo "MTU optimal: $((optimal + 28)) octets"
echo "(Données: $optimal octets + 28 octets headers)"

# Afficher le MTU de l'interface locale
echo ""
echo "MTU des interfaces locales:"
ip link show | grep -E "^[0-9]:|mtu"
```

---

### Partie 5.2 : Détection d'Anomalies et Attaques

#### Exercice 5.2.1 : Détection de scan de ports

```python
#!/usr/bin/env python3
# port_scan_detector.py - Détecter les scans de ports

from scapy.all import *
from collections import defaultdict
import time
import threading

class PortScanDetector:
    def __init__(self, threshold=10, time_window=5):
        """
        threshold: nombre de ports différents pour considérer comme scan
        time_window: fenêtre de temps en secondes
        """
        self.threshold = threshold
        self.time_window = time_window
        self.connections = defaultdict(lambda: {'ports': set(), 'first_seen': None})
        self.lock = threading.Lock()
        
    def process_packet(self, packet):
        """Analyser un paquet"""
        
        if not packet.haslayer(TCP):
            return
        
        # Récupérer infos
        src_ip = packet[IP].src
        dst_port = packet[TCP].dport
        flags = packet[TCP].flags
        
        current_time = time.time()
        
        with self.lock:
            # Initialiser si nouveau
            if self.connections[src_ip]['first_seen'] is None:
                self.connections[src_ip]['first_seen'] = current_time
            
            # Nettoyer vieilles entrées
            if current_time - self.connections[src_ip]['first_seen'] > self.time_window:
                self.connections[src_ip] = {'ports': set(), 'first_seen': current_time}
            
            # Ajouter le port
            self.connections[src_ip]['ports'].add(dst_port)
            
            # Vérifier si c'est un scan
            num_ports = len(self.connections[src_ip]['ports'])
            
            if num_ports >= self.threshold:
                self.alert_scan(src_ip, num_ports, list(self.connections[src_ip]['ports']))
                # Reset après alerte
                self.connections[src_ip] = {'ports': set(), 'first_seen': current_time}
    
    def alert_scan(self, src_ip, num_ports, ports):
        """Générer une alerte"""
        print(f"\n{'='*60}")
        print(f"⚠️  SCAN DE PORTS DÉTECTÉ!")
        print(f"{'='*60}")
        print(f"IP Source:     {src_ip}")
        print(f"Ports scannés: {num_ports}")
        print(f"Liste:         {sorted(ports)[:20]}{'...' if len(ports) > 20 else ''}")
        print(f"Timestamp:     {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*60}\n")
        
        # Logger dans un fichier
        with open('port_scan_alerts.log', 'a') as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - "
                   f"Port scan from {src_ip} ({num_ports} ports)\n")
    
    def start_monitoring(self, interface='any'):
        """Démarrer le monitoring"""
        print(f"Démarrage détection de scan de ports...")
        print(f"Interface: {interface}")
        print(f"Seuil: {self.threshold} ports en {self.time_window}s")
        print(f"Ctrl+C pour arrêter\n")
        
        try:
            sniff(iface=interface, 
                  filter="tcp",
                  prn=self.process_packet,
                  store=False)
        except KeyboardInterrupt:
            print("\n\nArrêt du monitoring")

def main():
    if os.geteuid() != 0:
        print("Ce script nécessite les privilèges root (sudo)")
        sys.exit(1)
    
    detector = PortScanDetector(threshold=10, time_window=5)
    detector.start_monitoring()

if __name__ == "__main__":
    main()
```

```bash
chmod +x port_scan_detector.py

# Terminal 1: Démarrer le détecteur
sudo python3 port_scan_detector.py

# Terminal 2: Simuler un scan
nmap -F localhost
```

---

#### Exercice 5.2.2 : Détection de SYN flood

```python
#!/usr/bin/env python3
# syn_flood_detector.py - Détecter les attaques SYN flood

from scapy.all import *
from collections import defaultdict
import time

class SynFloodDetector:
    def __init__(self, threshold=100, time_window=10):
        self.threshold = threshold
        self.time_window = time_window
        self.syn_counts = defaultdict(list)
        
    def process_packet(self, packet):
        if not packet.haslayer(TCP):
            return
        
        # Vérifier si c'est un SYN
        if packet[TCP].flags == 'S':
            src_ip = packet[IP].src
            current_time = time.time()
            
            # Ajouter timestamp
            self.syn_counts[src_ip].append(current_time)
            
            # Nettoyer vieux timestamps
            self.syn_counts[src_ip] = [
                t for t in self.syn_counts[src_ip]
                if current_time - t <= self.time_window
            ]
            
            # Vérifier le seuil
            count = len(self.syn_counts[src_ip])
            
            if count >= self.threshold:
                self.alert_flood(src_ip, count)
                self.syn_counts[src_ip] = []
    
    def alert_flood(self, src_ip, count):
        print(f"\n{'='*60}")
        print(f"🚨 SYN FLOOD DÉTECTÉ!")
        print(f"{'='*60}")
        print(f"IP Source:  {src_ip}")
        print(f"SYN count:  {count} en {self.time_window}s")
        print(f"Timestamp:  {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*60}\n")
        
        with open('syn_flood_alerts.log', 'a') as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - "
                   f"SYN flood from {src_ip} ({count} SYN)\n")
    
    def start_monitoring(self):
        print("Détection SYN flood active...")
        print(f"Seuil: {self.threshold} SYN en {self.time_window}s")
        print("Ctrl+C pour arrêter\n")
        
        try:
            sniff(filter="tcp",
                  prn=self.process_packet,
                  store=False)
        except KeyboardInterrupt:
            print("\n\nArrêt")

if __name__ == "__main__":
    if os.geteuid() != 0:
        print("Nécessite root (sudo)")
        sys.exit(1)
    
    detector = SynFloodDetector(threshold=100, time_window=10)
    detector.start_monitoring()
```

---

#### Exercice 5.2.3 : Analyse de trafic suspect

```bash
#!/bin/bash
# suspicious_traffic_analysis.sh - Analyser le trafic suspect

CAPTURE_FILE="suspicious.pcap"
DURATION=60

echo "=== Analyse de Trafic Suspect ==="

# Capturer le trafic
echo "[1/6] Capture du trafic ($DURATION secondes)..."
sudo timeout $DURATION tcpdump -i any -w $CAPTURE_FILE -q

# Analyse 1: Top IPs sources
echo ""
echo "[2/6] Top 10 IPs sources:"
tshark -r $CAPTURE_FILE -T fields -e ip.src | sort | uniq -c | sort -rn | head -10

# Analyse 2: Top IPs destinations
echo ""
echo "[3/6] Top 10 IPs destinations:"
tshark -r $CAPTURE_FILE -T fields -e ip.dst | sort | uniq -c | sort -rn | head -10

# Analyse 3: Protocoles utilisés
echo ""
echo "[4/6] Distribution des protocoles:"
tshark -r $CAPTURE_FILE -T fields -e ip.proto | sort | uniq -c | sort -rn

# Analyse 4: Ports scannés
echo ""
echo "[5/6] Ports les plus contactés:"
tshark -r $CAPTURE_FILE -T fields -e tcp.dstport -e udp.dstport | \
    grep -v "^$" | sort | uniq -c | sort -rn | head -20

# Analyse 5: Détection de patterns suspects
echo ""
echo "[6/6] Patterns suspects:"

# Scans de ports (beaucoup de SYN sans ACK)
SYN_COUNT=$(tshark -r $CAPTURE_FILE -Y "tcp.flags.syn==1 and tcp.flags.ack==0" | wc -l)
echo "  Paquets SYN sans ACK: $SYN_COUNT"

if [ $SYN_COUNT -gt 100 ]; then
    echo "    ⚠️  Possible scan de ports!"
fi

# Fragmentation excessive
FRAG_COUNT=$(tshark -r $CAPTURE_FILE -Y "ip.flags.mf==1 or ip.frag_offset>0" | wc -l)
echo "  Paquets fragmentés: $FRAG_COUNT"

if [ $FRAG_COUNT -gt 50 ]; then
    echo "    ⚠️  Fragmentation suspecte!"
fi

# Paquets avec TTL faible
LOW_TTL=$(tshark -r $CAPTURE_FILE -Y "ip.ttl<10" | wc -l)
echo "  Paquets avec TTL < 10: $LOW_TTL"

# Connexions vers ports inhabituels
UNUSUAL_PORTS=$(tshark -r $CAPTURE_FILE -Y "tcp.dstport>49151 or udp.dstport>49151" | wc -l)
echo "  Connexions vers ports >49151: $UNUSUAL_PORTS"

echo ""
echo "Analyse terminée. Fichier: $CAPTURE_FILE"
```

---

### Partie 5.3 : Optimisation Réseau

#### Exercice 5.3.1 : Tuning TCP/IP Linux

```bash
#!/bin/bash
# tcp_tuning.sh - Optimiser les paramètres TCP/IP

echo "=== Optimisation TCP/IP ==="

# Backup config actuelle
sysctl -a | grep -E "net.core|net.ipv4" > /tmp/sysctl_backup_$(date +%Y%m%d).txt

# Paramètres optimisés pour serveur
cat << 'EOF' | sudo tee /etc/sysctl.d/99-network-performance.conf
# === Network Performance Tuning ===

# Augmenter les buffers réseau
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 16777216
net.core.wmem_default = 16777216

# Buffer TCP
net.ipv4.tcp_rmem = 4096 87380 134217728
net.ipv4.tcp_wmem = 4096 65536 134217728

# Augmenter la taille de la queue SYN
net.ipv4.tcp_max_syn_backlog = 8192
net.core.somaxconn = 1024

# Fast socket recycling
net.ipv4.tcp_tw_reuse = 1

# Protection SYN flood
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_synack_retries = 2

# Keepalive
net.ipv4.tcp_keepalive_time = 600
net.ipv4.tcp_keepalive_intvl = 60
net.ipv4.tcp_keepalive_probes = 3

# Fenêtre TCP
net.ipv4.tcp_window_scaling = 1

# MTU Discovery
net.ipv4.tcp_mtu_probing = 1

# Congestion control (BBR si disponible, sinon cubic)
net.ipv4.tcp_congestion_control = cubic

# IP forwarding (routeur)
#net.ipv4.ip_forward = 1

# Accepter redirects ICMP (désactiver pour sécurité)
net.ipv4.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0

# Netfilter conntrack
net.netfilter.nf_conntrack_max = 1048576

# File descriptor limits
fs.file-max = 2097152

EOF

# Appliquer
sudo sysctl -p /etc/sysctl.d/99-network-performance.conf

echo ""
echo "✓ Paramètres appliqués"
echo ""
echo "Vérifier avec:"
echo "  sysctl net.ipv4.tcp_rmem"
echo "  sysctl net.core.rmem_max"
```

---

#### Exercice 5.3.2 : Monitoring de performance réseau

```python
#!/usr/bin/env python3
# network_monitor.py - Monitoring performance réseau

import psutil
import time
import json
from datetime import datetime

class NetworkMonitor:
    def __init__(self, interval=1):
        self.interval = interval
        self.last_stats = psutil.net_io_counters()
        self.last_time = time.time()
        
    def get_bandwidth(self):
        """Calculer la bande passante actuelle"""
        current_stats = psutil.net_io_counters()
        current_time = time.time()
        
        time_delta = current_time - self.last_time
        
        # Calculer les différences
        bytes_sent = current_stats.bytes_sent - self.last_stats.bytes_sent
        bytes_recv = current_stats.bytes_recv - self.last_stats.bytes_recv
        
        # Bande passante en Mbps
        upload_mbps = (bytes_sent * 8) / (time_delta * 1000000)
        download_mbps = (bytes_recv * 8) / (time_delta * 1000000)
        
        # Mettre à jour
        self.last_stats = current_stats
        self.last_time = current_time
        
        return {
            'upload_mbps': upload_mbps,
            'download_mbps': download_mbps,
            'total_mbps': upload_mbps + download_mbps,
            'bytes_sent': bytes_sent,
            'bytes_recv': bytes_recv,
            'packets_sent': current_stats.packets_sent,
            'packets_recv': current_stats.packets_recv,
            'errors_in': current_stats.errin,
            'errors_out': current_stats.errout,
            'drops_in': current_stats.dropin,
            'drops_out': current_stats.dropout
        }
    
    def get_connections(self):
        """Obtenir les connexions actives"""
        connections = psutil.net_connections(kind='inet')
        
        stats = {
            'total': len(connections),
            'established': 0,
            'listen': 0,
            'time_wait': 0,
            'close_wait': 0,
            'by_port': {}
        }
        
        for conn in connections:
            stats[conn.status.lower()] = stats.get(conn.status.lower(), 0) + 1
            
            if conn.laddr:
                port = conn.laddr.port
                stats['by_port'][port] = stats['by_port'].get(port, 0) + 1
        
        return stats
    
    def monitor_realtime(self, duration=None):
        """Monitoring en temps réel"""
        print("Network Monitoring - Ctrl+C pour arrêter\n")
        print(f"{'Time':<20} {'Upload':<15} {'Download':<15} {'Total':<15} {'Connections':<12} {'Errors':<10}")
        print("-" * 100)
        
        start_time = time.time()
        
        try:
            while True:
                if duration and (time.time() - start_time) >= duration:
                    break
                
                bw = self.get_bandwidth()
                conn = self.get_connections()
                
                timestamp = datetime.now().strftime('%H:%M:%S')
                
                print(f"{timestamp:<20} "
                      f"{bw['upload_mbps']:>10.2f} Mbps  "
                      f"{bw['download_mbps']:>10.2f} Mbps  "
                      f"{bw['total_mbps']:>10.2f} Mbps  "
                      f"{conn['total']:>10}  "
                      f"{bw['errors_in'] + bw['errors_out']:>8}")
                
                time.sleep(self.interval)
                
        except KeyboardInterrupt:
            print("\n\nMonitoring arrêté")
    
    def monitor_to_file(self, filename, duration=3600):
        """Monitoring vers fichier JSON"""
        print(f"Enregistrement dans {filename} pendant {duration}s...")
        
        data = []
        start_time = time.time()
        
        try:
            while (time.time() - start_time) < duration:
                timestamp = datetime.now().isoformat()
                bw = self.get_bandwidth()
                conn = self.get_connections()
                
                entry = {
                    'timestamp': timestamp,
                    'bandwidth': bw,
                    'connections': conn
                }
                
                data.append(entry)
                
                # Sauvegarder périodiquement
                if len(data) % 60 == 0:
                    with open(filename, 'w') as f:
                        json.dump(data, f, indent=2)
                    print(f"[{timestamp}] {len(data)} échantillons sauvegardés")
                
                time.sleep(self.interval)
                
        except KeyboardInterrupt:
            print("\n\nArrêt...")
        
        # Sauvegarde finale
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"\n✓ Données sauvegardées: {filename}")
        print(f"  Échantillons: {len(data)}")
        print(f"  Durée: {time.time() - start_time:.0f}s")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Network Performance Monitor')
    parser.add_argument('--interval', type=float, default=1.0,
                       help='Intervalle de mesure (secondes)')
    parser.add_argument('--duration', type=int,
                       help='Durée du monitoring (secondes)')
    parser.add_argument('--output', type=str,
                       help='Fichier de sortie JSON')
    
    args = parser.parse_args()
    
    monitor = NetworkMonitor(interval=args.interval)
    
    if args.output:
        duration = args.duration or 3600
        monitor.monitor_to_file(args.output, duration)
    else:
        monitor.monitor_realtime(duration=args.duration)

if __name__ == "__main__":
    main()
```

```bash
chmod +x network_monitor.py

# Monitoring temps réel
python3 network_monitor.py

# Enregistrer dans un fichier pendant 1h
python3 network_monitor.py --output network_stats.json --duration 3600

# Intervalle de 0.5s
python3 network_monitor.py --interval 0.5
```

---

### Partie 5.4 : Analyse Forensique Réseau

#### Exercice 5.4.1 : Extraction de fichiers depuis PCAP

```bash
#!/bin/bash
# extract_files_from_pcap.sh - Extraire fichiers d'une capture

PCAP="$1"

if [ -z "$PCAP" ] || [ ! -f "$PCAP" ]; then
    echo "Usage: $0 <fichier.pcap>"
    exit 1
fi

echo "=== Extraction de fichiers depuis PCAP ==="
echo "Fichier: $PCAP"

# Créer répertoire de sortie
OUTPUT_DIR="extracted_$(basename $PCAP .pcap)"
mkdir -p "$OUTPUT_DIR"

# 1. Extraire les fichiers HTTP
echo ""
echo "[1] Extraction HTTP..."
tshark -r "$PCAP" --export-objects "http,$OUTPUT_DIR/http" 2>/dev/null
HTTP_COUNT=$(ls -1 "$OUTPUT_DIR/http" 2>/dev/null | wc -l)
echo "  Fichiers HTTP extraits: $HTTP_COUNT"

# 2. Extraire les fichiers SMB
echo ""
echo "[2] Extraction SMB..."
tshark -r "$PCAP" --export-objects "smb,$OUTPUT_DIR/smb" 2>/dev/null
SMB_COUNT=$(ls -1 "$OUTPUT_DIR/smb" 2>/dev/null | wc -l)
echo "  Fichiers SMB extraits: $SMB_COUNT"

# 3. Extraire les fichiers TFTP
echo ""
echo "[3] Extraction TFTP..."
tshark -r "$PCAP" --export-objects "tftp,$OUTPUT_DIR/tftp" 2>/dev/null
TFTP_COUNT=$(ls -1 "$OUTPUT_DIR/tftp" 2>/dev/null | wc -l)
echo "  Fichiers TFTP extraits: $TFTP_COUNT"

# 4. Analyser les URLs
echo ""
echo "[4] Extraction URLs HTTP..."
tshark -r "$PCAP" -Y "http.request" -T fields -e http.host -e http.request.uri | \
    awk '{print "http://"$1$2}' > "$OUTPUT_DIR/urls.txt"
URL_COUNT=$(wc -l < "$OUTPUT_DIR/urls.txt")
echo "  URLs extraites: $URL_COUNT"

# 5. Extraire les emails
echo ""
echo "[5] Recherche d'emails..."
tshark -r "$PCAP" -Y "smtp" -V | grep -Eo "\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b" | \
    sort -u > "$OUTPUT_DIR/emails.txt"
EMAIL_COUNT=$(wc -l < "$OUTPUT_DIR/emails.txt")
echo "  Emails trouvés: $EMAIL_COUNT"

# 6. Extraire les credentials
echo ""
echo "[6] Recherche de credentials..."
tshark -r "$PCAP" -Y "http.request.method==POST" -V | \
    grep -i "password\|passwd\|pwd" > "$OUTPUT_DIR/potential_passwords.txt" 2>/dev/null

# Résumé
echo ""
echo "=== Résumé ==="
echo "Répertoire de sortie: $OUTPUT_DIR"
ls -lh "$OUTPUT_DIR"

echo ""
echo "Fichiers extraits dans:"
echo "  HTTP: $OUTPUT_DIR/http/"
echo "  SMB:  $OUTPUT_DIR/smb/"
echo "  TFTP: $OUTPUT_DIR/tftp/"
echo "  URLs: $OUTPUT_DIR/urls.txt"
```

---

#### Exercice 5.4.2 : Reconstruction de sessions TCP

```python
#!/usr/bin/env python3
# tcp_stream_reconstruction.py - Reconstruire streams TCP

from scapy.all import *
from collections import defaultdict

def reconstruct_tcp_streams(pcap_file):
    """Reconstruire les streams TCP"""
    
    print(f"Lecture de {pcap_file}...")
    packets = rdpcap(pcap_file)
    
    # Grouper par connexion TCP
    streams = defaultdict(lambda: {'data': b'', 'packets': []})
    
    for pkt in packets:
        if not pkt.haslayer(TCP) or not pkt.haslayer(IP):
            continue
        
        # Identifier le stream
        src = f"{pkt[IP].src}:{pkt[TCP].sport}"
        dst = f"{pkt[IP].dst}:{pkt[TCP].dport}"
        
        # Clé unique pour le stream (bidirectionnel)
        stream_key = tuple(sorted([src, dst]))
        
        # Ajouter les données
        if pkt.haslayer(Raw):
            streams[stream_key]['data'] += bytes(pkt[Raw].load)
            streams[stream_key]['packets'].append(pkt)
    
    print(f"\n{len(streams)} streams TCP trouvés\n")
    
    # Analyser chaque stream
    for i, (stream_key, stream_data) in enumerate(streams.items(), 1):
        data = stream_data['data']
        packets = stream_data['packets']
        
        if len(data) == 0:
            continue
        
        print(f"Stream #{i}")
        print(f"  Connexion: {stream_key[0]} <-> {stream_key[1]}")
        print(f"  Paquets: {len(packets)}")
        print(f"  Taille: {len(data)} octets")
        
        # Détecter le type de protocole
        protocol = detect_protocol(data)
        print(f"  Protocole: {protocol}")
        
        # Sauvegarder dans un fichier
        filename = f"stream_{i}_{protocol}.bin"
        with open(filename, 'wb') as f:
            f.write(data)
        print(f"  Sauvegardé: {filename}")
        
        # Afficher début des données
        preview = data[:100]
        if all(32 <= b < 127 or b in [9, 10, 13] for b in preview):
            print(f"  Aperçu: {preview.decode('ascii', errors='ignore')[:80]}...")
        else:
            print(f"  Aperçu: {preview.hex()[:80]}...")
        
        print()

def detect_protocol(data):
    """Détecter le protocole à partir des données"""
    
    try:
        data_str = data.decode('ascii', errors='ignore')
        
        if data_str.startswith('GET ') or data_str.startswith('POST ') or 'HTTP/' in data_str:
            return 'HTTP'
        elif data_str.startswith('SSH-'):
            return 'SSH'
        elif b'\x16\x03' in data[:10]:  # TLS handshake
            return 'TLS'
        elif data_str.startswith('220 ') or 'SMTP' in data_str:
            return 'SMTP'
        elif data_str.startswith('+OK') or 'POP3' in data_str:
            return 'POP3'
    except:
        pass
    
    return 'Unknown'

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <fichier.pcap>")
        sys.exit(1)
    
    reconstruct_tcp_streams(sys.argv[1])
```

---

### 🎯 QUIZ NIVEAU 5

1. Comment mesurer la bande passante entre deux machines ?
2. Qu'est-ce que le jitter réseau ?
3. Comment détecter un scan de ports dans le trafic ?
4. Quels paramètres sysctl optimiser pour hautes performances ?
5. Comment extraire des fichiers d'une capture PCAP ?
6. Qu'est-ce qu'une attaque SYN flood ?
7. Quel est le MTU standard d'Ethernet ?
8. Comment reconstruire une session TCP depuis un PCAP ?

---

<a name="projet-final"></a>
## 🏆 PROJET FINAL : LABORATOIRE RÉSEAU COMPLET

### Objectif
Créer un laboratoire réseau complet intégrant tous les protocoles étudiés, avec monitoring, analyse de sécurité et optimisation.

---

### Architecture du Projet

```
┌─────────────────────────────────────────────────────────────┐
│                    LABORATOIRE RÉSEAU                        │
│                                                              │
│  ┌────────────┐    ┌────────────┐    ┌────────────┐       │
│  │   Client   │───│  Firewall  │───│   Server   │       │
│  │  Machine   │    │  /Router   │    │  Machine   │       │
│  └────────────┘    └────────────┘    └────────────┘       │
│       │                  │                  │               │
│       │                  │                  │               │
│       └──────────────────┴──────────────────┘               │
│                          │                                   │
│                ┌─────────┴──────────┐                       │
│                │  Monitoring/IDS    │                       │
│                │     Station        │                       │
│                └────────────────────┘                       │
└─────────────────────────────────────────────────────────────┘

Services à déployer:
- HTTP/HTTPS Web Server
- SSH Server
- DNS Server
- Monitoring (Prometheus/Grafana ou custom)
- IDS (Snort ou custom)
- Traffic Generator
```

---

### Phase 1 : Installation et Configuration

```bash
#!/bin/bash
# setup_lab.sh - Configuration complète du laboratoire

echo "=== CONFIGURATION DU LABORATOIRE RÉSEAU ==="

# 1. Installation des services
echo "[1/8] Installation des services..."
sudo apt update
sudo apt install -y \
    apache2 nginx \
    openssh-server \
    bind9 bind9utils \
    iperf3 \
    tcpdump wireshark tshark \
    python3-pip python3-scapy \
    snort fail2ban \
    docker.io docker-compose

# 2. Configuration Apache
echo "[2/8] Configuration Apache..."
sudo systemctl start apache2
sudo systemctl enable apache2

cat << 'EOF' | sudo tee /var/www/html/index.html
<!DOCTYPE html>
<html>
<head>
    <title>Lab Réseau</title>
    <style>
        body { font-family: Arial; margin: 50px; }
        h1 { color: #333; }
        .info { background: #f0f0f0; padding: 20px; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Laboratoire Réseau - Serveur Web</h1>
    <div class="info">
        <h2>Services disponibles:</h2>
        <ul>
            <li>HTTP: Port 80</li>
            <li>HTTPS: Port 443</li>
            <li>SSH: Port 22</li>
            <li>DNS: Port 53</li>
        </ul>
        <p>Timestamp: <span id="time"></span></p>
    </div>
    <script>
        document.getElementById('time').textContent = new Date().toLocaleString();
    </script>
</body>
</html>
EOF

# 3. Configuration HTTPS
echo "[3/8] Configuration HTTPS..."
sudo mkdir -p /etc/apache2/ssl
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/apache2/ssl/server.key \
    -out /etc/apache2/ssl/server.crt \
    -subj "/C=FR/ST=France/L=Paris/O=Lab/CN=localhost"

sudo a2enmod ssl
sudo a2ensite default-ssl
sudo systemctl reload apache2

# 4. Configuration SSH
echo "[4/8] Configuration SSH..."
sudo systemctl start ssh
sudo systemctl enable ssh

# 5. Configuration DNS
echo "[5/8] Configuration DNS basique..."
sudo systemctl start named
sudo systemctl enable named

# 6. Firewall
echo "[6/8] Configuration firewall..."
sudo ufw allow 22/tcp   # SSH
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp  # HTTPS
sudo ufw allow 53/udp   # DNS
sudo ufw --force enable

# 7. Fail2ban
echo "[7/8] Configuration fail2ban..."
sudo systemctl start fail2ban
sudo systemctl enable fail2ban

# 8. Scripts de monitoring
echo "[8/8] Création des scripts de monitoring..."

# Script principal de monitoring
cat << 'SCRIPT' > ~/monitor_lab.sh
#!/bin/bash

while true; do
    clear
    echo "=== MONITORING LABORATOIRE RÉSEAU ==="
    echo "Date: $(date)"
    echo ""
    
    echo "Services:"
    systemctl is-active apache2 && echo "  ✓ Apache" || echo "  ✗ Apache"
    systemctl is-active ssh && echo "  ✓ SSH" || echo "  ✗ SSH"
    systemctl is-active named && echo "  ✓ DNS" || echo "  ✗ DNS"
    
    echo ""
    echo "Connexions actives:"
    ss -tn | grep ESTAB | wc -l
    
    echo ""
    echo "Top 5 IPs connectées:"
    ss -tn | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | head -5
    
    echo ""
    echo "Utilisation réseau:"
    vnstat -l --oneline | cut -d\; -f4-5
    
    sleep 5
done
SCRIPT

chmod +x ~/monitor_lab.sh

echo ""
echo "✓ Configuration terminée!"
echo ""
echo "Services démarrés:"
echo "  - HTTP:  http://$(hostname -I | awk '{print $1}')"
echo "  - HTTPS: https://$(hostname -I | awk '{print $1}')"
echo "  - SSH:   ssh $(whoami)@$(hostname -I | awk '{print $1}')"
echo ""
echo "Lancer le monitoring:"
echo "  ~/monitor_lab.sh"
```

---

### Phase 2 : Tests de Protocoles

```python
#!/usr/bin/env python3
# test_all_protocols.py - Tester tous les protocoles

import socket
import subprocess
import requests
import time
from datetime import datetime

class ProtocolTester:
    def __init__(self, target='localhost'):
        self.target = target
        self.results = {}
        
    def test_icmp(self):
        """Test ICMP (ping)"""
        print("[1/6] Test ICMP...")
        
        try:
            result = subprocess.run(
                ['ping', '-c', '4', self.target],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                # Extraire latence moyenne
                for line in result.stdout.split('\n'):
                    if 'avg' in line:
                        avg_time = line.split('/')[4]
                        self.results['ICMP'] = {
                            'status': 'OK',
                            'latency': f"{avg_time}ms"
                        }
                        return True
            
            self.results['ICMP'] = {'status': 'FAILED'}
            return False
            
        except Exception as e:
            self.results['ICMP'] = {'status': 'ERROR', 'error': str(e)}
            return False
    
    def test_tcp(self, port=80):
        """Test TCP connection"""
        print(f"[2/6] Test TCP (port {port})...")
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            
            start = time.time()
            result = sock.connect_ex((self.target, port))
            latency = (time.time() - start) * 1000
            
            sock.close()
            
            if result == 0:
                self.results['TCP'] = {
                    'status': 'OK',
                    'port': port,
                    'latency': f"{latency:.2f}ms"
                }
                return True
            else:
                self.results['TCP'] = {'status': 'FAILED', 'port': port}
                return False
                
        except Exception as e:
            self.results['TCP'] = {'status': 'ERROR', 'error': str(e)}
            return False
    
    def test_udp(self, port=53):
        """Test UDP"""
        print(f"[3/6] Test UDP (port {port})...")
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(2)
            
            # Envoyer un paquet
            sock.sendto(b'test', (self.target, port))
            
            try:
                data, addr = sock.recvfrom(1024)
                self.results['UDP'] = {
                    'status': 'OK',
                    'port': port,
                    'response': True
                }
                return True
            except socket.timeout:
                self.results['UDP'] = {
                    'status': 'OK',
                    'port': port,
                    'response': False,
                    'note': 'No response (normal for some services)'
                }
                return True
                
        except Exception as e:
            self.results['UDP'] = {'status': 'ERROR', 'error': str(e)}
            return False
    
    def test_http(self):
        """Test HTTP"""
        print("[4/6] Test HTTP...")
        
        try:
            start = time.time()
            response = requests.get(f'http://{self.target}', timeout=5)
            latency = (time.time() - start) * 1000
            
            self.results['HTTP'] = {
                'status': 'OK',
                'code': response.status_code,
                'latency': f"{latency:.2f}ms",
                'size': len(response.content)
            }
            return True
            
        except Exception as e:
            self.results['HTTP'] = {'status': 'ERROR', 'error': str(e)}
            return False
    
    def test_https(self):
        """Test HTTPS"""
        print("[5/6] Test HTTPS...")
        
        try:
            start = time.time()
            response = requests.get(f'https://{self.target}', 
                                   timeout=5, 
                                   verify=False)
            latency = (time.time() - start) * 1000
            
            self.results['HTTPS'] = {
                'status': 'OK',
                'code': response.status_code,
                'latency': f"{latency:.2f}ms",
                'tls_version': 'TLS'  # Simplifié
            }
            return True
            
        except Exception as e:
            self.results['HTTPS'] = {'status': 'ERROR', 'error': str(e)}
            return False
    
    def test_ssh(self, port=22):
        """Test SSH"""
        print(f"[6/6] Test SSH (port {port})...")
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((self.target, port))
            
            # Lire le banner SSH
            banner = sock.recv(1024).decode('utf-8').strip()
            sock.close()
            
            if 'SSH' in banner:
                self.results['SSH'] = {
                    'status': 'OK',
                    'port': port,
                    'banner': banner
                }
                return True
            else:
                self.results['SSH'] = {'status': 'FAILED', 'port': port}
                return False
                
        except Exception as e:
            self.results['SSH'] = {'status': 'ERROR', 'error': str(e)}
            return False
    
    def run_all_tests(self):
        """Exécuter tous les tests"""
        print("="*60)
        print("TEST DE TOUS LES PROTOCOLES")
        print("="*60)
        print(f"Cible: {self.target}")
        print(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("")
        
        tests = [
            self.test_icmp,
            lambda: self.test_tcp(80),
            lambda: self.test_udp(53),
            self.test_http,
            self.test_https,
            lambda: self.test_ssh(22)
        ]
        
        for test in tests:
            test()
            time.sleep(0.5)
        
        self.print_results()
    
    def print_results(self):
        """Afficher les résultats"""
        print("\n" + "="*60)
        print("RÉSULTATS")
        print("="*60)
        
        for protocol, result in self.results.items():
            status = result.get('status', 'UNKNOWN')
            symbol = '✓' if status == 'OK' else '✗'
            
            print(f"\n{symbol} {protocol}")
            for key, value in result.items():
                if key != 'status':
                    print(f"    {key}: {value}")
        
        # Résumé
        total = len(self.results)
        success = sum(1 for r in self.results.values() if r.get('status') == 'OK')
        
        print("\n" + "="*60)
        print(f"RÉSUMÉ: {success}/{total} tests réussis")
        print("="*60)

if __name__ == "__main__":
    import sys
    import warnings
    warnings.filterwarnings('ignore')
    
    target = sys.argv[1] if len(sys.argv) > 1 else 'localhost'
    
    tester = ProtocolTester(target)
    tester.run_all_tests()
```

---

### Phase 3 : Monitoring et Analyse

```python
#!/usr/bin/env python3
# lab_dashboard.py - Dashboard de monitoring

import psutil
import time
import curses
from datetime import datetime
import subprocess

class LabDashboard:
    def __init__(self):
        self.running = True
        
    def get_network_stats(self):
        """Statistiques réseau"""
        net_io = psutil.net_io_counters()
        
        return {
            'bytes_sent': net_io.bytes_sent,
            'bytes_recv': net_io.bytes_recv,
            'packets_sent': net_io.packets_sent,
            'packets_recv': net_io.packets_recv,
            'errors': net_io.errin + net_io.errout
        }
    
    def get_connections(self):
        """Connexions actives"""
        connections = psutil.net_connections(kind='inet')
        
        stats = {
            'total': len(connections),
            'tcp': 0,
            'udp': 0,
            'established': 0,
            'listen': 0
        }
        
        for conn in connections:
            if conn.type == socket.SOCK_STREAM:
                stats['tcp'] += 1
                if conn.status == 'ESTABLISHED':
                    stats['established'] += 1
                elif conn.status == 'LISTEN':
                    stats['listen'] += 1
            elif conn.type == socket.SOCK_DGRAM:
                stats['udp'] += 1
        
        return stats
    
    def get_service_status(self):
        """Status des services"""
        services = ['apache2', 'ssh', 'named']
        status = {}
        
        for service in services:
            try:
                result = subprocess.run(
                    ['systemctl', 'is-active', service],
                    capture_output=True,
                    text=True
                )
                status[service] = result.stdout.strip() == 'active'
            except:
                status[service] = False
        
        return status
    
    def draw_dashboard(self, stdscr):
        """Dessiner le dashboard"""
        curses.curs_set(0)
        stdscr.nodelay(1)
        stdscr.timeout(1000)
        
        last_net = self.get_network_stats()
        last_time = time.time()
        
        while self.running:
            current_time = time.time()
            time_delta = current_time - last_time
            
            stdscr.clear()
            height, width = stdscr.getmaxyx()
            
            # Header
            header = "LABORATOIRE RÉSEAU - DASHBOARD"
            stdscr.addstr(0, (width - len(header)) // 2, header, curses.A_BOLD)
            stdscr.addstr(1, 0, "=" * width)
            
            # Date/Heure
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            stdscr.addstr(2, 2, f"Date: {timestamp}")
            
            # Services
            stdscr.addstr(4, 2, "SERVICES:", curses.A_BOLD)
            services = self.get_service_status()
            y = 5
            for service, active in services.items():
                symbol = "✓" if active else "✗"
                color = curses.color_pair(1) if active else curses.color_pair(2)
                stdscr.addstr(y, 4, f"{symbol} {service}", color)
                y += 1
            
            # Connexions
            stdscr.addstr(y + 1, 2, "CONNEXIONS:", curses.A_BOLD)
            conn_stats = self.get_connections()
            y += 2
            for key, value in conn_stats.items():
                stdscr.addstr(y, 4, f"{key}: {value}")
                y += 1
            
            # Réseau
            current_net = self.get_network_stats()
            
            bytes_sent_rate = (current_net['bytes_sent'] - last_net['bytes_sent']) / time_delta
            bytes_recv_rate = (current_net['bytes_recv'] - last_net['bytes_recv']) / time_delta
            
            stdscr.addstr(y + 1, 2, "RÉSEAU:", curses.A_BOLD)
            y += 2
            stdscr.addstr(y, 4, f"Upload:   {bytes_sent_rate/1024:.2f} KB/s")
            y += 1
            stdscr.addstr(y, 4, f"Download: {bytes_recv_rate/1024:.2f} KB/s")
            y += 1
            stdscr.addstr(y, 4, f"Erreurs:  {current_net['errors']}")
            
            # Footer
            stdscr.addstr(height-2, 0, "=" * width)
            stdscr.addstr(height-1, 2, "Appuyez sur 'q' pour quitter")
            
            stdscr.refresh()
            
            last_net = current_net
            last_time = current_time
            
            # Check pour quitter
            key = stdscr.getch()
            if key == ord('q'):
                self.running = False
    
    def run(self):
        """Lancer le dashboard"""
        curses.wrapper(self.draw_dashboard)

if __name__ == "__main__":
    import socket
    
    # Init colors
    def init_colors():
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)
    
    dashboard = LabDashboard()
    
    try:
        curses.wrapper(lambda stdscr: (init_colors(), dashboard.draw_dashboard(stdscr)))
    except KeyboardInterrupt:
        print("\nDashboard arrêté")
```

---

### Phase 4 : Tests de Performance

```bash
#!/bin/bash
# performance_tests.sh - Suite complète de tests de performance

TARGET="${1:-localhost}"
DURATION=10

echo "=== TESTS DE PERFORMANCE RÉSEAU ==="
echo "Cible: $TARGET"
echo "Durée: ${DURATION}s par test"
echo ""

# 1. Latence ICMP
echo "[1/5] Test de latence ICMP..."
ping -c 100 -i 0.2 $TARGET | tail -2

# 2. Bande passante TCP
echo ""
echo "[2/5] Test bande passante TCP..."
echo "  Démarrez 'iperf3 -s' sur la cible"
read -p "  Appuyez sur Entrée quand prêt..."
iperf3 -c $TARGET -t $DURATION

# 3. Bande passante UDP
echo ""
echo "[3/5] Test bande passante UDP..."
iperf3 -c $TARGET -u -b 100M -t $DURATION

# 4. Latence HTTP
echo ""
echo "[4/5] Test latence HTTP..."
for i in {1..10}; do
    curl -o /dev/null -s -w "%{time_total}\n" http://$TARGET/
done | awk '{sum+=$1; count++} END {print "Latence moyenne: " sum/count*1000 " ms"}'

# 5. MTU Discovery
echo ""
echo "[5/5] Découverte MTU..."
for size in 1472 1500 2000; do
    echo -n "  Taille $size: "
    ping -M do -c 1 -s $size -W 1 $TARGET > /dev/null 2>&1 && echo "OK" || echo "Fragmenté"
done

echo ""
echo "=== Tests terminés ==="
```

---

### Livrables du Projet

1. **Documentation complète** (format Markdown)
   - Architecture du laboratoire
   - Configuration de chaque service
   - Procédures de test

2. **Scripts fonctionnels**
   - Installation automatisée
   - Tests de protocoles
   - Monitoring en temps réel
   - Analyse de performance

3. **Rapport d'analyse**
   - Résultats des tests
   - Métriques de performance
   - Recommandations d'optimisation

4. **Présentation**
   - Démonstration en direct
   - Capture d'écran
   - Analyse des résultats

---

## 📚 RESSOURCES ET RÉFÉRENCES

### Documentation Officielle
- RFC 791 (IP)
- RFC 793 (TCP)
- RFC 768 (UDP)
- RFC 792 (ICMP)
- RFC 2616 (HTTP/1.1)
- RFC 8446 (TLS 1.3)
- RFC 4251-4254 (SSH)

### Outils en Ligne
- Wireshark Wiki: https://wiki.wireshark.org
- tcpdump Manual: https://www.tcpdump.org/manpages/tcpdump.1.html
- Scapy Documentation: https://scapy.readthedocs.io

### Livres Recommandés
- "TCP/IP Illustrated" - W. Richard Stevens
- "Computer Networking: A Top-Down Approach" - Kurose & Ross
- "Practical Packet Analysis" - Chris Sanders

---

## ✅ CHECKLIST FINALE

- [ ] Niveau 0: Fondamentaux maîtrisés
- [ ] Niveau 1: IP et ICMP compris
- [ ] Niveau 2: TCP et UDP maîtrisés
- [ ] Niveau 3: HTTP et HTTPS configurés
- [ ] Niveau 4: SSH sécurisé et utilisé
- [ ] Niveau 5: Analyse avancée réalisée
- [ ] Projet Final: Laboratoire déployé
- [ ] Tous les scripts testés
- [ ] Documentation complète
- [ ] Captures réseau analysées

---

## 🎓 CERTIFICATION

Vous avez maintenant les compétences pour :
- ✅ Comprendre les protocoles réseau en profondeur
- ✅ Analyser le trafic réseau
- ✅ Détecter les anomalies et attaques
- ✅ Optimiser les performances
- ✅ Sécuriser les communications
- ✅ Automatiser l'analyse réseau

**Félicitations !** 🎉

---

**Auteur:** Claude AI  
**Version:** 1.0  
**Date:** 2026  
**Licence:** Éducatif

---

**FIN DU TP COMPLET**
