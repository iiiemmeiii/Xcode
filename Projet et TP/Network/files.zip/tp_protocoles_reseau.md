# TP COMPLET : MAÎTRISE DES PROTOCOLES RÉSEAU
## IP • TCP • UDP • ICMP • HTTP • HTTPS • SSH
### De Zéro à Expert - Apprentissage Progressif

**Durée estimée :** 20-25 heures  
**Système :** Ubuntu 20.04+ (testé sur Ubuntu 22.04)  
**Prérequis :** Connaissances de base en ligne de commande Linux

---

## 📋 TABLE DES MATIÈRES

1. [Niveau 0 - Fondamentaux Réseau](#niveau-0)
2. [Niveau 1 - IP et ICMP](#niveau-1)
3. [Niveau 2 - TCP et UDP](#niveau-2)
4. [Niveau 3 - HTTP et HTTPS](#niveau-3)
5. [Niveau 4 - SSH](#niveau-4)
6. [Niveau 5 - Analyse Avancée](#niveau-5)
7. [Projet Final - Architecture Complète](#projet-final)

---

<a name="niveau-0"></a>
## 🔵 NIVEAU 0 : FONDAMENTAUX RÉSEAU (3-4 heures)

### Objectifs
- Comprendre le modèle OSI et TCP/IP
- Configurer l'environnement de laboratoire
- Maîtriser les outils d'analyse réseau
- Comprendre l'encapsulation des données

---

### Partie 0.1 : Théorie - Modèles OSI et TCP/IP

#### Exercice 0.1.1 : Comprendre les couches réseau

**Modèle OSI (7 couches) :**

```
┌─────────────────────────────────────────┐
│  7. APPLICATION    │ HTTP, SSH, DNS     │ ← Données utilisateur
├────────────────────┼────────────────────┤
│  6. PRÉSENTATION   │ SSL/TLS, JPEG      │ ← Chiffrement, compression
├────────────────────┼────────────────────┤
│  5. SESSION        │ NetBIOS, RPC       │ ← Gestion des sessions
├────────────────────┼────────────────────┤
│  4. TRANSPORT      │ TCP, UDP           │ ← Port source/destination
├────────────────────┼────────────────────┤
│  3. RÉSEAU         │ IP, ICMP           │ ← Adresse IP source/dest
├────────────────────┼────────────────────┤
│  2. LIAISON        │ Ethernet, WiFi     │ ← Adresse MAC
├────────────────────┼────────────────────┤
│  1. PHYSIQUE       │ Câbles, ondes      │ ← Signaux électriques
└─────────────────────────────────────────┘
```

**Modèle TCP/IP (4 couches) :**

```
┌─────────────────────────────────────────┐
│  APPLICATION       │ HTTP, SSH, DNS     │ ← Couches OSI 5-7
├────────────────────┼────────────────────┤
│  TRANSPORT         │ TCP, UDP           │ ← Couche OSI 4
├────────────────────┼────────────────────┤
│  INTERNET          │ IP, ICMP           │ ← Couche OSI 3
├────────────────────┼────────────────────┤
│  ACCÈS RÉSEAU      │ Ethernet, WiFi     │ ← Couches OSI 1-2
└─────────────────────────────────────────┘
```

**Questions de compréhension :**
1. Quelle couche gère l'adressage IP ?
2. À quelle couche opère TCP ?
3. Quelle est la différence entre OSI et TCP/IP ?
4. Pourquoi HTTP est-il à la couche Application ?

---

#### Exercice 0.1.2 : Encapsulation des données

```
DONNÉES UTILISATEUR (ex: "GET /index.html HTTP/1.1")
    ↓
┌───────────────────────────────────────────────────┐
│ En-tête HTTP | Données                            │ ← Couche Application
└───────────────────────────────────────────────────┘
    ↓
┌───────────────────────────────────────────────────┐
│ En-tête TCP | En-tête HTTP | Données              │ ← Couche Transport
└───────────────────────────────────────────────────┘
    ↓
┌───────────────────────────────────────────────────┐
│ En-tête IP | En-tête TCP | En-tête HTTP | Données │ ← Couche Internet
└───────────────────────────────────────────────────┘
    ↓
┌───────────────────────────────────────────────────┐
│ En-tête Ethernet | ... | Trailer Ethernet         │ ← Couche Accès Réseau
└───────────────────────────────────────────────────┘
    ↓
TRANSMISSION SUR LE RÉSEAU (bits)
```

**Terminologie :**
- **Données** (Application) → **Segment** (TCP) → **Paquet** (IP) → **Trame** (Ethernet)
- **PDU** (Protocol Data Unit) : Unité de données à chaque couche
- **MTU** (Maximum Transmission Unit) : Taille maximale d'un paquet (généralement 1500 octets)

---

### Partie 0.2 : Installation des Outils

#### Exercice 0.2.1 : Installation de l'environnement complet

```bash
# Mise à jour du système
sudo apt update && sudo apt upgrade -y

# Outils d'analyse réseau
sudo apt install -y \
    tcpdump \
    wireshark \
    tshark \
    nmap \
    netcat \
    netcat-openbsd \
    socat \
    curl \
    wget \
    iputils-ping \
    traceroute \
    mtr \
    iperf3 \
    net-tools \
    iproute2 \
    dnsutils \
    bind9-utils \
    openssh-server \
    openssh-client \
    apache2 \
    nginx

# Outils de développement
sudo apt install -y \
    python3 \
    python3-pip \
    python3-scapy \
    build-essential \
    git

# Python networking libraries
pip3 install scapy requests paramiko

# Donner les permissions à Wireshark
sudo usermod -aG wireshark $USER
sudo chmod +x /usr/bin/dumpcap

echo "[+] Installation terminée. Redémarrez votre session pour Wireshark."
```

---

#### Exercice 0.2.2 : Vérification de l'installation

```bash
# Vérifier les outils installés
echo "=== Vérification des outils ==="

command -v tcpdump && echo "✓ tcpdump" || echo "✗ tcpdump"
command -v wireshark && echo "✓ wireshark" || echo "✗ wireshark"
command -v tshark && echo "✓ tshark" || echo "✗ tshark"
command -v nmap && echo "✓ nmap" || echo "✗ nmap"
command -v nc && echo "✓ netcat" || echo "✗ netcat"
command -v curl && echo "✓ curl" || echo "✗ curl"
command -v ssh && echo "✓ ssh" || echo "✗ ssh"

# Vérifier Python et Scapy
python3 -c "import scapy; print('✓ Scapy')" 2>/dev/null || echo "✗ Scapy"

# Afficher les interfaces réseau
echo -e "\n=== Interfaces réseau ==="
ip link show

# Afficher la configuration IP
echo -e "\n=== Configuration IP ==="
ip addr show
```

---

### Partie 0.3 : Configuration de l'Environnement de Test

#### Exercice 0.3.1 : Créer un laboratoire réseau virtuel

```bash
#!/bin/bash
# setup_lab.sh - Configuration du laboratoire

echo "[+] Configuration du laboratoire réseau"

# Activer le serveur web Apache
sudo systemctl start apache2
sudo systemctl enable apache2

# Activer SSH
sudo systemctl start ssh
sudo systemctl enable ssh

# Créer une page de test
echo "<h1>Laboratoire Réseau - Test Page</h1>" | sudo tee /var/www/html/test.html

# Configuration du firewall (autoriser tout pour les tests)
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw allow 8080/tcp  # HTTP alternatif

# Vérifier les services
echo -e "\n[+] Services actifs :"
sudo systemctl status apache2 | grep Active
sudo systemctl status ssh | grep Active

# Afficher les informations réseau
echo -e "\n[+] Configuration réseau :"
IP=$(hostname -I | awk '{print $1}')
echo "    Adresse IP : $IP"
echo "    Test HTTP  : http://$IP"
echo "    Test HTTPS : https://$IP (si configuré)"
echo "    Test SSH   : ssh $USER@$IP"

echo -e "\n[+] Laboratoire prêt !"
```

**Exécution :**
```bash
chmod +x setup_lab.sh
./setup_lab.sh
```

---

#### Exercice 0.3.2 : Configuration de capture réseau

```bash
# Trouver l'interface réseau principale
INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)
echo "Interface principale : $INTERFACE"

# Test de capture simple (Ctrl+C pour arrêter)
sudo tcpdump -i $INTERFACE -c 10

# Capture avec filtre
sudo tcpdump -i $INTERFACE 'tcp port 80' -c 5

# Capture dans un fichier
sudo tcpdump -i $INTERFACE -w capture_test.pcap -c 100

# Lire le fichier de capture
tcpdump -r capture_test.pcap

# Analyse avec tshark
tshark -r capture_test.pcap
```

---

### Partie 0.4 : Commandes Réseau Essentielles

#### Exercice 0.4.1 : Diagnostic réseau de base

```bash
# 1. AFFICHER LA CONFIGURATION IP
# Ancienne méthode (ifconfig)
ifconfig

# Nouvelle méthode (ip)
ip addr show
ip a  # Raccourci

# 2. AFFICHER LA TABLE DE ROUTAGE
# Ancienne méthode
route -n
netstat -rn

# Nouvelle méthode
ip route show
ip r  # Raccourci

# 3. AFFICHER LES CONNEXIONS ACTIVES
# Ancienne méthode
netstat -tulpn

# Nouvelle méthode
ss -tulpn

# Détails :
# -t : TCP
# -u : UDP
# -l : Listening (en écoute)
# -p : Process (afficher le processus)
# -n : Numeric (ne pas résoudre les noms)

# 4. AFFICHER LES VOISINS ARP
# Ancienne méthode
arp -a

# Nouvelle méthode
ip neigh show
ip n  # Raccourci

# 5. STATISTIQUES RÉSEAU
netstat -s
ss -s
ip -s link show
```

---

#### Exercice 0.4.2 : Tests de connectivité

```bash
# 1. PING (ICMP)
ping -c 4 8.8.8.8
ping -c 4 google.com

# Options utiles :
ping -c 10 -i 0.2 google.com  # 10 pings, intervalle 0.2s
ping -s 1000 google.com       # Taille du paquet 1000 octets
ping -f google.com            # Flood ping (besoin de root)

# 2. TRACEROUTE
traceroute google.com
traceroute -n google.com      # Sans résolution DNS
traceroute -I google.com      # Utiliser ICMP au lieu d'UDP

# Alternative moderne (mtr)
mtr google.com                # Interactif
mtr -r -c 10 google.com       # Rapport de 10 cycles

# 3. TEST DNS
# Résolution simple
host google.com
nslookup google.com

# Résolution détaillée
dig google.com
dig google.com +short         # Version courte
dig @8.8.8.8 google.com       # Serveur DNS spécifique
dig google.com ANY            # Tous les enregistrements

# 4. TEST TCP/UDP (NETCAT)
# Vérifier si un port est ouvert
nc -zv google.com 80
nc -zv google.com 443

# Scanner une plage de ports
nc -zv google.com 80-100

# Test UDP
nc -zvu 8.8.8.8 53
```

---

#### Exercice 0.4.3 : Analyse des ports locaux

```bash
# Lister tous les ports en écoute
sudo ss -tulpn

# Exemple de sortie :
# Netid  State   Recv-Q Send-Q Local Address:Port  Peer Address:Port
# tcp    LISTEN  0      128    0.0.0.0:22          0.0.0.0:*       users:(("sshd",pid=1234,fd=3))
# tcp    LISTEN  0      128    0.0.0.0:80          0.0.0.0:*       users:(("apache2",pid=5678,fd=4))

# Filtrer par port
sudo ss -tulpn | grep :80
sudo ss -tulpn | grep :22
sudo ss -tulpn | grep :443

# Afficher uniquement TCP
sudo ss -tlpn

# Afficher uniquement UDP
sudo ss -ulpn

# Afficher les connexions établies
sudo ss -tnp

# Script pour analyser les ports
cat << 'EOF' > check_ports.sh
#!/bin/bash
echo "=== Ports en écoute sur cette machine ==="
echo ""
echo "TCP Ports:"
sudo ss -tlpn | awk 'NR>1 {split($4,a,":"); print a[length(a)] "\t" $6}' | sort -n | uniq
echo ""
echo "UDP Ports:"
sudo ss -ulpn | awk 'NR>1 {split($4,a,":"); print a[length(a)] "\t" $6}' | sort -n | uniq
EOF

chmod +x check_ports.sh
./check_ports.sh
```

---

### Partie 0.5 : Introduction à la Capture de Paquets

#### Exercice 0.5.1 : Premier capture avec tcpdump

```bash
# Capturer sur l'interface principale
INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)

# Capture basique (10 paquets)
sudo tcpdump -i $INTERFACE -c 10

# Capture avec timestamp et détails
sudo tcpdump -i $INTERFACE -c 10 -tttt -v

# Options importantes :
# -i : interface
# -c : count (nombre de paquets)
# -n : ne pas résoudre les noms
# -v : verbose
# -vv : très verbose
# -tttt : timestamp lisible
# -X : afficher le contenu en hexa et ASCII
# -w : écrire dans un fichier
# -r : lire depuis un fichier

# Capture avec contenu en hexa
sudo tcpdump -i $INTERFACE -c 3 -XX

# Sauvegarder dans un fichier
sudo tcpdump -i $INTERFACE -w capture.pcap -c 100

# Lire le fichier
tcpdump -r capture.pcap
```

---

#### Exercice 0.5.2 : Filtres de capture tcpdump

```bash
# FILTRES PAR PROTOCOLE
sudo tcpdump -i $INTERFACE icmp           # Seulement ICMP
sudo tcpdump -i $INTERFACE tcp            # Seulement TCP
sudo tcpdump -i $INTERFACE udp            # Seulement UDP
sudo tcpdump -i $INTERFACE ip             # Seulement IP

# FILTRES PAR PORT
sudo tcpdump -i $INTERFACE port 80        # Port 80 (source ou dest)
sudo tcpdump -i $INTERFACE src port 80    # Port source 80
sudo tcpdump -i $INTERFACE dst port 80    # Port destination 80
sudo tcpdump -i $INTERFACE portrange 80-100

# FILTRES PAR HÔTE
sudo tcpdump -i $INTERFACE host 8.8.8.8           # Trafic de/vers 8.8.8.8
sudo tcpdump -i $INTERFACE src host 8.8.8.8       # Source 8.8.8.8
sudo tcpdump -i $INTERFACE dst host 8.8.8.8       # Destination 8.8.8.8

# FILTRES PAR RÉSEAU
sudo tcpdump -i $INTERFACE net 192.168.1.0/24     # Sous-réseau

# COMBINAISONS (AND, OR, NOT)
sudo tcpdump -i $INTERFACE 'tcp and port 80'
sudo tcpdump -i $INTERFACE 'tcp and (port 80 or port 443)'
sudo tcpdump -i $INTERFACE 'tcp and not port 22'
sudo tcpdump -i $INTERFACE 'host 8.8.8.8 and tcp'

# FILTRES AVANCÉS (FLAGS TCP)
sudo tcpdump -i $INTERFACE 'tcp[tcpflags] & tcp-syn != 0'     # Paquets SYN
sudo tcpdump -i $INTERFACE 'tcp[tcpflags] == tcp-syn'         # Seulement SYN
sudo tcpdump -i $INTERFACE 'tcp[tcpflags] & (tcp-syn|tcp-fin) != 0'  # SYN ou FIN
```

---

#### Exercice 0.5.3 : Analyse avec Wireshark/tshark

```bash
# TSHARK (Wireshark en ligne de commande)

# Capture basique
sudo tshark -i $INTERFACE -c 10

# Afficher uniquement certains champs
sudo tshark -i $INTERFACE -c 10 -T fields -e ip.src -e ip.dst -e tcp.port

# Avec filtres d'affichage
sudo tshark -i $INTERFACE -c 100 -Y "http"
sudo tshark -i $INTERFACE -c 100 -Y "tcp.port == 80"
sudo tshark -i $INTERFACE -c 100 -Y "ip.addr == 8.8.8.8"

# Statistiques
tshark -r capture.pcap -q -z io,stat,1  # Stats par seconde
tshark -r capture.pcap -q -z conv,tcp   # Conversations TCP
tshark -r capture.pcap -q -z endpoints,ip  # Endpoints IP

# Export en JSON
sudo tshark -i $INTERFACE -c 10 -T json > capture.json

# WIRESHARK (interface graphique)
# Lancer Wireshark
sudo wireshark &

# Ouvrir un fichier de capture
wireshark capture.pcap &
```

---

### 🎯 QUIZ NIVEAU 0

1. Combien de couches dans le modèle OSI ? Et dans TCP/IP ?
2. À quelle couche OSI opère IP ? Et TCP ?
3. Qu'est-ce que l'encapsulation ?
4. Quelle est la différence entre `ifconfig` et `ip addr` ?
5. Comment capturer uniquement le trafic HTTP avec tcpdump ?
6. Quelle commande moderne remplace `netstat -tulpn` ?
7. Qu'est-ce qu'un PDU ?
8. Quelle est la taille MTU standard d'Ethernet ?

**Commandes à mémoriser (Niveau 0) :**
```bash
ip addr show                              # Configuration IP
ip route show                             # Table de routage
ss -tulpn                                 # Ports en écoute
ping -c 4 <host>                          # Test ICMP
sudo tcpdump -i eth0 -w file.pcap        # Capture réseau
tshark -r file.pcap                       # Analyse capture
dig <domain>                              # Requête DNS
```

---

<a name="niveau-1"></a>
## 🟢 NIVEAU 1 : IP ET ICMP (4-5 heures)

### Objectifs
- Maîtriser le protocole IP (IPv4 et IPv6)
- Comprendre ICMP en profondeur
- Manipuler les en-têtes IP
- Analyser le routage

---

### Partie 1.1 : Protocole IP (Internet Protocol)

#### Exercice 1.1.1 : Structure de l'en-tête IPv4

```
En-tête IPv4 (20 octets minimum, jusqu'à 60 octets avec options)

 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|Version|  IHL  |Type of Service|          Total Length         |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|         Identification        |Flags|      Fragment Offset    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|  Time to Live |    Protocol   |         Header Checksum       |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                       Source Address                          |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Destination Address                        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Options (if IHL > 5)                       |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

Champs importants :
- Version (4 bits)      : 4 pour IPv4, 6 pour IPv6
- IHL (4 bits)          : Internet Header Length (en mots de 32 bits)
- TOS (8 bits)          : Type of Service (QoS)
- Total Length (16 bits): Longueur totale du paquet (en-tête + données)
- TTL (8 bits)          : Time To Live (nombre de sauts maximum)
- Protocol (8 bits)     : Protocole de couche supérieure (1=ICMP, 6=TCP, 17=UDP)
- Source/Dest Address   : Adresses IP 32 bits
```

**Capture et analyse d'un paquet IP :**

```bash
# Générer du trafic ICMP
ping -c 1 8.8.8.8 &

# Capturer avec détails de l'en-tête IP
sudo tcpdump -i any -c 1 icmp -vv

# Exemple de sortie :
# IP (tos 0x0, ttl 64, id 12345, offset 0, flags [DF], proto ICMP (1), length 84)
#     192.168.1.100 > 8.8.8.8: ICMP echo request, id 1234, seq 1, length 64

# Capturer avec contenu hexa pour voir l'en-tête
sudo tcpdump -i any -c 1 icmp -XX | head -20
```

---

#### Exercice 1.1.2 : Adressage IPv4

```bash
#!/bin/bash
# ip_analysis.sh - Analyse d'adressage IPv4

cat << 'EOF'
=== CLASSES D'ADRESSES IPv4 ===

Classe A: 0.0.0.0     - 127.255.255.255  (/8)   - 16M hôtes
Classe B: 128.0.0.0   - 191.255.255.255  (/16)  - 65K hôtes  
Classe C: 192.0.0.0   - 223.255.255.255  (/24)  - 254 hôtes
Classe D: 224.0.0.0   - 239.255.255.255         - Multicast
Classe E: 240.0.0.0   - 255.255.255.255         - Réservé

=== ADRESSES PRIVÉES (RFC 1918) ===

10.0.0.0/8        (10.0.0.0     - 10.255.255.255)
172.16.0.0/12     (172.16.0.0   - 172.31.255.255)
192.168.0.0/16    (192.168.0.0  - 192.168.255.255)

=== ADRESSES SPÉCIALES ===

0.0.0.0/8         - Réseau actuel
127.0.0.0/8       - Loopback (localhost)
169.254.0.0/16    - Link-local (APIPA)
224.0.0.0/4       - Multicast
255.255.255.255   - Broadcast limité
EOF

# Calculateur de sous-réseau
function calculate_network() {
    local ip=$1
    local cidr=$2
    
    echo "IP: $ip/$cidr"
    
    # Utiliser ipcalc si disponible
    if command -v ipcalc &> /dev/null; then
        ipcalc $ip/$cidr
    else
        # Calcul manuel basique
        IFS='.' read -r -a octets <<< "$ip"
        
        case $cidr in
            8)  mask="255.0.0.0" ;;
            16) mask="255.255.0.0" ;;
            24) mask="255.255.255.0" ;;
            *)  mask="Utiliser ipcalc pour ce CIDR" ;;
        esac
        
        echo "Masque: $mask"
    fi
}

# Exemples
echo -e "\n=== EXEMPLES DE CALCUL ==="
calculate_network "192.168.1.100" "24"
echo ""
calculate_network "10.0.0.50" "8"
```

**Installation de ipcalc :**
```bash
sudo apt install ipcalc -y

# Utilisation
ipcalc 192.168.1.100/24
ipcalc 10.0.0.0/8
ipcalc 172.16.0.0/12
```

---

#### Exercice 1.1.3 : Fragmentation IP

```bash
# La fragmentation se produit quand un paquet est plus grand que le MTU

# 1. Vérifier le MTU de l'interface
ip link show | grep mtu

# 2. Envoyer un gros paquet ICMP (sera fragmenté)
# -M do : Don't Fragment (DF) désactivé
# -s : taille des données (1500 = en-tête IP (20) + ICMP (8) + données)
ping -c 1 -s 2000 8.8.8.8

# 3. Capturer pour voir la fragmentation
sudo tcpdump -i any icmp and host 8.8.8.8 -v

# Exemple de sortie avec fragmentation :
# IP (... id 12345, offset 0, flags [+], ...) 192.168.1.100 > 8.8.8.8: ICMP ...
# IP (... id 12345, offset 1480, flags [none], ...) 192.168.1.100 > 8.8.8.8: ip-proto-1
#                 ^^^^ même ID        ^^^^ offset différent

# 4. Tester avec Don't Fragment
ping -c 1 -s 2000 -M do 8.8.8.8
# Devrait afficher : "ping: local error: message too long, mtu=1500"

# 5. Déterminer le MTU du chemin (Path MTU Discovery)
tracepath 8.8.8.8
```

**Script d'analyse de fragmentation :**

```python
#!/usr/bin/env python3
# ip_fragmentation.py - Analyser la fragmentation IP avec Scapy

from scapy.all import *

def create_large_packet():
    """Créer un paquet qui nécessitera fragmentation"""
    # Paquet ICMP avec 3000 octets de données
    ip = IP(dst="8.8.8.8")
    icmp = ICMP()
    data = "X" * 3000
    
    packet = ip/icmp/data
    
    print(f"Taille du paquet : {len(packet)} octets")
    print(f"MTU typique : 1500 octets")
    print(f"Nombre de fragments attendus : {len(packet) // 1480 + 1}")
    
    # Fragmenter et envoyer
    fragments = fragment(packet, fragsize=1480)
    
    print(f"\nNombre de fragments créés : {len(fragments)}")
    
    for i, frag in enumerate(fragments):
        print(f"\nFragment {i+1}:")
        print(f"  Offset: {frag[IP].frag}")
        print(f"  More Fragments (MF): {frag[IP].flags.MF}")
        print(f"  Don't Fragment (DF): {frag[IP].flags.DF}")
        print(f"  Taille: {len(frag)} octets")
        frag.show()

if __name__ == "__main__":
    if os.geteuid() != 0:
        print("Ce script nécessite les privilèges root (sudo)")
        sys.exit(1)
    
    create_large_packet()
```

```bash
chmod +x ip_fragmentation.py
sudo python3 ip_fragmentation.py
```

---

#### Exercice 1.1.4 : Time To Live (TTL)

```bash
# Le TTL est décrémenté à chaque routeur
# Quand TTL=0, le paquet est détruit et un ICMP Time Exceeded est renvoyé

# 1. Observer le TTL par défaut de votre système
ping -c 1 8.8.8.8 | grep ttl

# Systèmes d'exploitation typiques :
# Linux/Unix   : TTL 64
# Windows      : TTL 128
# Cisco/Routeurs: TTL 255

# 2. Modifier le TTL
sudo ping -c 1 -t 1 8.8.8.8   # TTL = 1 (atteindra le 1er routeur)
sudo ping -c 1 -t 5 8.8.8.8   # TTL = 5

# 3. Traceroute utilise le TTL
traceroute 8.8.8.8
# Envoie des paquets avec TTL croissant : 1, 2, 3, ...

# 4. Script pour tester différents TTL
cat << 'EOF' > ttl_test.sh
#!/bin/bash
TARGET="8.8.8.8"
echo "Test TTL vers $TARGET"

for ttl in {1..10}; do
    echo -n "TTL $ttl: "
    result=$(sudo ping -c 1 -t $ttl -W 1 $TARGET 2>&1)
    
    if echo "$result" | grep -q "Time to live exceeded"; then
        echo "Time exceeded"
    elif echo "$result" | grep -q "1 received"; then
        echo "Destination reached"
        break
    else
        echo "No response"
    fi
    sleep 0.5
done
EOF

chmod +x ttl_test.sh
./ttl_test.sh
```

---

### Partie 1.2 : Protocole ICMP (Internet Control Message Protocol)

#### Exercice 1.2.1 : Types de messages ICMP

```
=== MESSAGES ICMP PRINCIPAUX ===

Type 0  - Echo Reply (Réponse ping)
Type 3  - Destination Unreachable
   Code 0: Network Unreachable
   Code 1: Host Unreachable
   Code 2: Protocol Unreachable
   Code 3: Port Unreachable
   Code 4: Fragmentation Needed but DF Set
Type 4  - Source Quench (obsolète, contrôle de flux)
Type 5  - Redirect
Type 8  - Echo Request (Requête ping)
Type 11 - Time Exceeded
   Code 0: TTL Exceeded in Transit
   Code 1: Fragment Reassembly Time Exceeded
Type 13 - Timestamp Request
Type 14 - Timestamp Reply

Format d'un message ICMP :
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|     Type      |     Code      |          Checksum             |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                        Rest of Header                         |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                        Data ...                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

**Capture et analyse ICMP :**

```bash
# 1. Capturer le trafic ICMP
sudo tcpdump -i any icmp -vv -c 10 &
TCPDUMP_PID=$!

# 2. Générer différents types de messages ICMP

# Echo Request/Reply (Type 8/0)
ping -c 2 8.8.8.8

# Time Exceeded (Type 11)
sudo ping -c 1 -t 1 8.8.8.8

# Destination Unreachable (Type 3)
ping -c 1 192.168.255.254  # IP improbable

# Port Unreachable (Type 3, Code 3)
nc -u 8.8.8.8 12345  # UDP vers port fermé

sleep 2
sudo kill $TCPDUMP_PID 2>/dev/null
```

---

#### Exercice 1.2.2 : Ping en profondeur

```bash
# OPTIONS PING AVANCÉES

# 1. Intervalle entre pings
ping -c 10 -i 0.2 8.8.8.8  # Toutes les 0.2 secondes

# 2. Taille du paquet
ping -c 3 -s 100 8.8.8.8   # 100 octets de données
ping -c 3 -s 1000 8.8.8.8  # 1000 octets
ping -c 3 -s 1472 8.8.8.8  # Maximum sans fragmentation (1500 - 20 IP - 8 ICMP)

# 3. Pattern de données
ping -c 3 -p ff 8.8.8.8    # Remplir avec 0xff
ping -c 3 -p deadbeef 8.8.8.8  # Pattern personnalisé

# 4. Timeout
ping -c 3 -W 1 8.8.8.8     # Timeout de 1 seconde

# 5. Flood ping (nécessite root)
sudo ping -f 8.8.8.8       # Envoyer le plus rapidement possible

# 6. Ping vers broadcast (vérifier si autorisé)
ping -c 3 -b 192.168.1.255

# 7. Timestamp
ping -c 3 -D 8.8.8.8       # Afficher timestamp Unix

# 8. Verbose
ping -c 3 -v 8.8.8.8

# 9. Ne pas router (seulement réseau local)
ping -c 3 -r 8.8.8.8

# 10. Spécifier interface source
ping -c 3 -I eth0 8.8.8.8
```

**Script d'analyse de latence :**

```bash
#!/bin/bash
# latency_monitor.sh - Monitorer la latence réseau

TARGET="${1:-8.8.8.8}"
COUNT=100
INTERVAL=0.2

echo "Monitoring latency to $TARGET (${COUNT} pings)"
echo "========================================"

# Lancer ping et sauvegarder résultats
ping -c $COUNT -i $INTERVAL $TARGET | tee ping_results.txt | \
    grep 'time=' | \
    awk '{print $7}' | \
    cut -d= -f2 > latencies.txt

# Calculer les statistiques
if [ -s latencies.txt ]; then
    python3 << 'PYTHON'
import statistics

with open('latencies.txt', 'r') as f:
    latencies = [float(line.strip()) for line in f if line.strip()]

if latencies:
    print(f"\n=== STATISTIQUES ===")
    print(f"Min:    {min(latencies):.2f} ms")
    print(f"Max:    {max(latencies):.2f} ms")
    print(f"Moyen:  {statistics.mean(latencies):.2f} ms")
    print(f"Médian: {statistics.median(latencies):.2f} ms")
    print(f"Écart-type: {statistics.stdev(latencies):.2f} ms")
    
    # Détection des anomalies (>2 écarts-types)
    mean = statistics.mean(latencies)
    stdev = statistics.stdev(latencies)
    threshold = mean + 2 * stdev
    anomalies = [l for l in latencies if l > threshold]
    
    if anomalies:
        print(f"\nAnomalies détectées: {len(anomalies)} pings > {threshold:.2f} ms")
PYTHON
fi

rm -f latencies.txt ping_results.txt
```

```bash
chmod +x latency_monitor.sh
./latency_monitor.sh 8.8.8.8
```

---

#### Exercice 1.2.3 : Création de paquets ICMP personnalisés

```python
#!/usr/bin/env python3
# custom_icmp.py - Créer et envoyer des paquets ICMP personnalisés

from scapy.all import *
import sys

def send_echo_request(target, count=4):
    """Envoyer des requêtes ICMP Echo (ping)"""
    print(f"Envoi de {count} pings vers {target}")
    
    for i in range(count):
        # Créer le paquet ICMP
        packet = IP(dst=target)/ICMP(type=8, code=0, id=12345, seq=i)
        
        # Envoyer et attendre réponse
        reply = sr1(packet, timeout=2, verbose=0)
        
        if reply:
            print(f"Reply from {reply.src}: icmp_seq={i} ttl={reply.ttl} time={reply.time*1000:.2f}ms")
        else:
            print(f"Request timeout for icmp_seq {i}")

def send_timestamp_request(target):
    """Envoyer une requête ICMP Timestamp"""
    print(f"\nEnvoi Timestamp Request vers {target}")
    
    # ICMP Type 13 - Timestamp Request
    packet = IP(dst=target)/ICMP(type=13, code=0)
    reply = sr1(packet, timeout=2, verbose=0)
    
    if reply and reply.haslayer(ICMP):
        print(f"Timestamp Reply reçu de {reply.src}")
        reply.show()
    else:
        print("Pas de réponse")

def send_unreachable(target_ip, target_port):
    """Simuler un ICMP Destination Unreachable"""
    print(f"\nEnvoi ICMP Unreachable pour {target_ip}:{target_port}")
    
    # Créer un paquet UDP original (simulé)
    original_packet = IP(dst=target_ip)/UDP(dport=target_port)/"Test data"
    
    # ICMP Type 3, Code 3 - Port Unreachable
    icmp_packet = IP(dst=target_ip)/ICMP(type=3, code=3)/original_packet
    
    send(icmp_packet, verbose=1)

def icmp_tunnel_demo():
    """Démonstration de tunneling via ICMP (données dans payload)"""
    print("\n=== Démonstration ICMP Tunneling ===")
    
    target = "8.8.8.8"
    secret_data = "This is secret data hidden in ICMP!"
    
    # Créer un paquet ICMP avec des données personnalisées
    packet = IP(dst=target)/ICMP()/secret_data
    
    print(f"Envoi de données cachées dans ICMP vers {target}")
    reply = sr1(packet, timeout=2, verbose=0)
    
    if reply:
        print("Réponse reçue :")
        reply.show()

def main():
    if os.geteuid() != 0:
        print("Ce script nécessite les privilèges root (sudo)")
        sys.exit(1)
    
    target = "8.8.8.8"
    
    # Test 1: Echo Request classique
    send_echo_request(target, count=4)
    
    # Test 2: Timestamp Request
    send_timestamp_request(target)
    
    # Test 3: Démonstration tunneling
    icmp_tunnel_demo()

if __name__ == "__main__":
    main()
```

```bash
chmod +x custom_icmp.py
sudo python3 custom_icmp.py
```

---

#### Exercice 1.2.4 : Détecter le filtrage ICMP

```bash
#!/bin/bash
# icmp_filter_detection.sh - Détecter le filtrage ICMP

TARGET="${1:-8.8.8.8}"

echo "=== Détection de filtrage ICMP sur $TARGET ==="
echo ""

# Test 1: ICMP Echo (Type 8)
echo "[Test 1] ICMP Echo Request (ping)"
if ping -c 2 -W 2 $TARGET &> /dev/null; then
    echo "✓ ICMP Echo autorisé"
else
    echo "✗ ICMP Echo bloqué ou hôte injoignable"
fi

# Test 2: ICMP Timestamp
echo ""
echo "[Test 2] ICMP Timestamp Request"
sudo hping3 --icmp --icmptype 13 -c 2 $TARGET &> /dev/null
if [ $? -eq 0 ]; then
    echo "✓ ICMP Timestamp autorisé"
else
    echo "✗ ICMP Timestamp bloqué (ou hping3 non installé)"
fi

# Test 3: Grande taille ICMP
echo ""
echo "[Test 3] ICMP avec grande payload (1400 octets)"
if ping -c 2 -s 1400 -W 2 $TARGET &> /dev/null; then
    echo "✓ Grands paquets ICMP autorisés"
else
    echo "✗ Grands paquets ICMP bloqués"
fi

# Test 4: Fréquence élevée
echo ""
echo "[Test 4] ICMP à haute fréquence"
if ping -c 10 -i 0.1 -W 2 $TARGET &> /dev/null; then
    echo "✓ Haute fréquence ICMP autorisée"
else
    echo "✗ Limitation de débit ICMP (rate limiting)"
fi

echo ""
echo "=== Analyse terminée ==="
```

---

### Partie 1.3 : IPv6

#### Exercice 1.3.1 : Introduction à IPv6

```
=== DIFFÉRENCES IPv4 vs IPv6 ===

IPv4:
- Adresse: 32 bits (4 octets)
- Format: 192.168.1.1 (notation décimale pointée)
- En-tête: 20-60 octets (variable avec options)
- Adresses: ~4.3 milliards

IPv6:
- Adresse: 128 bits (16 octets)
- Format: 2001:0db8:0000:0000:0000:ff00:0042:8329 (notation hexadécimale)
- En-tête: 40 octets (fixe)
- Adresses: 340 undécillions (3.4×10³⁸)

=== FORMAT ADRESSE IPv6 ===

Complète: 2001:0db8:0000:0000:0000:ff00:0042:8329

Règles de compression:
1. Supprimer les zéros de tête: 2001:db8:0:0:0:ff00:42:8329
2. Remplacer séquence de zéros par :: (une seule fois)
   2001:db8::ff00:42:8329

Adresses spéciales:
::1                 - Loopback (équivalent de 127.0.0.1)
::                  - Adresse non spécifiée
fe80::/10           - Link-local (auto-configuration)
ff00::/8            - Multicast
2000::/3            - Global unicast
```

**Configuration et test IPv6 :**

```bash
# Vérifier si IPv6 est activé
ip -6 addr show

# Afficher la table de routage IPv6
ip -6 route show

# Ping IPv6 localhost
ping6 ::1

# Ping IPv6 Google
ping6 2001:4860:4860::8888

# Traceroute IPv6
traceroute6 2001:4860:4860::8888

# DNS lookup IPv6 (AAAA record)
dig AAAA google.com
dig AAAA google.com +short

# Test de connectivité IPv6 web
curl -6 https://ipv6.google.com

# Vérifier votre adresse IPv6 publique
curl -6 https://api64.ipify.org
```

---

#### Exercice 1.3.2 : Capture et analyse IPv6

```bash
# Capturer le trafic IPv6
sudo tcpdump -i any ip6 -c 10 -vv

# Capturer ICMPv6
sudo tcpdump -i any icmp6 -c 10 -vv

# Générer du trafic IPv6 pendant la capture
ping6 -c 3 ::1 &
ping6 -c 3 2001:4860:4860::8888 &

# Analyse avec tshark
sudo tshark -i any -f "ip6" -c 10

# Filtres IPv6 avancés
sudo tcpdump -i any 'ip6 and tcp and port 80' -c 5
sudo tcpdump -i any 'icmp6' -c 5
```

**Script d'analyse IPv6 :**

```python
#!/usr/bin/env python3
# ipv6_analysis.py - Analyser les adresses IPv6

import ipaddress
import sys

def analyze_ipv6(addr_str):
    """Analyser une adresse IPv6"""
    try:
        addr = ipaddress.IPv6Address(addr_str)
        
        print(f"Adresse: {addr}")
        print(f"Compressée: {addr.compressed}")
        print(f"Exploded: {addr.exploded}")
        print(f"\nType:")
        
        if addr.is_loopback:
            print("  - Loopback (::1)")
        if addr.is_link_local:
            print("  - Link-local (fe80::/10)")
        if addr.is_multicast:
            print("  - Multicast (ff00::/8)")
        if addr.is_private:
            print("  - Privée")
        if addr.is_global:
            print("  - Global unicast")
        if addr.is_reserved:
            print("  - Réservée")
        if addr.is_unspecified:
            print("  - Non spécifiée (::)")
            
    except ValueError as e:
        print(f"Erreur: {e}")

def analyze_ipv6_network(network_str):
    """Analyser un réseau IPv6"""
    try:
        network = ipaddress.IPv6Network(network_str, strict=False)
        
        print(f"\nRéseau: {network}")
        print(f"Préfixe: /{network.prefixlen}")
        print(f"Adresse réseau: {network.network_address}")
        print(f"Masque: {network.netmask}")
        print(f"Nombre d'adresses: {network.num_addresses}")
        print(f"Première adresse: {network.network_address}")
        print(f"Dernière adresse: {network.broadcast_address}")
        
    except ValueError as e:
        print(f"Erreur: {e}")

if __name__ == "__main__":
    # Exemples
    print("=== ANALYSE ADRESSE IPv6 ===")
    analyze_ipv6("2001:db8::ff00:42:8329")
    
    print("\n" + "="*50)
    analyze_ipv6("fe80::1")
    
    print("\n" + "="*50)
    analyze_ipv6("::1")
    
    print("\n" + "="*50)
    print("=== ANALYSE RÉSEAU IPv6 ===")
    analyze_ipv6_network("2001:db8::/32")
```

```bash
chmod +x ipv6_analysis.py
python3 ipv6_analysis.py
```

---

### 🎯 QUIZ NIVEAU 1

1. Quelle est la taille de l'en-tête IPv4 minimum ? Et maximum ?
2. Que signifie TTL ? Que se passe-t-il quand TTL=0 ?
3. Quel protocole utilise ICMP Type 8 et Type 0 ?
4. Qu'est-ce que la fragmentation IP ? Quand se produit-elle ?
5. Quelle est la différence entre IPv4 et IPv6 ?
6. Comment s'appelle ::1 en IPv6 ?
7. Quel message ICMP renvoie traceroute ?
8. Quelle est la taille MTU standard d'Ethernet ?

**Commandes à mémoriser (Niveau 1) :**
```bash
ping -c 4 <host>                          # Test ICMP
ping -s 1472 <host>                       # Taille max sans fragmentation
sudo ping -t 5 <host>                     # TTL personnalisé
traceroute <host>                         # Tracer la route
ip addr show                              # Config IPv4/IPv6
ping6 <ipv6>                              # Ping IPv6
sudo tcpdump -i any icmp -vv             # Capture ICMP
```

---

<a name="niveau-2"></a>
## 🟡 NIVEAU 2 : TCP ET UDP (5-6 heures)

### Objectifs
- Maîtriser TCP : connexion, flags, contrôle de flux
- Comprendre UDP et ses cas d'usage
- Analyser les sessions TCP
- Manipuler les ports et les sockets

---

### Partie 2.1 : Protocole TCP (Transmission Control Protocol)

#### Exercice 2.1.1 : Structure de l'en-tête TCP

```
En-tête TCP (20 octets minimum, jusqu'à 60 octets avec options)

 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|          Source Port          |       Destination Port        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                        Sequence Number                        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Acknowledgment Number                      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
| Offset| Res |     Flags     |            Window             |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|           Checksum            |         Urgent Pointer        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Options (if offset > 5)                    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

Champs importants:
- Source/Dest Port (16 bits): Ports source et destination
- Sequence Number (32 bits): Numéro de séquence
- Acknowledgment (32 bits): Numéro d'acquittement
- Flags (9 bits):
    URG: Urgent pointer field significant
    ACK: Acknowledgment field significant
    PSH: Push function
    RST: Reset the connection
    SYN: Synchronize sequence numbers
    FIN: No more data from sender
- Window (16 bits): Taille de la fenêtre pour contrôle de flux
```

---

#### Exercice 2.1.2 : Three-Way Handshake (établissement de connexion)

```
=== TCP THREE-WAY HANDSHAKE ===

Client                                Server
  |                                     |
  |  SYN (seq=x)                        |
  |------------------------------------>|  1. Client envoie SYN
  |                                     |
  |           SYN-ACK (seq=y, ack=x+1) |
  |<------------------------------------|  2. Serveur répond SYN-ACK
  |                                     |
  |  ACK (seq=x+1, ack=y+1)            |
  |------------------------------------>|  3. Client envoie ACK
  |                                     |
  |     CONNECTION ESTABLISHED          |
  |<----------------------------------->|
```

**Observation du handshake :**

```bash
# Terminal 1: Capture
sudo tcpdump -i any 'tcp port 8080' -nn -vv &
TCPDUMP_PID=$!

# Terminal 2: Créer un serveur simple
nc -l 8080 &
SERVER_PID=$!

# Terminal 3: Se connecter
sleep 1
nc localhost 8080 &
CLIENT_PID=$!

# Attendre un peu pour voir les échanges
sleep 2

# Observer les paquets capturés :
# 1. [S] SYN du client
# 2. [S.] SYN-ACK du serveur  
# 3. [.] ACK du client
# 4. [.] ACK des données échangées
# 5. [F.] FIN quand on ferme
# 6. [.] ACK final

# Nettoyer
sudo kill $TCPDUMP_PID $SERVER_PID $CLIENT_PID 2>/dev/null
```

**Script d'analyse du handshake :**

```python
#!/usr/bin/env python3
# tcp_handshake.py - Simuler et analyser le TCP handshake

from scapy.all import *
import sys

def perform_handshake(target_ip, target_port):
    """Effectuer un TCP handshake manuel avec Scapy"""
    
    print(f"=== TCP Three-Way Handshake vers {target_ip}:{target_port} ===\n")
    
    # Choisir un port source aléatoire
    src_port = RandShort()
    
    # Étape 1: Envoyer SYN
    print("[1] Envoi SYN...")
    ip = IP(dst=target_ip)
    syn = TCP(sport=src_port, dport=target_port, flags='S', seq=1000)
    syn_ack = sr1(ip/syn, timeout=2, verbose=0)
    
    if not syn_ack:
        print("✗ Pas de réponse (port filtré ou hôte injoignable)")
        return False
    
    if syn_ack.haslayer(TCP):
        if syn_ack[TCP].flags == 'SA':  # SYN-ACK
            print(f"✓ SYN-ACK reçu (seq={syn_ack[TCP].seq}, ack={syn_ack[TCP].ack})")
            
            # Étape 2: Envoyer ACK
            print("[2] Envoi ACK...")
            ack = TCP(sport=src_port, dport=target_port, flags='A', 
                     seq=syn_ack[TCP].ack, ack=syn_ack[TCP].seq + 1)
            send(ip/ack, verbose=0)
            print("✓ ACK envoyé - Connexion établie!")
            
            # Étape 3: Envoyer FIN pour fermer proprement
            print("[3] Envoi FIN pour fermer...")
            fin = TCP(sport=src_port, dport=target_port, flags='FA',
                     seq=syn_ack[TCP].ack, ack=syn_ack[TCP].seq + 1)
            send(ip/fin, verbose=0)
            print("✓ FIN envoyé - Connexion fermée")
            
            return True
            
        elif syn_ack[TCP].flags == 'RA':  # RST-ACK
            print("✗ RST-ACK reçu (port fermé)")
            return False
    
    return False

def scan_port_with_syn(target_ip, port):
    """Scanner un port avec SYN (SYN scan)"""
    ip = IP(dst=target_ip)
    syn = TCP(sport=RandShort(), dport=port, flags='S')
    
    response = sr1(ip/syn, timeout=1, verbose=0)
    
    if not response:
        return "filtered"
    elif response.haslayer(TCP):
        if response[TCP].flags == 'SA':
            # Envoyer RST pour ne pas compléter le handshake
            rst = TCP(sport=syn.sport, dport=port, flags='R', seq=response[TCP].ack)
            send(ip/rst, verbose=0)
            return "open"
        elif response[TCP].flags == 'RA':
            return "closed"
    elif response.haslayer(ICMP):
        return "filtered"
    
    return "unknown"

def main():
    if os.geteuid() != 0:
        print("Ce script nécessite les privilèges root (sudo)")
        sys.exit(1)
    
    # Test 1: Handshake complet
    target_ip = "localhost"
    target_port = 80
    
    print("Test 1: Handshake complet\n")
    perform_handshake(target_ip, target_port)
    
    # Test 2: Scan de ports
    print("\n" + "="*60)
    print("Test 2: Scan de ports avec SYN\n")
    
    ports = [22, 80, 443, 8080, 9999]
    for port in ports:
        status = scan_port_with_syn(target_ip, port)
        print(f"Port {port}: {status}")

if __name__ == "__main__":
    main()
```

```bash
chmod +x tcp_handshake.py
sudo python3 tcp_handshake.py
```

---

#### Exercice 2.1.3 : Flags TCP en détail

```bash
# FLAGS TCP:
# SYN (S): Synchronisation - établir connexion
# ACK (A): Acquittement
# FIN (F): Terminer connexion
# RST (R): Reset - fermeture brutale
# PSH (P): Push - envoyer immédiatement
# URG (U): Urgent

# Capturer et voir les flags
sudo tcpdump -i any 'tcp' -nn -c 20 | grep Flags

# Filtres tcpdump pour flags spécifiques:
sudo tcpdump -i any 'tcp[tcpflags] & tcp-syn != 0'      # SYN
sudo tcpdump -i any 'tcp[tcpflags] == tcp-syn'          # Seulement SYN
sudo tcpdump -i any 'tcp[tcpflags] & tcp-fin != 0'      # FIN
sudo tcpdump -i any 'tcp[tcpflags] & tcp-rst != 0'      # RST
sudo tcpdump -i any 'tcp[tcpflags] & (tcp-syn|tcp-fin) != 0'  # SYN ou FIN
```

**Générateur de paquets avec différents flags :**

```python
#!/usr/bin/env python3
# tcp_flags.py - Envoyer des paquets TCP avec différents flags

from scapy.all import *
import sys

def send_syn(target, port):
    """Envoyer un paquet SYN"""
    print(f"Envoi SYN vers {target}:{port}")
    ip = IP(dst=target)
    syn = TCP(sport=RandShort(), dport=port, flags='S', seq=1000)
    response = sr1(ip/syn, timeout=2, verbose=0)
    
    if response:
        print(f"  Réponse: Flags={response[TCP].flags}")
    else:
        print("  Pas de réponse")

def send_fin(target, port):
    """Envoyer un paquet FIN"""
    print(f"Envoi FIN vers {target}:{port}")
    ip = IP(dst=target)
    fin = TCP(sport=RandShort(), dport=port, flags='F')
    response = sr1(ip/fin, timeout=2, verbose=0)
    
    if response:
        print(f"  Réponse: Flags={response[TCP].flags}")
    else:
        print("  Pas de réponse")

def send_xmas(target, port):
    """Envoyer un paquet Xmas (FIN, PSH, URG)"""
    print(f"Envoi Xmas vers {target}:{port}")
    ip = IP(dst=target)
    xmas = TCP(sport=RandShort(), dport=port, flags='FPU')
    response = sr1(ip/xmas, timeout=2, verbose=0)
    
    if response:
        print(f"  Réponse: Flags={response[TCP].flags}")
    else:
        print("  Pas de réponse")

def send_null(target, port):
    """Envoyer un paquet Null (aucun flag)"""
    print(f"Envoi Null vers {target}:{port}")
    ip = IP(dst=target)
    null = TCP(sport=RandShort(), dport=port, flags='')
    response = sr1(ip/null, timeout=2, verbose=0)
    
    if response:
        print(f"  Réponse: Flags={response[TCP].flags}")
    else:
        print("  Pas de réponse")

def send_rst(target, port):
    """Envoyer un paquet RST"""
    print(f"Envoi RST vers {target}:{port}")
    ip = IP(dst=target)
    rst = TCP(sport=RandShort(), dport=port, flags='R', seq=1000)
    send(ip/rst, verbose=0)
    print("  RST envoyé (pas de réponse attendue)")

def main():
    if os.geteuid() != 0:
        print("Ce script nécessite les privilèges root (sudo)")
        sys.exit(1)
    
    target = "localhost"
    port = 80
    
    print(f"=== Test des flags TCP sur {target}:{port} ===\n")
    
    send_syn(target, port)
    print()
    send_fin(target, port)
    print()
    send_xmas(target, port)
    print()
    send_null(target, port)
    print()
    send_rst(target, port)

if __name__ == "__main__":
    main()
```

```bash
chmod +x tcp_flags.py
sudo python3 tcp_flags.py
```

---

#### Exercice 2.1.4 : Fermeture de connexion TCP

```
=== TCP CONNECTION TERMINATION (Four-Way Handshake) ===

Client                                Server
  |                                     |
  |  FIN (seq=x)                        |
  |------------------------------------>|  1. Client envoie FIN
  |                                     |
  |           ACK (ack=x+1)             |
  |<------------------------------------|  2. Serveur acquitte
  |                                     |
  |           FIN (seq=y)               |
  |<------------------------------------|  3. Serveur envoie FIN
  |                                     |
  |  ACK (ack=y+1)                      |
  |------------------------------------>|  4. Client acquitte
  |                                     |
  |     CONNECTION CLOSED               |
  |                                     |

Alternative: Reset (RST)
  |  RST                                |
  |------------------------------------>|  Fermeture brutale
  |     CONNECTION CLOSED               |
```

**Observer la fermeture :**

```bash
# Capturer la fermeture de connexion
sudo tcpdump -i any 'tcp port 8080' -nn -vv &
TCPDUMP_PID=$!

# Créer une connexion et la fermer
nc -l 8080 &
SERVER_PID=$!
sleep 1

echo "Test" | nc localhost 8080
# Observer les paquets FIN et ACK

sleep 2
sudo kill $TCPDUMP_PID $SERVER_PID 2>/dev/null
```

---

#### Exercice 2.1.5 : Numéros de séquence et acquittement

```bash
# Les numéros de séquence TCP permettent:
# - L'ordre des paquets
# - La détection de paquets perdus
# - La retransmission

# Visualiser les numéros de séquence
sudo tcpdump -i any 'tcp port 80' -nn -S -vv

# Options importantes:
# -S : Afficher les numéros de séquence absolus (au lieu de relatifs)

# Créer une connexion et envoyer des données
cat << 'EOF' > tcp_seq_test.sh
#!/bin/bash

# Démarrer capture
sudo tcpdump -i lo 'tcp port 8080' -nn -S -w tcp_seq.pcap &
TCPDUMP_PID=$!

# Serveur
nc -l 8080 > received.txt &
SERVER_PID=$!

sleep 1

# Client envoie des données
echo "Message 1" | nc localhost 8080 &
sleep 0.5
echo "Message 2" | nc localhost 8080 &
sleep 0.5
echo "Message 3" | nc localhost 8080 &

sleep 2

# Arrêter
sudo kill $TCPDUMP_PID $SERVER_PID 2>/dev/null
killall nc 2>/dev/null

# Analyser
echo "=== Analyse des numéros de séquence ==="
tcpdump -r tcp_seq.pcap -nn -S | grep 8080

# Nettoyer
rm -f tcp_seq.pcap received.txt
EOF

chmod +x tcp_seq_test.sh
./tcp_seq_test.sh
```

---

#### Exercice 2.1.6 : Fenêtre TCP (Window) et contrôle de flux

```bash
# La fenêtre TCP indique combien de données peuvent être envoyées
# avant d'attendre un ACK (contrôle de flux)

# Observer la taille de fenêtre
sudo tcpdump -i any 'tcp port 80' -nn -vv | grep -i window

# Tester avec transfert de gros fichier
cat << 'EOF' > tcp_window_test.sh
#!/bin/bash

echo "=== Test de la fenêtre TCP ==="

# Créer un gros fichier
dd if=/dev/zero of=test_file bs=1M count=10 2>/dev/null

# Capturer pendant le transfert
sudo tcpdump -i lo 'tcp port 8080' -nn -c 100 -w tcp_window.pcap &
TCPDUMP_PID=$!

# Serveur netcat
nc -l 8080 > /dev/null &
SERVER_PID=$!

sleep 1

# Client envoie le fichier
nc localhost 8080 < test_file

sleep 2

# Arrêter
sudo kill $TCPDUMP_PID $SERVER_PID 2>/dev/null

# Analyser les fenêtres
echo ""
echo "=== Tailles de fenêtre observées ==="
tshark -r tcp_window.pcap -T fields -e tcp.window_size_value | \
    sort -n | uniq -c | tail -10

# Statistiques détaillées
echo ""
echo "=== Statistiques TCP ==="
tshark -r tcp_window.pcap -q -z io,stat,1,"tcp.window_size_value"

# Nettoyer
rm -f test_file tcp_window.pcap
killall nc 2>/dev/null
EOF

chmod +x tcp_window_test.sh
./tcp_window_test.sh
```

---

### Partie 2.2 : Protocole UDP (User Datagram Protocol)

#### Exercice 2.2.1 : Structure de l'en-tête UDP

```
En-tête UDP (8 octets - beaucoup plus simple que TCP!)

 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|          Source Port          |       Destination Port        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|            Length             |           Checksum            |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                          Data ...                             |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

Caractéristiques UDP:
- Sans connexion (pas de handshake)
- Pas de garantie de livraison
- Pas d'ordre garanti
- Pas de contrôle de flux
- Overhead minimal (8 octets vs 20+ pour TCP)

Cas d'usage:
- DNS (port 53)
- DHCP (ports 67/68)
- Streaming vidéo/audio
- Jeux en ligne
- VoIP
- SNMP (port 161/162)
- Syslog (port 514)
```

---

#### Exercice 2.2.2 : Communication UDP basique

```bash
# UDP avec netcat

# Terminal 1: Serveur UDP
nc -u -l 9999

# Terminal 2: Client UDP
nc -u localhost 9999

# Tapez des messages dans chaque terminal
# Remarquez: pas de handshake, communication immédiate

# Capturer le trafic UDP
sudo tcpdump -i lo 'udp port 9999' -nn -vv -X
```

**Script d'envoi/réception UDP :**

```python
#!/usr/bin/env python3
# udp_communication.py - Serveur et client UDP

import socket
import threading
import sys

def udp_server(port):
    """Serveur UDP simple"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('0.0.0.0', port))
    
    print(f"[Serveur] Écoute sur UDP port {port}")
    
    try:
        while True:
            data, addr = sock.recvfrom(1024)
            print(f"[Serveur] Reçu de {addr}: {data.decode()}")
            
            # Répondre
            response = f"Echo: {data.decode()}"
            sock.sendto(response.encode(), addr)
    except KeyboardInterrupt:
        print("\n[Serveur] Arrêt")
    finally:
        sock.close()

def udp_client(host, port, message):
    """Client UDP simple"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    try:
        # Envoyer
        print(f"[Client] Envoi vers {host}:{port}: {message}")
        sock.sendto(message.encode(), (host, port))
        
        # Recevoir réponse
        sock.settimeout(2)
        data, addr = sock.recvfrom(1024)
        print(f"[Client] Réponse de {addr}: {data.decode()}")
    except socket.timeout:
        print("[Client] Timeout - pas de réponse")
    finally:
        sock.close()

def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print(f"  Serveur: {sys.argv[0]} server <port>")
        print(f"  Client:  {sys.argv[0]} client <host> <port> <message>")
        sys.exit(1)
    
    mode = sys.argv[1]
    
    if mode == "server":
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 9999
        udp_server(port)
    elif mode == "client":
        host = sys.argv[2] if len(sys.argv) > 2 else "localhost"
        port = int(sys.argv[3]) if len(sys.argv) > 3 else 9999
        message = " ".join(sys.argv[4:]) if len(sys.argv) > 4 else "Hello UDP!"
        udp_client(host, port, message)
    else:
        print("Mode invalide. Utilisez 'server' ou 'client'")

if __name__ == "__main__":
    main()
```

**Utilisation :**
```bash
chmod +x udp_communication.py

# Terminal 1: Serveur
python3 udp_communication.py server 9999

# Terminal 2: Client
python3 udp_communication.py client localhost 9999 "Test message"
```

---

#### Exercice 2.2.3 : UDP vs TCP - Comparaison pratique

```bash
#!/bin/bash
# tcp_vs_udp_comparison.sh - Comparer performances TCP vs UDP

PORT=9999
FILE_SIZE=10M

echo "=== Comparaison TCP vs UDP ==="

# Créer un fichier de test
echo "[+] Création fichier de test (${FILE_SIZE})..."
dd if=/dev/urandom of=test_file bs=1M count=10 2>/dev/null

# Test TCP
echo ""
echo "[+] Test TCP..."
nc -l $PORT > /dev/null &
SERVER_PID=$!
sleep 1

START=$(date +%s.%N)
nc localhost $PORT < test_file
END=$(date +%s.%N)
TCP_TIME=$(echo "$END - $START" | bc)

kill $SERVER_PID 2>/dev/null
echo "  Temps TCP: ${TCP_TIME}s"

# Test UDP
echo ""
echo "[+] Test UDP..."
nc -u -l $PORT > /dev/null &
SERVER_PID=$!
sleep 1

START=$(date +%s.%N)
nc -u localhost $PORT < test_file
END=$(date +%s.%N)
UDP_TIME=$(echo "$END - $START" | bc)

kill $SERVER_PID 2>/dev/null
echo "  Temps UDP: ${UDP_TIME}s"

# Comparaison
echo ""
echo "=== Résultats ==="
echo "TCP: ${TCP_TIME}s"
echo "UDP: ${UDP_TIME}s"
echo ""
echo "Note: UDP est plus rapide mais peut perdre des paquets"

# Nettoyer
rm -f test_file
killall nc 2>/dev/null
```

---

#### Exercice 2.2.4 : Perte de paquets UDP

```python
#!/usr/bin/env python3
# udp_packet_loss.py - Simuler et mesurer la perte de paquets UDP

import socket
import time
import threading

def udp_sender(host, port, num_packets, delay=0.01):
    """Envoyer des paquets UDP numérotés"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    print(f"Envoi de {num_packets} paquets UDP vers {host}:{port}")
    
    for i in range(num_packets):
        message = f"Packet {i}"
        sock.sendto(message.encode(), (host, port))
        time.sleep(delay)
    
    # Message de fin
    sock.sendto(b"END", (host, port))
    sock.close()
    print("Envoi terminé")

def udp_receiver(port, expected_packets):
    """Recevoir et compter les paquets UDP"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('0.0.0.0', port))
    sock.settimeout(5)
    
    print(f"Réception sur port {port}")
    
    received = []
    
    try:
        while True:
            data, addr = sock.recvfrom(1024)
            msg = data.decode()
            
            if msg == "END":
                break
            
            if msg.startswith("Packet"):
                packet_num = int(msg.split()[1])
                received.append(packet_num)
    except socket.timeout:
        print("Timeout")
    finally:
        sock.close()
    
    # Analyser les pertes
    received.sort()
    expected = set(range(expected_packets))
    lost = expected - set(received)
    
    print(f"\n=== Résultats ===")
    print(f"Paquets attendus: {expected_packets}")
    print(f"Paquets reçus: {len(received)}")
    print(f"Paquets perdus: {len(lost)}")
    print(f"Taux de perte: {len(lost)/expected_packets*100:.2f}%")
    
    if lost:
        print(f"Numéros perdus: {sorted(list(lost))[:10]}..." if len(lost) > 10 else f"Numéros perdus: {sorted(list(lost))}")

def main():
    host = "localhost"
    port = 9999
    num_packets = 1000
    
    # Démarrer le récepteur dans un thread
    receiver_thread = threading.Thread(
        target=udp_receiver, 
        args=(port, num_packets)
    )
    receiver_thread.start()
    
    # Attendre que le serveur soit prêt
    time.sleep(1)
    
    # Envoyer les paquets
    udp_sender(host, port, num_packets, delay=0.001)
    
    # Attendre la fin
    receiver_thread.join()

if __name__ == "__main__":
    main()
```

```bash
chmod +x udp_packet_loss.py
python3 udp_packet_loss.py
```

---

### Partie 2.3 : Ports et Sockets

#### Exercice 2.3.1 : Comprendre les ports

```
=== NUMÉROS DE PORTS ===

Ports bien connus (Well-Known Ports): 0-1023
- Nécessitent des privilèges root/admin pour écouter
- Exemples:
    20/21  : FTP
    22     : SSH
    23     : Telnet
    25     : SMTP
    53     : DNS
    80     : HTTP
    110    : POP3
    143    : IMAP
    443    : HTTPS

Ports enregistrés (Registered Ports): 1024-49151
- Utilisés par des applications spécifiques
- Exemples:
    3306   : MySQL
    5432   : PostgreSQL
    6379   : Redis
    8080   : HTTP alternatif
    27017  : MongoDB

Ports dynamiques/privés (Dynamic/Private): 49152-65535
- Utilisés pour les connexions client (ports éphémères)
```

**Analyser les ports utilisés :**

```bash
# Lister tous les ports en écoute
sudo ss -tulpn

# Par protocole
sudo ss -tlpn  # TCP
sudo ss -ulpn  # UDP

# Ports par service
cat /etc/services | grep -E "^(ssh|http|https|ftp|dns)" | head -20

# Voir les ports éphémères configurés
cat /proc/sys/net/ipv4/ip_local_port_range

# Modifier la plage (temporaire)
sudo sysctl -w net.ipv4.ip_local_port_range="32768 60999"
```

---

#### Exercice 2.3.2 : Scanner de ports en Python

```python
#!/usr/bin/env python3
# port_scanner.py - Scanner de ports TCP et UDP

import socket
import sys
from concurrent.futures import ThreadPoolExecutor
import argparse

def scan_tcp_port(host, port, timeout=1):
    """Scanner un port TCP"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        
        if result == 0:
            # Tenter d'identifier le service
            try:
                service = socket.getservbyport(port, 'tcp')
            except:
                service = "unknown"
            return port, "open", service
        else:
            return port, "closed", None
    except socket.error:
        return port, "filtered", None

def scan_udp_port(host, port, timeout=1):
    """Scanner un port UDP"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        
        # Envoyer un paquet vide
        sock.sendto(b'', (host, port))
        
        try:
            data, addr = sock.recvfrom(1024)
            sock.close()
            
            try:
                service = socket.getservbyport(port, 'udp')
            except:
                service = "unknown"
            return port, "open", service
        except socket.timeout:
            # Pas de réponse ne signifie pas forcément fermé pour UDP
            sock.close()
            return port, "open|filtered", None
    except socket.error:
        return port, "closed", None

def scan_ports(host, ports, protocol='tcp', threads=50):
    """Scanner une liste de ports"""
    print(f"Scan de {host} ({protocol.upper()})...")
    print(f"Ports: {min(ports)}-{max(ports)}")
    print("-" * 50)
    
    scan_func = scan_tcp_port if protocol == 'tcp' else scan_udp_port
    
    with ThreadPoolExecutor(max_workers=threads) as executor:
        results = executor.map(lambda p: scan_func(host, p), ports)
    
    open_ports = []
    for port, status, service in results:
        if status in ["open", "open|filtered"]:
            service_name = service if service else "unknown"
            print(f"Port {port:5d}/{protocol} : {status:15s} {service_name}")
            open_ports.append(port)
    
    print("-" * 50)
    print(f"Total ports ouverts: {len(open_ports)}")
    return open_ports

def main():
    parser = argparse.ArgumentParser(description='Scanner de ports TCP/UDP')
    parser.add_argument('host', help='Hôte à scanner')
    parser.add_argument('-p', '--ports', default='1-1024', 
                       help='Ports à scanner (ex: 80,443 ou 1-1000)')
    parser.add_argument('-t', '--protocol', choices=['tcp', 'udp'], 
                       default='tcp', help='Protocole')
    parser.add_argument('-T', '--threads', type=int, default=50,
                       help='Nombre de threads')
    
    args = parser.parse_args()
    
    # Parser les ports
    if '-' in args.ports:
        start, end = map(int, args.ports.split('-'))
        ports = range(start, end + 1)
    else:
        ports = [int(p) for p in args.ports.split(',')]
    
    # Scanner
    scan_ports(args.host, ports, args.protocol, args.threads)

if __name__ == "__main__":
    main()
```

**Utilisation :**
```bash
chmod +x port_scanner.py

# Scanner les ports TCP communs
python3 port_scanner.py localhost -p 1-1024

# Scanner des ports spécifiques
python3 port_scanner.py localhost -p 22,80,443,3306

# Scanner en UDP
python3 port_scanner.py localhost -p 53,67,68,161 -t udp

# Scanner avec plus de threads
python3 port_scanner.py 192.168.1.1 -p 1-10000 -T 100
```

---

#### Exercice 2.3.3 : Programmation socket - Client/Serveur

**Serveur TCP multi-thread :**

```python
#!/usr/bin/env python3
# tcp_server_multithread.py - Serveur TCP gérant plusieurs clients

import socket
import threading

def handle_client(client_socket, client_address):
    """Gérer un client"""
    print(f"[+] Nouvelle connexion de {client_address}")
    
    try:
        # Envoyer message de bienvenue
        client_socket.send(b"Bienvenue sur le serveur!\n")
        
        while True:
            # Recevoir données
            data = client_socket.recv(1024)
            
            if not data:
                break
            
            message = data.decode().strip()
            print(f"[{client_address}] {message}")
            
            # Répondre
            response = f"Echo: {message}\n"
            client_socket.send(response.encode())
            
    except Exception as e:
        print(f"[-] Erreur avec {client_address}: {e}")
    finally:
        print(f"[-] Déconnexion de {client_address}")
        client_socket.close()

def main():
    host = '0.0.0.0'
    port = 9999
    
    # Créer socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    # Bind et listen
    server.bind((host, port))
    server.listen(5)
    
    print(f"[*] Serveur en écoute sur {host}:{port}")
    
    try:
        while True:
            # Accepter connexion
            client_socket, client_address = server.accept()
            
            # Créer un thread pour ce client
            client_thread = threading.Thread(
                target=handle_client,
                args=(client_socket, client_address)
            )
            client_thread.start()
    except KeyboardInterrupt:
        print("\n[*] Arrêt du serveur")
    finally:
        server.close()

if __name__ == "__main__":
    main()
```

**Client TCP :**

```python
#!/usr/bin/env python3
# tcp_client.py - Client TCP simple

import socket
import sys

def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <host> <port>")
        sys.exit(1)
    
    host = sys.argv[1]
    port = int(sys.argv[2])
    
    # Créer socket
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    try:
        # Connecter
        print(f"[*] Connexion à {host}:{port}")
        client.connect((host, port))
        
        # Recevoir message de bienvenue
        response = client.recv(1024)
        print(response.decode(), end='')
        
        # Boucle d'envoi/réception
        while True:
            message = input("> ")
            
            if message.lower() == 'quit':
                break
            
            # Envoyer
            client.send((message + "\n").encode())
            
            # Recevoir réponse
            response = client.recv(1024)
            print(response.decode(), end='')
            
    except Exception as e:
        print(f"[-] Erreur: {e}")
    finally:
        client.close()
        print("[*] Déconnecté")

if __name__ == "__main__":
    main()
```

**Test :**
```bash
# Terminal 1: Serveur
python3 tcp_server_multithread.py

# Terminal 2: Client 1
python3 tcp_client.py localhost 9999

# Terminal 3: Client 2
python3 tcp_client.py localhost 9999

# Terminal 4: Client 3
python3 tcp_client.py localhost 9999
```

---

### 🎯 QUIZ NIVEAU 2

1. Quelles sont les 3 étapes du TCP three-way handshake ?
2. Quelle est la différence principale entre TCP et UDP ?
3. Que signifient les flags TCP SYN, ACK, FIN et RST ?
4. Pourquoi UDP est-il utilisé pour le streaming vidéo ?
5. Qu'est-ce qu'un port éphémère ?
6. Comment TCP garantit-il l'ordre des paquets ?
7. Quelle est la taille de l'en-tête TCP minimum ? Et UDP ?
8. Que se passe-t-il si un paquet TCP n'est pas acquitté ?

**Commandes à mémoriser (Niveau 2) :**
```bash
ss -tulpn                                 # Ports en écoute
sudo tcpdump -i any 'tcp port 80' -vv   # Capture TCP
sudo tcpdump -i any 'udp port 53' -vv   # Capture UDP
nc -l 8080                                # Serveur TCP
nc -u -l 9999                             # Serveur UDP
nc localhost 8080                         # Client TCP
```

---

**[Suite dans le prochain message avec HTTP/HTTPS/SSH...]**

Voulez-vous que je continue avec les niveaux 3, 4 et 5 (HTTP, HTTPS, SSH, analyse avancée et projet final) ?
