# TP PROTOCOLES AVANCÉS - Suite Partie 1
## DHCP (Dynamic Host Configuration Protocol)
### Configuration Automatique des Hôtes

---

## 🟢 NIVEAU 1 (suite) : DHCP

### Objectifs
- Comprendre l'allocation automatique d'IP
- Configurer un serveur DHCP
- Analyser le processus DORA
- Implémenter DHCP dans Packet Tracer

---

### Partie 2.1 : Théorie DHCP

#### Exercice 2.1.1 : Comprendre DHCP

```
=== QU'EST-CE QUE DHCP ? ===

DHCP (Dynamic Host Configuration Protocol) configure
automatiquement les paramètres réseau des clients :
- Adresse IP
- Masque de sous-réseau
- Passerelle par défaut
- Serveurs DNS
- Nom de domaine
- Serveur NTP
- Etc.

=== PROCESSUS DORA (4 ÉTAPES) ===

Client                              Serveur DHCP
  |                                      |
  | DISCOVER (broadcast)                 |
  |------------------------------------->|  1. Client cherche serveur
  |      UDP 68→67                       |
  |                                      |
  |                 OFFER (broadcast)    |
  |<-------------------------------------|  2. Serveur propose IP
  |                   UDP 67→68          |
  |                                      |
  | REQUEST (broadcast)                  |
  |------------------------------------->|  3. Client demande cette IP
  |      UDP 68→67                       |
  |                                      |
  |               ACK (unicast/broadcast)|
  |<-------------------------------------|  4. Serveur confirme
  |                 UDP 67→68            |
  |                                      |

D - Discover  : "Y a-t-il un serveur DHCP ?"
O - Offer     : "Oui, voici une IP disponible"
R - Request   : "J'accepte cette IP"
A - Ack       : "OK, elle est à toi"

=== TYPES D'ALLOCATION ===

1. DYNAMIQUE:
   - IP attribuée temporairement (bail/lease)
   - IP retourne au pool après expiration
   - Usage: Postes clients, Wi-Fi public

2. AUTOMATIQUE:
   - IP attribuée de façon permanente
   - Basée sur MAC address
   - IP ne change pas

3. STATIQUE (Réservation):
   - IP fixe pour un MAC spécifique
   - Configurée dans le serveur
   - Usage: Imprimantes, serveurs

=== PORTS DHCP ===

Port 67 : Serveur DHCP (écoute)
Port 68 : Client DHCP (écoute)
Protocole : UDP

=== BAIL (LEASE) ===

Durée pendant laquelle l'IP est attribuée
- T1 (50% du bail) : Renouvellement avec serveur actuel
- T2 (87.5% du bail) : Renouvellement avec n'importe quel serveur
- Expiration : Client doit recommencer DORA

Exemple: Bail de 24h
- 0h   : IP obtenue
- 12h  : T1 - Renouvellement automatique (DHCP Request)
- 21h  : T2 - Si T1 échoué, broadcast Request
- 24h  : Expiration - DHCP Discover si toujours pas renouvelé

=== OPTIONS DHCP ===

Options courantes (sur 255 possibles):
1   : Masque de sous-réseau
3   : Passerelle par défaut (router)
6   : Serveurs DNS
15  : Nom de domaine
42  : Serveurs NTP
51  : Durée du bail
53  : Type de message DHCP
54  : Identifiant du serveur
```

---

#### Exercice 2.1.2 : Installation serveur DHCP (Linux)

```bash
#!/bin/bash
# install_dhcp_server.sh - Installer et configurer serveur DHCP

echo "=== INSTALLATION SERVEUR DHCP ==="

# 1. Installation
sudo apt update
sudo apt install isc-dhcp-server -y

# 2. Configuration de l'interface
echo "[1] Configuration interface..."
INTERFACE="eth0"  # À adapter

sudo tee /etc/default/isc-dhcp-server << EOF
# Interface d'écoute du serveur DHCP
INTERFACESv4="$INTERFACE"
INTERFACESv6=""
EOF

# 3. Configuration principale
echo "[2] Configuration DHCP..."

sudo cp /etc/dhcp/dhcpd.conf /etc/dhcp/dhcpd.conf.backup

sudo tee /etc/dhcp/dhcpd.conf << 'DHCPCONF'
# Configuration serveur DHCP

# Paramètres globaux
option domain-name "lab.local";
option domain-name-servers 8.8.8.8, 8.8.4.4;
default-lease-time 600;
max-lease-time 7200;
authoritative;

# Log
log-facility local7;

# Subnet 192.168.1.0/24
subnet 192.168.1.0 netmask 255.255.255.0 {
    range 192.168.1.100 192.168.1.200;
    option routers 192.168.1.1;
    option subnet-mask 255.255.255.0;
    option broadcast-address 192.168.1.255;
    option domain-name-servers 8.8.8.8, 8.8.4.4;
    option ntp-servers 192.168.1.1;
    default-lease-time 600;
    max-lease-time 7200;
}

# Réservation statique (exemple)
host printer {
    hardware ethernet 00:11:22:33:44:55;
    fixed-address 192.168.1.50;
}

host server {
    hardware ethernet aa:bb:cc:dd:ee:ff;
    fixed-address 192.168.1.10;
    option host-name "server.lab.local";
}

# Subnet additionnel
#subnet 192.168.2.0 netmask 255.255.255.0 {
#    range 192.168.2.100 192.168.2.200;
#    option routers 192.168.2.1;
#}
DHCPCONF

# 4. Configurer IP statique sur l'interface serveur
echo "[3] Configuration IP statique serveur..."
sudo tee /etc/netplan/01-dhcp-server.yaml << NETPLAN
network:
  version: 2
  ethernets:
    $INTERFACE:
      addresses:
        - 192.168.1.1/24
      dhcp4: no
NETPLAN

sudo netplan apply

# 5. Démarrer le service
echo "[4] Démarrage service DHCP..."
sudo systemctl restart isc-dhcp-server
sudo systemctl enable isc-dhcp-server

# 6. Vérifier
echo "[5] Vérification..."
sudo systemctl status isc-dhcp-server

# 7. Afficher les baux
echo "[6] Fichier des baux:"
echo "    /var/lib/dhcp/dhcpd.leases"

echo ""
echo "✓ Serveur DHCP configuré"
echo "  Réseau: 192.168.1.0/24"
echo "  Pool: 192.168.1.100-200"
echo "  Gateway: 192.168.1.1"
echo ""
echo "Commandes utiles:"
echo "  sudo systemctl status isc-dhcp-server"
echo "  sudo tail -f /var/log/syslog | grep dhcp"
echo "  sudo cat /var/lib/dhcp/dhcpd.leases"
```

```bash
chmod +x install_dhcp_server.sh
sudo ./install_dhcp_server.sh
```

---

#### Exercice 2.1.3 : Configuration client DHCP

```bash
#!/bin/bash
# dhcp_client_config.sh - Configuration client DHCP

echo "=== CONFIGURATION CLIENT DHCP ==="

INTERFACE="eth0"  # À adapter

# 1. Configuration netplan (Ubuntu moderne)
echo "[1] Méthode 1: Netplan (Ubuntu 18.04+)"
sudo tee /etc/netplan/01-network-config.yaml << NETPLAN
network:
  version: 2
  ethernets:
    $INTERFACE:
      dhcp4: true
      dhcp6: false
NETPLAN

sudo netplan apply

# 2. Configuration /etc/network/interfaces (Debian classique)
echo "[2] Méthode 2: /etc/network/interfaces"
cat << INTERFACES
# Ajouter dans /etc/network/interfaces
auto $INTERFACE
iface $INTERFACE inet dhcp
INTERFACES

# 3. Renouveler le bail DHCP
echo "[3] Renouvellement manuel:"
sudo dhclient -r $INTERFACE  # Release
sudo dhclient $INTERFACE     # Renew

# 4. Informations du bail actuel
echo "[4] Informations bail DHCP:"
cat /var/lib/dhcp/dhclient.leases

# 5. Tester avec dhcping
echo "[5] Test avec dhcping:"
sudo apt install dhcping -y
sudo dhcping -s 192.168.1.1 -i $INTERFACE

# 6. Mode verbose
echo "[6] dhclient en mode verbose:"
sudo dhclient -v $INTERFACE

# 7. Script pour monitorer renouvellement
cat << 'SCRIPT' > monitor_dhcp_lease.sh
#!/bin/bash
# Monitorer le bail DHCP

INTERFACE="eth0"
LEASE_FILE="/var/lib/dhcp/dhclient.$INTERFACE.leases"

while true; do
    if [ -f "$LEASE_FILE" ]; then
        echo "=== $(date) ==="
        echo "Bail actuel:"
        grep -E "lease|renew|rebind|expire" "$LEASE_FILE" | tail -4
        echo ""
    fi
    sleep 60
done
SCRIPT

chmod +x monitor_dhcp_lease.sh

echo ""
echo "✓ Client DHCP configuré"
echo ""
echo "Commandes utiles:"
echo "  sudo dhclient -v eth0        # Obtenir bail (verbose)"
echo "  sudo dhclient -r eth0        # Libérer bail"
echo "  ip addr show eth0            # Vérifier IP"
echo "  ./monitor_dhcp_lease.sh      # Monitorer"
```

---

#### Exercice 2.1.4 : Capture et analyse DHCP

```bash
#!/bin/bash
# capture_dhcp.sh - Capturer et analyser trafic DHCP

INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)

echo "=== CAPTURE TRAFIC DHCP ==="
echo "Interface: $INTERFACE"

# Démarrer capture
echo "Capture en cours (30 secondes)..."
sudo tcpdump -i $INTERFACE -w dhcp_capture.pcap \
    'udp port 67 or udp port 68' &
TCPDUMP_PID=$!

sleep 2

# Forcer renouvellement DHCP
echo "Génération trafic DHCP..."
sudo dhclient -r $INTERFACE
sleep 2
sudo dhclient $INTERFACE

sleep 28
sudo kill $TCPDUMP_PID 2>/dev/null

# Analyser
echo ""
echo "=== ANALYSE ==="

# Avec tcpdump
echo "[1] Messages DHCP capturés:"
tcpdump -r dhcp_capture.pcap -n -v | grep -i dhcp | head -20

# Avec tshark détaillé
echo ""
echo "[2] Détails avec tshark:"
tshark -r dhcp_capture.pcap -Y "dhcp" -V | head -50

# Extraire les 4 messages DORA
echo ""
echo "[3] Messages DORA:"
tshark -r dhcp_capture.pcap -Y "dhcp" -T fields \
    -e frame.number \
    -e dhcp.option.dhcp \
    -e ip.src \
    -e ip.dst \
    -e dhcp.option.requested_ip_address 2>/dev/null

# Statistiques
echo ""
echo "[4] Statistiques:"
echo "DISCOVER: $(tshark -r dhcp_capture.pcap -Y 'dhcp.option.dhcp==1' 2>/dev/null | wc -l)"
echo "OFFER:    $(tshark -r dhcp_capture.pcap -Y 'dhcp.option.dhcp==2' 2>/dev/null | wc -l)"
echo "REQUEST:  $(tshark -r dhcp_capture.pcap -Y 'dhcp.option.dhcp==3' 2>/dev/null | wc -l)"
echo "ACK:      $(tshark -r dhcp_capture.pcap -Y 'dhcp.option.dhcp==5' 2>/dev/null | wc -l)"

echo ""
echo "Capture: dhcp_capture.pcap"
```

---

#### Exercice 2.1.5 : Client DHCP avec Scapy

```python
#!/usr/bin/env python3
# dhcp_client_scapy.py - Client DHCP avec Scapy

from scapy.all import *
import sys

def dhcp_discover(iface='eth0'):
    """Envoyer DHCP Discover"""
    
    print("[*] Envoi DHCP DISCOVER...")
    
    # MAC address de l'interface
    mac = get_if_hwaddr(iface)
    
    # Transaction ID aléatoire
    xid = random.randint(1, 0xFFFFFFFF)
    
    # Construire le paquet
    ether = Ether(dst='ff:ff:ff:ff:ff:ff', src=mac)
    ip = IP(src='0.0.0.0', dst='255.255.255.255')
    udp = UDP(sport=68, dport=67)
    
    bootp = BOOTP(
        op=1,  # Request
        chaddr=mac2str(mac),
        xid=xid
    )
    
    dhcp = DHCP(options=[
        ('message-type', 'discover'),
        ('param_req_list', [1, 3, 6, 15]),  # Subnet, Router, DNS, Domain
        'end'
    ])
    
    packet = ether/ip/udp/bootp/dhcp
    
    # Afficher
    packet.show()
    
    # Envoyer et attendre réponse
    print("[*] Attente OFFER...")
    ans = srp1(packet, iface=iface, timeout=5, verbose=False)
    
    if ans:
        return ans, xid
    else:
        print("[-] Pas d'OFFER reçu")
        return None, xid

def dhcp_request(offer, xid, iface='eth0'):
    """Envoyer DHCP Request"""
    
    print("\n[*] Envoi DHCP REQUEST...")
    
    mac = get_if_hwaddr(iface)
    
    # Extraire infos de l'OFFER
    offered_ip = offer[BOOTP].yiaddr
    server_ip = offer[BOOTP].siaddr
    
    # Trouver le serveur DHCP dans les options
    for opt in offer[DHCP].options:
        if opt[0] == 'server_id':
            server_id = opt[1]
            break
    
    print(f"[+] IP offerte: {offered_ip}")
    print(f"[+] Serveur DHCP: {server_id}")
    
    # Construire REQUEST
    ether = Ether(dst='ff:ff:ff:ff:ff:ff', src=mac)
    ip = IP(src='0.0.0.0', dst='255.255.255.255')
    udp = UDP(sport=68, dport=67)
    
    bootp = BOOTP(
        op=1,
        chaddr=mac2str(mac),
        xid=xid
    )
    
    dhcp = DHCP(options=[
        ('message-type', 'request'),
        ('requested_addr', offered_ip),
        ('server_id', server_id),
        ('param_req_list', [1, 3, 6, 15]),
        'end'
    ])
    
    packet = ether/ip/udp/bootp/dhcp
    
    # Envoyer et attendre ACK
    print("[*] Attente ACK...")
    ans = srp1(packet, iface=iface, timeout=5, verbose=False)
    
    return ans

def parse_dhcp_options(packet):
    """Parser les options DHCP"""
    
    if not packet.haslayer(DHCP):
        return {}
    
    options = {}
    
    for opt in packet[DHCP].options:
        if opt == 'end':
            break
        
        key, value = opt[0], opt[1]
        
        if key == 'message-type':
            types = {1: 'discover', 2: 'offer', 3: 'request', 
                    5: 'ack', 6: 'nak'}
            options[key] = types.get(value, value)
        else:
            options[key] = value
    
    return options

def full_dhcp_sequence(iface='eth0'):
    """Séquence DHCP complète"""
    
    print("="*60)
    print("SÉQUENCE DHCP COMPLÈTE")
    print("="*60)
    print(f"Interface: {iface}\n")
    
    # 1. DISCOVER
    offer, xid = dhcp_discover(iface)
    
    if not offer:
        return
    
    # Parser OFFER
    print("\n[+] OFFER reçu:")
    print(f"    IP proposée: {offer[BOOTP].yiaddr}")
    
    options = parse_dhcp_options(offer)
    for key, value in options.items():
        print(f"    {key}: {value}")
    
    # 2. REQUEST
    ack = dhcp_request(offer, xid, iface)
    
    if not ack:
        print("[-] Pas d'ACK reçu")
        return
    
    # Parser ACK
    print("\n[+] ACK reçu:")
    print(f"    IP attribuée: {ack[BOOTP].yiaddr}")
    
    options = parse_dhcp_options(ack)
    for key, value in options.items():
        print(f"    {key}: {value}")
    
    print("\n" + "="*60)
    print("CONFIGURATION OBTENUE:")
    print("="*60)
    print(f"IP Address:     {ack[BOOTP].yiaddr}")
    print(f"Subnet Mask:    {options.get('subnet_mask', 'N/A')}")
    print(f"Router:         {options.get('router', 'N/A')}")
    print(f"DNS Servers:    {options.get('name_server', 'N/A')}")
    print(f"Domain:         {options.get('domain', 'N/A')}")
    print(f"Lease Time:     {options.get('lease_time', 'N/A')}s")
    print("="*60)

def dhcp_release(ip_address, iface='eth0'):
    """Libérer une adresse DHCP"""
    
    print(f"[*] Libération de {ip_address}...")
    
    mac = get_if_hwaddr(iface)
    xid = random.randint(1, 0xFFFFFFFF)
    
    ether = Ether(dst='ff:ff:ff:ff:ff:ff', src=mac)
    ip = IP(src=ip_address, dst='255.255.255.255')
    udp = UDP(sport=68, dport=67)
    
    bootp = BOOTP(
        op=1,
        chaddr=mac2str(mac),
        xid=xid,
        ciaddr=ip_address
    )
    
    dhcp = DHCP(options=[
        ('message-type', 'release'),
        'end'
    ])
    
    packet = ether/ip/udp/bootp/dhcp
    
    sendp(packet, iface=iface, verbose=False)
    print("[+] RELEASE envoyé")

def main():
    if os.geteuid() != 0:
        print("Nécessite root (sudo)")
        sys.exit(1)
    
    import argparse
    
    parser = argparse.ArgumentParser(description='Client DHCP avec Scapy')
    parser.add_argument('--discover', action='store_true',
                       help='Envoyer DISCOVER')
    parser.add_argument('--full', action='store_true',
                       help='Séquence complète')
    parser.add_argument('--release', metavar='IP',
                       help='Libérer une IP')
    parser.add_argument('--interface', default='eth0',
                       help='Interface réseau')
    
    args = parser.parse_args()
    
    if args.full:
        full_dhcp_sequence(args.interface)
    elif args.discover:
        dhcp_discover(args.interface)
    elif args.release:
        dhcp_release(args.release, args.interface)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
```

**Utilisation :**
```bash
chmod +x dhcp_client_scapy.py

# Séquence complète
sudo python3 dhcp_client_scapy.py --full

# Discover seulement
sudo python3 dhcp_client_scapy.py --discover

# Release
sudo python3 dhcp_client_scapy.py --release 192.168.1.100
```

---

### Partie 2.2 : DHCP dans Packet Tracer

#### Exercice 2.2.1 : Topologie DHCP simple

```
=== TOPOLOGIE PACKET TRACER - DHCP ===

    PC1          PC2          PC3
     │            │            │
     │            │            │
     └────────────┼────────────┘
                  │
              Switch0
                  │
              Router0
           (Serveur DHCP)

CONFIGURATION:

1. Router comme serveur DHCP:

Router> enable
Router# configure terminal
Router(config)# interface GigabitEthernet0/0
Router(config-if)# ip address 192.168.1.1 255.255.255.0
Router(config-if)# no shutdown
Router(config-if)# exit

! Créer le pool DHCP
Router(config)# ip dhcp pool LAN_POOL
Router(dhcp-config)# network 192.168.1.0 255.255.255.0
Router(dhcp-config)# default-router 192.168.1.1
Router(dhcp-config)# dns-server 8.8.8.8 8.8.4.4
Router(dhcp-config)# domain-name lab.local
Router(dhcp-config)# lease 0 8 0
Router(dhcp-config)# exit

! Exclure certaines IP
Router(config)# ip dhcp excluded-address 192.168.1.1 192.168.1.10

! Vérifier
Router# show ip dhcp pool
Router# show ip dhcp binding

2. PC en mode DHCP:
   - Desktop > IP Configuration
   - Sélectionner "DHCP"
   - Cliquer "Renew" ou attendre

3. Vérifier:
   PC> ipconfig
   PC> ipconfig /all

4. Mode Simulation:
   - Activer Simulation Mode
   - Sur PC: Desktop > Command Prompt > ipconfig /renew
   - Observer les 4 paquets DORA
```

---

#### Exercice 2.2.2 : DHCP Relay

```
=== TOPOLOGIE DHCP RELAY ===

 Réseau A                Réseau B
192.168.1.0/24         192.168.2.0/24
    │                       │
  Switch                  Switch
    │                       │
    PC1                     PC2
    │                       │
    └───── Router ──────────┘
       (DHCP Relay)
              │
              │
         Serveur DHCP
       192.168.3.10

Le routeur fait office de relais DHCP entre les clients
et le serveur DHCP centralisé.

CONFIGURATION RELAY:

Router> enable
Router# configure terminal

! Interface vers Réseau A
Router(config)# interface GigabitEthernet0/0
Router(config-if)# ip address 192.168.1.1 255.255.255.0
Router(config-if)# ip helper-address 192.168.3.10
Router(config-if)# no shutdown
Router(config-if)# exit

! Interface vers Réseau B
Router(config)# interface GigabitEthernet0/1
Router(config-if)# ip address 192.168.2.1 255.255.255.0
Router(config-if)# ip helper-address 192.168.3.10
Router(config-if)# no shutdown
Router(config-if)# exit

! Interface vers Serveur DHCP
Router(config)# interface GigabitEthernet0/2
Router(config-if)# ip address 192.168.3.1 255.255.255.0
Router(config-if)# no shutdown

CONFIGURATION SERVEUR DHCP:

! Pool pour Réseau A
Router(config)# ip dhcp pool VLAN_A
Router(dhcp-config)# network 192.168.1.0 255.255.255.0
Router(dhcp-config)# default-router 192.168.1.1
Router(dhcp-config)# dns-server 8.8.8.8
Router(dhcp-config)# exit

! Pool pour Réseau B
Router(config)# ip dhcp pool VLAN_B
Router(dhcp-config)# network 192.168.2.0 255.255.255.0
Router(dhcp-config)# default-router 192.168.2.1
Router(dhcp-config)# dns-server 8.8.8.8
Router(dhcp-config)# exit
```

---

### Partie 2.3 : DHCP Avancé

#### Exercice 2.3.1 : Failover DHCP (Haute Disponibilité)

```bash
#!/bin/bash
# dhcp_failover_setup.sh - Configuration DHCP Failover

echo "=== CONFIGURATION DHCP FAILOVER ==="

# SERVEUR PRIMAIRE
cat << 'PRIMARY' > /etc/dhcp/dhcpd_primary.conf
# Serveur DHCP Primaire avec Failover

failover peer "dhcp-failover" {
    primary;
    address 192.168.1.10;
    port 647;
    peer address 192.168.1.11;
    peer port 647;
    max-response-delay 60;
    max-unacked-updates 10;
    mclt 3600;
    split 128;
    load balance max seconds 3;
}

subnet 192.168.1.0 netmask 255.255.255.0 {
    option routers 192.168.1.1;
    option subnet-mask 255.255.255.0;
    option domain-name-servers 8.8.8.8, 8.8.4.4;
    
    pool {
        failover peer "dhcp-failover";
        range 192.168.1.100 192.168.1.200;
    }
}
PRIMARY

# SERVEUR SECONDAIRE
cat << 'SECONDARY' > /etc/dhcp/dhcpd_secondary.conf
# Serveur DHCP Secondaire avec Failover

failover peer "dhcp-failover" {
    secondary;
    address 192.168.1.11;
    port 647;
    peer address 192.168.1.10;
    peer port 647;
    max-response-delay 60;
    max-unacked-updates 10;
    load balance max seconds 3;
}

subnet 192.168.1.0 netmask 255.255.255.0 {
    option routers 192.168.1.1;
    option subnet-mask 255.255.255.0;
    option domain-name-servers 8.8.8.8, 8.8.4.4;
    
    pool {
        failover peer "dhcp-failover";
        range 192.168.1.100 192.168.1.200;
    }
}
SECONDARY

echo "Configurations créées:"
echo "  - /etc/dhcp/dhcpd_primary.conf"
echo "  - /etc/dhcp/dhcpd_secondary.conf"
```

---

#### Exercice 2.3.2 : Snooping DHCP (Sécurité)

```
=== DHCP SNOOPING (CISCO SWITCH) ===

DHCP Snooping protège contre les serveurs DHCP malveillants

Configuration:

Switch> enable
Switch# configure terminal

! Activer DHCP snooping globalement
Switch(config)# ip dhcp snooping

! Activer sur VLANs
Switch(config)# ip dhcp snooping vlan 10,20

! Configurer interfaces de confiance (uplink, serveur DHCP)
Switch(config)# interface GigabitEthernet0/1
Switch(config-if)# ip dhcp snooping trust
Switch(config-if)# exit

! Limiter le taux de requêtes DHCP sur interfaces non fiables
Switch(config)# interface range FastEthernet0/1-24
Switch(config-if-range)# ip dhcp snooping limit rate 10
Switch(config-if-range)# exit

! Option 82 (informations circuit)
Switch(config)# ip dhcp snooping information option

! Vérifier
Switch# show ip dhcp snooping
Switch# show ip dhcp snooping binding
```

---

### 🎯 QUIZ DHCP

1. Que signifie DORA ?
2. Quels sont les ports UDP utilisés par DHCP ?
3. Qu'est-ce qu'un bail DHCP ?
4. Quelle est la différence entre T1 et T2 ?
5. Qu'est-ce qu'une réservation DHCP ?
6. À quoi sert DHCP Relay (ip helper-address) ?
7. Qu'est-ce que DHCP Snooping ?
8. Quelle option DHCP fournit la passerelle par défaut ?

**Réponses :**
1. Discover, Offer, Request, Ack
2. 67 (serveur), 68 (client)
3. Durée de location d'une IP
4. T1 (50%) = renouvellement, T2 (87.5%) = broadcast si T1 échoue
5. IP fixe attribuée à un MAC spécifique
6. Relayer les requêtes DHCP vers un serveur distant
7. Sécurité contre serveurs DHCP malveillants
8. Option 3 (router)

---

**Durée Niveau DHCP : 5-6 heures**

[Suite avec DNS dans le prochain fichier...]
