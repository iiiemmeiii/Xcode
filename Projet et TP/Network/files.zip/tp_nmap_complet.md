# TP COMPLET : MAÎTRISE DE NMAP SUR UBUNTU
## De Zéro à Expert - Apprentissage Progressif

**Durée estimée :** 8-12 heures  
**Système :** Ubuntu 20.04+ (testé sur Ubuntu 22.04)  
**Prérequis :** Connaissances de base en réseau et terminal Linux

---

## 📋 TABLE DES MATIÈRES

1. [Niveau 1 - Débutant : Installation et Découverte](#niveau-1)
2. [Niveau 2 - Intermédiaire : Scans Avancés](#niveau-2)
3. [Niveau 3 - Confirmé : Scripts NSE et Automatisation](#niveau-3)
4. [Niveau 4 - Expert : Techniques Avancées et Évasion](#niveau-4)
5. [Projet Final : Audit de Sécurité Complet](#projet-final)

---

<a name="niveau-1"></a>
## 🟢 NIVEAU 1 : DÉBUTANT (2-3 heures)

### Objectifs
- Installer Nmap et libpcap
- Comprendre les bases du scanning réseau
- Effectuer vos premiers scans
- Interpréter les résultats basiques

### Partie 1.1 : Installation et Configuration

#### Exercice 1.1.1 : Installation de Nmap

```bash
# Mise à jour du système
sudo apt update && sudo apt upgrade -y

# Installation de Nmap
sudo apt install nmap -y

# Vérification de l'installation
nmap --version

# Installation de libpcap (bibliothèque de capture de paquets)
sudo apt install libpcap-dev -y

# Vérification de libpcap
dpkg -l | grep libpcap
```

**Questions :**
1. Quelle version de Nmap avez-vous installée ?
2. Quelle est la différence entre libpcap et npcap ?
3. Pourquoi avons-nous besoin des privilèges sudo ?

**Réponses attendues :**
- Version 7.80+ normalement
- libpcap (Linux/Unix) vs npcap (Windows, successeur de WinPcap)
- Certains scans nécessitent des paquets raw (privilèges root)

---

#### Exercice 1.1.2 : Préparation de l'environnement de test

```bash
# Installation d'un serveur web local pour les tests
sudo apt install apache2 -y

# Vérifier que le service est actif
sudo systemctl status apache2

# Trouver votre adresse IP locale
ip addr show | grep inet

# Alternative
hostname -I
```

**Tâche pratique :**
- Notez votre adresse IP locale : `_______________`
- Vérifiez l'accès à http://localhost dans votre navigateur

---

### Partie 1.2 : Premiers Scans Basiques

#### Exercice 1.2.1 : Scan de votre machine locale

```bash
# Scan basique de localhost
nmap localhost

# Scan de votre IP locale
nmap 127.0.0.1

# Scan avec votre IP réelle
nmap $(hostname -I | awk '{print $1}')
```

**Analyse des résultats :**
```
Starting Nmap 7.80 ( https://nmap.org )
Nmap scan report for localhost (127.0.0.1)
Host is up (0.000012s latency).
Not shown: 997 closed ports
PORT    STATE SERVICE
22/tcp  open  ssh
80/tcp  open  http
443/tcp open  https
```

**Questions d'analyse :**
1. Combien de ports sont ouverts ?
2. Quels services sont détectés ?
3. Que signifie "closed ports" ?

---

#### Exercice 1.2.2 : Options de scan basiques

```bash
# Scan avec informations détaillées (verbose)
nmap -v localhost

# Scan très verbeux
nmap -vv localhost

# Scan avec raison de l'état des ports
nmap --reason localhost

# Scan sans résolution DNS (plus rapide)
nmap -n localhost

# Scan avec résolution DNS forcée
nmap -R localhost
```

**Tâche :** Comparez les temps d'exécution avec et sans `-n`

---

#### Exercice 1.2.3 : Spécification des cibles

```bash
# Scan d'une IP unique
nmap 192.168.1.1

# Scan d'un range d'IPs
nmap 192.168.1.1-10

# Scan d'un sous-réseau (notation CIDR)
nmap 192.168.1.0/24

# Scan de plusieurs hôtes
nmap 192.168.1.1 192.168.1.5 192.168.1.10

# Scan depuis un fichier
echo "192.168.1.1" > targets.txt
echo "192.168.1.5" >> targets.txt
nmap -iL targets.txt

# Exclure certaines IPs
nmap 192.168.1.0/24 --exclude 192.168.1.1
nmap 192.168.1.0/24 --excludefile exclude.txt
```

**Mini-projet 1 :**
Créez un script bash qui :
1. Trouve automatiquement votre sous-réseau local
2. Scanne toutes les machines actives
3. Sauvegarde les résultats dans un fichier

```bash
#!/bin/bash
# Solution partielle - à compléter
SUBNET=$(ip route | grep default | awk '{print $3}' | cut -d. -f1-3)
nmap -sn ${SUBNET}.0/24 -oN scan_local.txt
```

---

### Partie 1.3 : Types de Scans Fondamentaux

#### Exercice 1.3.1 : Scan de découverte d'hôtes (Host Discovery)

```bash
# Ping scan (détecte les hôtes actifs sans scanner les ports)
nmap -sn 192.168.1.0/24

# Équivalent de l'ancien -sP
nmap -sP 192.168.1.0/24  # Déprécié mais encore fonctionnel

# Liste les hôtes sans les scanner
nmap -sL 192.168.1.0/24

# Désactiver la découverte d'hôte (traiter tous comme actifs)
nmap -Pn localhost
```

**Analyse :**
- Combien d'hôtes actifs sur votre réseau ?
- Quelle est la différence entre `-sn` et `-sL` ?

---

#### Exercice 1.3.2 : Scans de ports basiques

```bash
# Scan TCP Connect (ne nécessite pas de privilèges root)
nmap -sT localhost

# Scan SYN (nécessite root, plus furtif)
sudo nmap -sS localhost

# Scan UDP (lent, nécessite root)
sudo nmap -sU localhost

# Scan des ports les plus communs (1000 ports)
nmap localhost

# Scan de tous les ports (65535)
nmap -p- localhost

# Scan de ports spécifiques
nmap -p 22,80,443 localhost

# Scan d'une plage de ports
nmap -p 1-100 localhost

# Scan des 100 ports les plus communs
nmap --top-ports 100 localhost
```

**Exercice pratique :**
Comparez les temps d'exécution :
- `nmap localhost` : _______ secondes
- `nmap -p- localhost` : _______ secondes
- `sudo nmap -sS localhost` : _______ secondes

---

#### Exercice 1.3.3 : Formats de sortie

```bash
# Sortie normale (affichage terminal)
nmap localhost

# Sortie normale dans un fichier
nmap localhost -oN scan_normal.txt

# Sortie XML (pour parsing)
nmap localhost -oX scan.xml

# Sortie greppable (une ligne par hôte)
nmap localhost -oG scan.grep

# Tous les formats en même temps
nmap localhost -oA scan_complet

# Sortie en format "script kiddie" (pour le fun)
nmap localhost -oS scan_kiddie.txt
```

**Tâche :**
Examinez chaque fichier de sortie et identifiez leurs cas d'usage.

---

### Partie 1.4 : Détection de Services et Versions

#### Exercice 1.4.1 : Détection de versions

```bash
# Détection de version basique
nmap -sV localhost

# Détection de version intensive (plus lente mais précise)
nmap -sV --version-intensity 9 localhost

# Détection de version légère (plus rapide)
nmap -sV --version-intensity 0 localhost

# Détection de version avec tous les ports
nmap -sV -p- localhost
```

**Analyse des résultats :**
```
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.1 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.52 ((Ubuntu))
```

**Questions :**
1. Quelles informations supplémentaires obtenez-vous avec `-sV` ?
2. Pourquoi l'intensité 9 est-elle plus lente ?

---

#### Exercice 1.4.2 : Détection de système d'exploitation

```bash
# Détection d'OS (nécessite root)
sudo nmap -O localhost

# Détection d'OS agressive
sudo nmap -O --osscan-guess localhost

# Scan complet : OS + versions + scripts + traceroute
sudo nmap -A localhost

# Limiter les tentatives de détection d'OS
sudo nmap -O --osscan-limit localhost
```

**Note importante :** La détection d'OS fonctionne mieux sur des machines distantes que sur localhost.

---

### 🎯 QUIZ NIVEAU 1

1. Quelle est la différence entre `-sT` et `-sS` ?
2. Pourquoi utiliser `-n` accélère-t-il les scans ?
3. Que signifie "STATE: filtered" pour un port ?
4. Comment scanner uniquement les ports UDP 53 et 67 ?
5. Quelle option permet de sauvegarder en XML ?

**Commandes à mémoriser (Niveau 1) :**
```bash
nmap <target>              # Scan basique
nmap -sn <subnet>          # Découverte d'hôtes
nmap -p- <target>          # Tous les ports
nmap -sV <target>          # Détection de versions
sudo nmap -A <target>      # Scan agressif complet
nmap -oA <name> <target>   # Sauvegarder tous formats
```

---

<a name="niveau-2"></a>
## 🟡 NIVEAU 2 : INTERMÉDIAIRE (3-4 heures)

### Objectifs
- Maîtriser les techniques de scan avancées
- Optimiser la performance des scans
- Comprendre les états des ports en profondeur
- Utiliser les scripts NSE basiques

### Partie 2.1 : Techniques de Scan Avancées

#### Exercice 2.1.1 : Scans TCP spécialisés

```bash
# Scan TCP ACK (détection de firewall)
sudo nmap -sA localhost

# Scan TCP Window
sudo nmap -sW localhost

# Scan TCP Maimon
sudo nmap -sM localhost

# Scan TCP FIN
sudo nmap -sF localhost

# Scan TCP Xmas (FIN, PSH, URG flags)
sudo nmap -sX localhost

# Scan TCP Null (aucun flag)
sudo nmap -sN localhost

# Idle scan (scan zombie, très furtif)
# sudo nmap -sI <zombie_host> <target>
```

**Tableau comparatif à remplir :**

| Type de scan | Flags TCP | Détectable par firewall ? | Nécessite root ? |
|--------------|-----------|---------------------------|------------------|
| -sT          |           |                           |                  |
| -sS          | SYN       |                           | Oui              |
| -sA          |           |                           |                  |
| -sF          |           |                           |                  |
| -sX          |           |                           |                  |
| -sN          |           |                           |                  |

---

#### Exercice 2.1.2 : Scans UDP avancés

```bash
# Scan UDP basique
sudo nmap -sU localhost

# Scan UDP des ports les plus communs
sudo nmap -sU --top-ports 20 localhost

# Scan UDP avec version
sudo nmap -sU -sV -p 53,161 localhost

# Scan combiné TCP + UDP
sudo nmap -sS -sU -p T:80,U:53 localhost
```

**Installation de services UDP pour les tests :**
```bash
# Installer un serveur DNS
sudo apt install bind9 -y

# Vérifier le port 53 UDP
sudo netstat -ulnp | grep 53

# Scanner le port 53
sudo nmap -sU -p 53 localhost
```

---

#### Exercice 2.1.3 : Scans SCTP et IP Protocol

```bash
# Scan SCTP INIT
sudo nmap -sY localhost

# Scan SCTP COOKIE ECHO
sudo nmap -sZ localhost

# Scan des protocoles IP
sudo nmap -sO localhost
```

---

### Partie 2.2 : Optimisation et Performance

#### Exercice 2.2.1 : Contrôle du timing

```bash
# Templates de timing (T0 à T5)
# T0 : Paranoïaque (très lent, furtif)
nmap -T0 localhost

# T1 : Sournois (lent)
nmap -T1 localhost

# T2 : Poli (ralenti pour moins de bande passante)
nmap -T2 localhost

# T3 : Normal (défaut)
nmap -T3 localhost
nmap localhost  # Équivalent

# T4 : Agressif (supposant un réseau rapide)
nmap -T4 localhost

# T5 : Insane (très rapide, peut perdre des résultats)
nmap -T5 localhost
```

**Exercice de timing :**
Mesurez le temps d'exécution de chaque template sur votre machine :

```bash
time nmap -T0 -p 1-100 localhost
time nmap -T3 -p 1-100 localhost
time nmap -T5 -p 1-100 localhost
```

Résultats :
- T0 : _______ secondes
- T3 : _______ secondes
- T5 : _______ secondes

---

#### Exercice 2.2.2 : Contrôle manuel du timing

```bash
# Délai minimum entre les probes
nmap --scan-delay 1s localhost

# Délai maximum entre les probes
nmap --max-scan-delay 10ms localhost

# Contrôle du RTT timeout minimum
nmap --min-rtt-timeout 100ms localhost

# Contrôle du RTT timeout maximum
nmap --max-rtt-timeout 200ms localhost

# Timeout initial de RTT
nmap --initial-rtt-timeout 500ms localhost

# Nombre de retransmissions
nmap --max-retries 2 localhost

# Timeout pour un hôte
nmap --host-timeout 5m localhost
```

---

#### Exercice 2.2.3 : Parallélisation

```bash
# Groupes d'hôtes minimum
nmap --min-hostgroup 50 192.168.1.0/24

# Groupes d'hôtes maximum
nmap --max-hostgroup 100 192.168.1.0/24

# Parallélisation minimale
nmap --min-parallelism 10 localhost

# Parallélisation maximale
nmap --max-parallelism 100 localhost

# Taux de paquets minimum
nmap --min-rate 100 localhost

# Taux de paquets maximum
nmap --max-rate 1000 localhost
```

**Mini-projet 2 :**
Trouvez la configuration optimale pour scanner rapidement votre sous-réseau local sans perdre de précision.

```bash
#!/bin/bash
# À optimiser selon votre réseau
sudo nmap -T4 --min-rate 300 --max-retries 2 -p 22,80,443 192.168.1.0/24 -oA scan_optimise
```

---

### Partie 2.3 : États des Ports et Interprétation

#### Exercice 2.3.1 : Comprendre les états de ports

```bash
# Scan avec raisons d'état
nmap --reason localhost

# Scan avec paquets envoyés/reçus
nmap --packet-trace -p 22,80 localhost
```

**États possibles :**
- `open` : Application accepte les connexions TCP/UDP
- `closed` : Port accessible mais aucune application n'écoute
- `filtered` : Nmap ne peut déterminer (firewall bloque)
- `unfiltered` : Accessible mais état ouvert/fermé indéterminable
- `open|filtered` : Nmap ne peut déterminer
- `closed|filtered` : Nmap ne peut déterminer

**Exercice pratique :**
Créez des règles iptables pour voir différents états :

```bash
# Bloquer le port 8080
sudo iptables -A INPUT -p tcp --dport 8080 -j DROP

# Scanner le port 8080
nmap -p 8080 localhost --reason

# État attendu : filtered

# Supprimer la règle
sudo iptables -D INPUT -p tcp --dport 8080 -j DROP
```

---

#### Exercice 2.3.2 : Analyse de firewall

```bash
# Détection de firewall avec ACK scan
sudo nmap -sA -p 1-1000 localhost

# Détection de firewall avec Window scan
sudo nmap -sW -p 1-1000 localhost

# Test avec différents flags
sudo nmap -sF -p 80 localhost  # FIN
sudo nmap -sX -p 80 localhost  # Xmas
sudo nmap -sN -p 80 localhost  # Null
```

**Tableau d'analyse :**
| Port | État normal | Avec firewall | Conclusion |
|------|-------------|---------------|------------|
| 22   |             |               |            |
| 80   |             |               |            |
| 443  |             |               |            |

---

### Partie 2.4 : Introduction aux Scripts NSE

#### Exercice 2.4.1 : Scripts par défaut

```bash
# Exécuter les scripts par défaut
nmap -sC localhost

# Équivalent à
nmap --script=default localhost

# Lister tous les scripts disponibles
ls /usr/share/nmap/scripts/ | wc -l
ls /usr/share/nmap/scripts/ | head -20

# Informations sur un script
nmap --script-help http-title

# Mettre à jour la base de scripts
sudo nmap --script-updatedb
```

---

#### Exercice 2.4.2 : Catégories de scripts

```bash
# Scripts de découverte
nmap --script=discovery localhost

# Scripts d'authentification
nmap --script=auth localhost

# Scripts de bruteforce
nmap --script=brute localhost

# Scripts de vulnérabilité
nmap --script=vuln localhost

# Scripts malware
nmap --script=malware localhost

# Combiner plusieurs catégories
nmap --script="default,safe" localhost

# Exclure une catégorie
nmap --script="default and not brute" localhost
```

**Catégories disponibles :**
- `auth` : Authentification
- `broadcast` : Découverte par broadcast
- `brute` : Attaques par force brute
- `default` : Scripts par défaut
- `discovery` : Découverte d'informations
- `dos` : Déni de service (à utiliser avec précaution)
- `exploit` : Exploitation de vulnérabilités
- `external` : Scripts utilisant des ressources externes
- `fuzzer` : Fuzzing
- `intrusive` : Scripts intrusifs
- `malware` : Détection de malware
- `safe` : Scripts non intrusifs
- `version` : Détection de versions
- `vuln` : Détection de vulnérabilités

---

#### Exercice 2.4.3 : Scripts HTTP spécifiques

```bash
# Titre des pages web
nmap --script http-title -p 80 localhost

# Énumération de répertoires
nmap --script http-enum -p 80 localhost

# Headers HTTP
nmap --script http-headers -p 80 localhost

# Méthodes HTTP autorisées
nmap --script http-methods -p 80 localhost

# Robots.txt
nmap --script http-robots.txt -p 80 localhost

# Serveur et version
nmap --script http-server-header -p 80 localhost

# Tous les scripts HTTP
nmap --script "http-*" -p 80 localhost
```

**Tâche pratique :**
Installez WordPress localement et scannez-le :

```bash
# Installation rapide de WordPress (optionnel)
sudo apt install wordpress -y

# Scan avec scripts web
nmap --script http-wordpress-enum,http-wordpress-users -p 80 localhost
```

---

#### Exercice 2.4.4 : Scripts avec arguments

```bash
# Script avec argument
nmap --script http-title --script-args http.useragent="Mozilla/5.0" -p 80 localhost

# Multiples arguments
nmap --script http-enum --script-args \
  http-enum.basepath=/admin/,http-enum.displayall=true \
  -p 80 localhost

# Arguments depuis un fichier
echo "http.useragent=CustomBot" > args.txt
nmap --script http-title --script-args-file args.txt -p 80 localhost
```

---

### Partie 2.5 : Évasion Basique et Fragmentation

#### Exercice 2.5.1 : Fragmentation de paquets

```bash
# Fragmentation basique (8 octets)
nmap -f localhost

# Fragmentation personnalisée (16 octets)
nmap -ff localhost

# MTU personnalisé (doit être multiple de 8)
nmap --mtu 24 localhost
```

---

#### Exercice 2.5.2 : Decoys (leurres)

```bash
# Utiliser des IPs leurres aléatoires
nmap -D RND:10 localhost

# Utiliser des IPs leurres spécifiques
nmap -D 192.168.1.100,192.168.1.101,ME localhost

# ME représente votre vraie IP dans la liste
```

---

#### Exercice 2.5.3 : Modification de l'adresse source

```bash
# Spoofer l'IP source (nécessite configuration réseau)
# ATTENTION : Ne fonctionne que dans certains contextes
sudo nmap -S 192.168.1.50 localhost

# Spécifier l'interface réseau
sudo nmap -e eth0 localhost

# Utiliser une IP source et interface spécifiques
sudo nmap -S 192.168.1.50 -e eth0 localhost
```

---

### 🎯 QUIZ NIVEAU 2

1. Quelle est la différence entre un scan SYN et un scan Connect ?
2. Quel template de timing utiliseriez-vous pour un scan IDS-évitant ?
3. Comment interpréter un port en état "filtered" ?
4. Quelle catégorie NSE utiliser pour détecter des vulnérabilités ?
5. Comment fragmenter les paquets en morceaux de 16 octets ?

**Commandes à mémoriser (Niveau 2) :**
```bash
nmap -T4 <target>                    # Scan rapide
sudo nmap -sS -sV -O <target>        # Scan furtif + détection
nmap --script=vuln <target>          # Scan de vulnérabilités
nmap -f -D RND:10 <target>           # Évasion basique
nmap --min-rate 300 <target>         # Contrôle du débit
```

---

<a name="niveau-3"></a>
## 🟠 NIVEAU 3 : CONFIRMÉ (3-4 heures)

### Objectifs
- Créer et personnaliser des scripts NSE
- Automatiser les scans complexes
- Intégrer Nmap dans des workflows
- Utiliser des techniques d'évasion avancées

### Partie 3.1 : Scripts NSE Avancés

#### Exercice 3.1.1 : Analyse approfondie avec NSE

```bash
# Détection de vulnérabilités critiques
nmap --script vuln,exploit -p- localhost

# Énumération SMB complète
sudo nmap --script "smb-enum-*" -p 445 <target>

# Bruteforce SSH (à utiliser éthiquement)
nmap --script ssh-brute --script-args \
  userdb=users.txt,passdb=pass.txt -p 22 <target>

# Détection SSL/TLS
nmap --script ssl-enum-ciphers,ssl-cert -p 443 <target>

# Analyse DNS complète
nmap --script "dns-*" -p 53 <dns_server>
```

---

#### Exercice 3.1.2 : Création de votre premier script NSE

**Anatomie d'un script NSE :**
```lua
-- Créer le fichier : custom-banner.nse
local shortport = require "shortport"
local stdnse = require "stdnse"

description = [[
Script de démonstration qui récupère la bannière d'un service.
]]

author = "Votre Nom"
license = "Same as Nmap--See https://nmap.org/book/man-legal.html"
categories = {"default", "safe", "discovery"}

-- Règle d'exécution : ports TCP ouverts
portrule = shortport.port_or_service({22, 80, 443}, {"ssh", "http", "https"})

-- Action principale
action = function(host, port)
  local output = {}
  
  table.insert(output, "Analyse du port " .. port.number)
  table.insert(output, "Service: " .. port.service)
  table.insert(output, "État: " .. port.state)
  
  return stdnse.format_output(true, output)
end
```

**Installation et test :**
```bash
# Créer le script
sudo nano /usr/share/nmap/scripts/custom-banner.nse
# (Copier le code ci-dessus)

# Mettre à jour la base de scripts
sudo nmap --script-updatedb

# Tester le script
nmap --script custom-banner localhost

# Déboguer le script
nmap --script custom-banner localhost -d
```

---

#### Exercice 3.1.3 : Script NSE avec arguments personnalisés

```lua
-- Fichier : http-custom-scan.nse
local http = require "http"
local shortport = require "shortport"
local stdnse = require "stdnse"

description = [[
Script personnalisé pour tester des chemins HTTP spécifiques.
]]

author = "Votre Nom"
categories = {"discovery", "safe"}

portrule = shortport.http

-- Fonction action avec arguments
action = function(host, port)
  local path = stdnse.get_script_args("http-custom-scan.path") or "/"
  local method = stdnse.get_script_args("http-custom-scan.method") or "GET"
  
  local response = http.generic_request(host, port, method, path)
  
  if response and response.status then
    return string.format("Status: %d, Taille: %d octets", 
                        response.status, 
                        #response.body)
  else
    return "Pas de réponse"
  end
end
```

**Utilisation :**
```bash
nmap --script http-custom-scan \
  --script-args http-custom-scan.path=/admin,http-custom-scan.method=POST \
  -p 80 localhost
```

---

#### Exercice 3.1.4 : Script NSE avec base de données

```lua
-- Fichier : port-logger.nse
local nmap = require "nmap"
local stdnse = require "stdnse"
local tab = require "tab"

description = [[
Enregistre tous les ports ouverts dans un format tabulaire.
]]

categories = {"safe", "discovery"}

-- S'exécute après le scan de tous les ports
postrule = function()
  return true
end

action = function()
  local output = tab.new(4)
  tab.addrow(output, "IP", "Port", "Service", "Version")
  
  -- Parcourir tous les hôtes scannés
  for _, host in ipairs(nmap.registry.hosts) do
    if host.up then
      for _, port in ipairs(host.ports) do
        if port.state == "open" then
          tab.addrow(output, 
                    host.ip, 
                    port.number, 
                    port.service or "unknown",
                    port.version or "N/A")
        end
      end
    end
  end
  
  return tab.dump(output)
end
```

---

### Partie 3.2 : Automatisation et Scripting

#### Exercice 3.2.1 : Script Bash d'automatisation

```bash
#!/bin/bash
# Fichier : auto_scan.sh
# Script d'automatisation de scan Nmap

# Configuration
TARGET="$1"
OUTPUT_DIR="./scans_$(date +%Y%m%d_%H%M%S)"
REPORT_FILE="$OUTPUT_DIR/rapport.html"

# Vérification des arguments
if [ -z "$TARGET" ]; then
    echo "Usage: $0 <target>"
    exit 1
fi

# Création du répertoire de sortie
mkdir -p "$OUTPUT_DIR"

echo "[+] Début du scan de $TARGET"
echo "[+] Les résultats seront dans $OUTPUT_DIR"

# Phase 1 : Découverte d'hôtes
echo "[+] Phase 1 : Découverte d'hôtes"
nmap -sn "$TARGET" -oA "$OUTPUT_DIR/01_discovery"

# Phase 2 : Scan rapide des ports communs
echo "[+] Phase 2 : Scan rapide"
nmap -T4 -F "$TARGET" -oA "$OUTPUT_DIR/02_quick_scan"

# Phase 3 : Scan complet
echo "[+] Phase 3 : Scan complet des ports"
nmap -p- "$TARGET" -oA "$OUTPUT_DIR/03_full_scan"

# Phase 4 : Détection de services et OS
echo "[+] Phase 4 : Détection de services"
sudo nmap -sV -O "$TARGET" -oA "$OUTPUT_DIR/04_services"

# Phase 5 : Scripts de vulnérabilités
echo "[+] Phase 5 : Analyse de vulnérabilités"
nmap --script vuln "$TARGET" -oA "$OUTPUT_DIR/05_vulnerabilities"

# Phase 6 : Scripts par défaut
echo "[+] Phase 6 : Scripts par défaut"
nmap -sC "$TARGET" -oA "$OUTPUT_DIR/06_default_scripts"

# Génération du rapport
echo "[+] Génération du rapport HTML"
xsltproc "$OUTPUT_DIR/06_default_scripts.xml" -o "$REPORT_FILE"

echo "[+] Scan terminé !"
echo "[+] Rapport disponible : $REPORT_FILE"
```

**Utilisation :**
```bash
chmod +x auto_scan.sh
./auto_scan.sh 192.168.1.1
```

---

#### Exercice 3.2.2 : Script Python d'intégration

```python
#!/usr/bin/env python3
# Fichier : nmap_parser.py
"""
Parser de résultats Nmap en Python
"""

import xml.etree.ElementTree as ET
import sys
import json

def parse_nmap_xml(xml_file):
    """Parse un fichier XML Nmap et retourne les résultats"""
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    results = {
        'scan_info': {},
        'hosts': []
    }
    
    # Informations du scan
    scan_info = root.find('scaninfo')
    if scan_info is not None:
        results['scan_info'] = scan_info.attrib
    
    # Parcourir les hôtes
    for host in root.findall('host'):
        host_data = {
            'addresses': {},
            'hostnames': [],
            'ports': [],
            'os': []
        }
        
        # Adresses
        for addr in host.findall('address'):
            addr_type = addr.get('addrtype')
            host_data['addresses'][addr_type] = addr.get('addr')
        
        # Noms d'hôtes
        hostnames = host.find('hostnames')
        if hostnames is not None:
            for hostname in hostnames.findall('hostname'):
                host_data['hostnames'].append({
                    'name': hostname.get('name'),
                    'type': hostname.get('type')
                })
        
        # Ports
        ports = host.find('ports')
        if ports is not None:
            for port in ports.findall('port'):
                port_data = {
                    'port': port.get('portid'),
                    'protocol': port.get('protocol'),
                    'state': port.find('state').get('state')
                }
                
                service = port.find('service')
                if service is not None:
                    port_data['service'] = {
                        'name': service.get('name'),
                        'product': service.get('product'),
                        'version': service.get('version')
                    }
                
                host_data['ports'].append(port_data)
        
        # OS
        os_elem = host.find('os')
        if os_elem is not None:
            for osmatch in os_elem.findall('osmatch'):
                host_data['os'].append({
                    'name': osmatch.get('name'),
                    'accuracy': osmatch.get('accuracy')
                })
        
        results['hosts'].append(host_data)
    
    return results

def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <nmap_xml_file>")
        sys.exit(1)
    
    xml_file = sys.argv[1]
    results = parse_nmap_xml(xml_file)
    
    # Affichage formaté
    print(json.dumps(results, indent=2))
    
    # Statistiques
    print(f"\n[+] Nombre d'hôtes trouvés : {len(results['hosts'])}")
    for host in results['hosts']:
        ip = host['addresses'].get('ipv4', 'N/A')
        print(f"\n[+] Hôte : {ip}")
        print(f"    Ports ouverts : {len(host['ports'])}")
        for port in host['ports']:
            if port['state'] == 'open':
                service = port.get('service', {}).get('name', 'unknown')
                print(f"    - {port['port']}/{port['protocol']} : {service}")

if __name__ == '__main__':
    main()
```

**Installation et utilisation :**
```bash
chmod +x nmap_parser.py

# Scanner et parser
nmap -sV localhost -oX scan.xml
./nmap_parser.py scan.xml
```

---

#### Exercice 3.2.3 : Intégration dans un pipeline CI/CD

```yaml
# Fichier : .gitlab-ci.yml (exemple GitLab CI)
stages:
  - scan
  - analyze
  - report

security_scan:
  stage: scan
  image: instrumentisto/nmap:latest
  script:
    - nmap -sV -oX nmap_results.xml $TARGET_IP
  artifacts:
    paths:
      - nmap_results.xml
    expire_in: 1 week

vulnerability_check:
  stage: analyze
  image: instrumentisto/nmap:latest
  script:
    - nmap --script vuln -oX vuln_results.xml $TARGET_IP
  artifacts:
    paths:
      - vuln_results.xml
    expire_in: 1 week

generate_report:
  stage: report
  image: python:3.9
  script:
    - pip install jinja2
    - python3 generate_report.py nmap_results.xml vuln_results.xml
  artifacts:
    paths:
      - security_report.html
    expire_in: 1 month
```

---

### Partie 3.3 : Techniques d'Évasion Avancées

#### Exercice 3.3.1 : Évasion IDS/IPS

```bash
# Randomisation de l'ordre des hôtes
nmap --randomize-hosts 192.168.1.0/24

# Spoofing de MAC address
sudo nmap --spoof-mac Dell localhost
sudo nmap --spoof-mac 0 localhost  # MAC aléatoire

# Combinaison de techniques d'évasion
sudo nmap -f -T2 -D RND:10 --spoof-mac Apple \
  --randomize-hosts --data-length 25 <target>

# Ajout de données aléatoires aux paquets
nmap --data-length 50 localhost

# Source port spécifique (ex: 53 pour DNS)
sudo nmap -g 53 <target>
sudo nmap --source-port 53 <target>
```

---

#### Exercice 3.3.2 : Techniques de tunneling

```bash
# Utiliser un proxy SOCKS
# Configurer proxychains d'abord
sudo apt install proxychains4 -y

# Éditer /etc/proxychains4.conf
# Ajouter : socks5 127.0.0.1 1080

# Scanner via proxy
proxychains nmap -sT -Pn <target>

# Via Tor (si installé)
proxychains nmap -sT -Pn -p 80,443 <target>
```

---

#### Exercice 3.3.3 : Badsum et paquets malformés

```bash
# Checksum invalide (détection IDS)
sudo nmap --badsum <target>

# TTL personnalisé
sudo nmap --ttl 128 <target>

# IP options
sudo nmap --ip-options "R" <target>  # Record route
sudo nmap --ip-options "T" <target>  # Timestamp
```

---

### Partie 3.4 : Analyse Réseau Avancée

#### Exercice 3.4.1 : IPv6 scanning

```bash
# Scan IPv6
nmap -6 ::1

# Scan d'un réseau IPv6 local
nmap -6 fe80::/64

# Scan avec détection de services IPv6
nmap -6 -sV <ipv6_address>

# Découverte d'hôtes IPv6
nmap -6 -sn <ipv6_network>
```

---

#### Exercice 3.4.2 : Traceroute avancé

```bash
# Traceroute avec Nmap
sudo nmap --traceroute <target>

# Traceroute avec scripts
sudo nmap --traceroute --script traceroute-geolocation <target>

# Combiner avec scan de ports
sudo nmap -sS -p 80,443 --traceroute <target>
```

---

#### Exercice 3.4.3 : Analyse de firewall

```bash
# Script de détection de firewall
nmap --script=firewalk --script-args=firewalk.max-ttl=20 \
  --traceroute <target>

# Détection de règles de firewall
sudo nmap -sA -T4 -p- <target> --reason

# Analyse des règles de filtrage
sudo nmap -sW -p 1-1000 <target>
```

---

### 🎯 QUIZ NIVEAU 3

1. Comment créer un script NSE qui s'exécute sur tous les ports HTTP ?
2. Quelle bibliothèque Lua utiliser pour les requêtes HTTP dans NSE ?
3. Comment combiner fragmentation et decoys efficacement ?
4. Quelle option utiliser pour spoofer une adresse MAC ?
5. Comment parser un fichier XML Nmap en Python ?

**Commandes à mémoriser (Niveau 3) :**
```bash
nmap --script vuln,exploit <target>         # Vuln scan complet
sudo nmap -f -T2 -D RND:10 <target>         # Évasion avancée
nmap --script custom-script.nse <target>    # Script personnalisé
nmap -6 -sV <ipv6_target>                   # Scan IPv6
proxychains nmap -sT -Pn <target>           # Via proxy
```

---

<a name="niveau-4"></a>
## 🔴 NIVEAU 4 : EXPERT (2-3 heures)

### Objectifs
- Maîtriser les techniques avancées de reconnaissance
- Optimiser pour des scans à grande échelle
- Combiner Nmap avec d'autres outils
- Développer des méthodologies d'audit complètes

### Partie 4.1 : Reconnaissance Avancée

#### Exercice 4.1.1 : OSINT et reconnaissance passive

```bash
# Utilisation de whois avec Nmap
nmap --script whois-domain google.com

# Recherche DNS
nmap --script dns-brute <domain>
nmap --script dns-zone-transfer --script-args dns-zone-transfer.domain=<domain> <dns_server>

# Énumération de sous-domaines
nmap --script dns-brute --script-args dns-brute.threads=10,dns-brute.hostlist=./subdomains.txt <domain>

# Analyse de certificats SSL
nmap --script ssl-cert,ssl-enum-ciphers -p 443 <target>

# Récupération d'emails
nmap --script http-grep --script-args http-grep.match='[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}' -p 80,443 <target>
```

---

#### Exercice 4.1.2 : Fingerprinting avancé

```bash
# Fingerprinting SSH
nmap --script ssh2-enum-algos,ssh-hostkey -p 22 <target>

# Fingerprinting HTTP
nmap --script http-methods,http-headers,http-server-header,http-title \
  -p 80,443 <target>

# Fingerprinting SMB
sudo nmap --script smb-os-discovery,smb-protocols -p 445 <target>

# Fingerprinting SNMP
sudo nmap -sU --script snmp-sysdescr,snmp-info -p 161 <target>
```

---

#### Exercice 4.1.3 : Scan de protocoles spécifiques

```bash
# Scan SCADA/ICS
nmap --script modbus-discover -p 502 <target>
nmap --script s7-info -p 102 <target>

# Scan base de données
nmap --script mysql-info,mysql-databases -p 3306 <target>
nmap --script mongodb-info -p 27017 <target>
nmap --script redis-info -p 6379 <target>

# Scan VoIP
nmap --script sip-methods,sip-enum-users -p 5060 <target>
```

---

### Partie 4.2 : Scans à Grande Échelle

#### Exercice 4.2.1 : Optimisation pour Internet scanning

```bash
# Scan rapide d'une classe B
sudo nmap -sS -T4 --min-rate 1000 --max-retries 1 \
  -p 80,443,8080,8443 192.168.0.0/16 -oG results.grep

# Scan massif avec masscan (alternative)
sudo apt install masscan -y
sudo masscan -p80,443 192.168.0.0/16 --rate=10000 -oL masscan_results.txt

# Combiner masscan + nmap pour précision
# 1. Masscan rapide pour trouver les ports ouverts
sudo masscan -p1-65535 <target> --rate=10000 -oL masscan.txt

# 2. Parser et scanner avec Nmap pour la précision
grep "open" masscan.txt | awk '{print $4,$3}' > open_ports.txt
# Puis scanner ces ports avec nmap -sV
```

---

#### Exercice 4.2.2 : Distribution des scans

```bash
# Script de distribution de scan sur plusieurs machines
#!/bin/bash
# distribute_scan.sh

TARGETS_FILE="targets.txt"
NUM_WORKERS=4

# Diviser les cibles
split -n l/$NUM_WORKERS $TARGETS_FILE targets_part_

# Lancer les scans en parallèle
for i in $(seq 1 $NUM_WORKERS); do
    nmap -iL targets_part_0$i -oA scan_part_$i &
done

wait
echo "Tous les scans terminés"

# Fusionner les résultats
cat scan_part_*.nmap > scan_complet.nmap
```

---

#### Exercice 4.2.3 : Gestion de la bande passante

```bash
# Limitation stricte de la bande passante
sudo nmap --max-rate 50 --max-parallelism 10 <target>

# Scan lent pour éviter la détection
sudo nmap -T1 --scan-delay 5s --max-scan-delay 10s <target>

# Configuration pour réseaux lents
nmap --initial-rtt-timeout 2s --max-rtt-timeout 4s \
  --max-retries 1 <target>
```

---

### Partie 4.3 : Intégration avec Autres Outils

#### Exercice 4.3.1 : Nmap + Metasploit

```bash
# Installer Metasploit
curl https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb > msfinstall
chmod 755 msfinstall
sudo ./msfinstall

# Utiliser Nmap depuis Metasploit
msfconsole
> db_nmap -sV <target>
> hosts
> services
> vulns

# Export depuis Nmap vers Metasploit
nmap -sV -oX scan.xml <target>
# Dans msfconsole :
> db_import scan.xml
```

---

#### Exercice 4.3.2 : Nmap + Nessus/OpenVAS

```bash
# Installation d'OpenVAS
sudo apt install openvas -y
sudo gvm-setup
sudo gvm-start

# Export Nmap vers OpenVAS
nmap -sV -oX scan_for_openvas.xml <target>
# Importer dans OpenVAS via l'interface web

# Alternative : utiliser les résultats Nmap pour cibler OpenVAS
nmap -sV <target> -oG - | awk '/open/{print $2}' > live_hosts.txt
```

---

#### Exercice 4.3.3 : Nmap + Wireshark

```bash
# Capturer le trafic Nmap avec tcpdump
sudo tcpdump -i eth0 -w nmap_traffic.pcap &
TCPDUMP_PID=$!

# Lancer le scan
sudo nmap -sS -p 1-1000 <target>

# Arrêter la capture
sudo kill $TCPDUMP_PID

# Analyser avec Wireshark
wireshark nmap_traffic.pcap &

# Ou avec tshark (CLI)
tshark -r nmap_traffic.pcap -Y "tcp.flags.syn==1 && tcp.flags.ack==0"
```

---

### Partie 4.4 : Détection et Contre-mesures

#### Exercice 4.4.1 : Détecter les scans Nmap (côté défenseur)

```bash
# Installation de Snort (IDS)
sudo apt install snort -y

# Règle Snort pour détecter les scans SYN
# /etc/snort/rules/local.rules
alert tcp any any -> $HOME_NET any (flags:S; \
  msg:"Possible SYN scan"; sid:1000001; rev:1;)

# Règle pour détecter les scans Xmas
alert tcp any any -> $HOME_NET any (flags:FPU; \
  msg:"Possible Xmas scan"; sid:1000002; rev:1;)

# Analyser les logs avec fail2ban
sudo apt install fail2ban -y

# Configuration fail2ban pour bloquer les scans
# /etc/fail2ban/jail.local
[nmap-scan]
enabled = true
filter = nmap-scan
logpath = /var/log/syslog
maxretry = 3
bantime = 3600
```

---

#### Exercice 4.4.2 : Techniques anti-scan

```bash
# Script pour randomiser les réponses de ports
# (tarpit, honeypot)

# Installation de portspoof
sudo apt install portspoof -y

# Configuration pour émuler tous les services
sudo portspoof -c /etc/portspoof.conf -s /etc/portspoof_signatures

# Utilisation de iptables pour ralentir les scans
sudo iptables -A INPUT -p tcp --dport 80 -m state --state NEW \
  -m recent --set
sudo iptables -A INPUT -p tcp --dport 80 -m state --state NEW \
  -m recent --update --seconds 60 --hitcount 10 -j DROP
```

---

#### Exercice 4.4.3 : Audit de votre propre défense

```bash
# Script d'auto-audit
#!/bin/bash
# self_audit.sh

echo "[+] Test 1 : Scan SYN basique"
sudo nmap -sS localhost

echo "[+] Test 2 : Scan furtif avec fragmentation"
sudo nmap -f -sS localhost

echo "[+] Test 3 : Scan lent (évasion IDS)"
sudo nmap -T1 localhost

echo "[+] Test 4 : Scan avec decoys"
sudo nmap -D RND:10 localhost

echo "[+] Vérification des logs..."
sudo tail -50 /var/log/syslog | grep -i "scan\|syn\|port"
```

---

### Partie 4.5 : Méthodologies d'Audit Professionnelles

#### Exercice 4.5.1 : Méthodologie PTES (Penetration Testing Execution Standard)

```bash
#!/bin/bash
# ptes_scan.sh - Scan selon la méthodologie PTES

TARGET="$1"
OUTPUT="./pentest_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUTPUT"

# Phase 1 : Intelligence Gathering
echo "[Phase 1] Intelligence Gathering"
nmap --script whois-domain,dns-brute "$TARGET" -oA "$OUTPUT/01_intel"

# Phase 2 : Vulnerability Analysis - Discovery
echo "[Phase 2] Network Discovery"
nmap -sn "$TARGET" -oA "$OUTPUT/02_discovery"

# Phase 3 : Vulnerability Analysis - Port Scanning
echo "[Phase 3] Port Scanning"
sudo nmap -sS -p- "$TARGET" -oA "$OUTPUT/03_ports"

# Phase 4 : Vulnerability Analysis - Service Enumeration
echo "[Phase 4] Service Enumeration"
sudo nmap -sV -sC "$TARGET" -oA "$OUTPUT/04_services"

# Phase 5 : Vulnerability Analysis - OS Detection
echo "[Phase 5] OS Detection"
sudo nmap -O "$TARGET" -oA "$OUTPUT/05_os"

# Phase 6 : Exploitation - Vulnerability Scanning
echo "[Phase 6] Vulnerability Scanning"
nmap --script vuln "$TARGET" -oA "$OUTPUT/06_vulns"

# Génération du rapport
echo "[+] Génération du rapport"
cat > "$OUTPUT/RAPPORT.md" << EOF
# Rapport d'Audit - $TARGET
Date : $(date)

## Résumé Exécutif
[À compléter manuellement]

## Méthodologie
Scan effectué selon la méthodologie PTES

## Résultats détaillés
Voir les fichiers dans $OUTPUT/
EOF

echo "[+] Audit terminé : $OUTPUT"
```

---

#### Exercice 4.5.2 : Script d'audit Web complet

```bash
#!/bin/bash
# web_audit.sh

TARGET="$1"
OUTPUT="./web_audit_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUTPUT"

echo "[+] Audit web de $TARGET"

# Découverte de ports web
echo "[1/6] Découverte de services web"
nmap -p 80,443,8080,8443 --open "$TARGET" -oA "$OUTPUT/web_ports"

# Énumération HTTP
echo "[2/6] Énumération HTTP"
nmap --script "http-*" -p 80,443,8080,8443 "$TARGET" -oA "$OUTPUT/http_enum"

# Technologies web
echo "[3/6] Détection de technologies"
nmap --script http-waf-detect,http-waf-fingerprint -p 80,443 "$TARGET" -oA "$OUTPUT/waf"

# Vulnérabilités web
echo "[4/6] Scan de vulnérabilités web"
nmap --script "http-vuln-*" -p 80,443 "$TARGET" -oA "$OUTPUT/web_vulns"

# SSL/TLS
echo "[5/6] Analyse SSL/TLS"
nmap --script ssl-enum-ciphers,ssl-cert,ssl-known-key -p 443 "$TARGET" -oA "$OUTPUT/ssl"

# Headers de sécurité
echo "[6/6] Vérification des headers de sécurité"
nmap --script http-security-headers -p 80,443 "$TARGET" -oA "$OUTPUT/security_headers"

echo "[+] Audit web terminé : $OUTPUT"
```

---

#### Exercice 4.5.3 : Rapport automatisé avec génération HTML

```python
#!/usr/bin/env python3
# generate_html_report.py

import xml.etree.ElementTree as ET
import sys
from datetime import datetime

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Rapport de Scan Nmap</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        h2 {{ color: #666; border-bottom: 2px solid #ddd; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
        .open {{ color: green; font-weight: bold; }}
        .closed {{ color: red; }}
        .filtered {{ color: orange; }}
        .summary {{ background-color: #f0f0f0; padding: 15px; margin: 20px 0; }}
    </style>
</head>
<body>
    <h1>Rapport de Scan Nmap</h1>
    <div class="summary">
        <strong>Date du scan :</strong> {date}<br>
        <strong>Nombre d'hôtes scannés :</strong> {num_hosts}<br>
        <strong>Nombre de ports ouverts :</strong> {num_open_ports}
    </div>
    
    {hosts_html}
</body>
</html>
"""

def parse_and_generate_report(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    hosts_html = ""
    total_open_ports = 0
    num_hosts = 0
    
    for host in root.findall('host'):
        num_hosts += 1
        
        # Adresse IP
        addr = host.find('address').get('addr')
        hosts_html += f"<h2>Hôte : {addr}</h2>"
        
        # Tableau des ports
        hosts_html += "<table><tr><th>Port</th><th>Protocole</th><th>État</th><th>Service</th><th>Version</th></tr>"
        
        ports = host.find('ports')
        if ports is not None:
            for port in ports.findall('port'):
                port_num = port.get('portid')
                protocol = port.get('protocol')
                state = port.find('state').get('state')
                
                state_class = state
                if state == 'open':
                    total_open_ports += 1
                
                service_name = "unknown"
                version = "N/A"
                service = port.find('service')
                if service is not None:
                    service_name = service.get('name', 'unknown')
                    product = service.get('product', '')
                    version_num = service.get('version', '')
                    version = f"{product} {version_num}".strip()
                
                hosts_html += f"""
                <tr>
                    <td>{port_num}</td>
                    <td>{protocol}</td>
                    <td class="{state_class}">{state}</td>
                    <td>{service_name}</td>
                    <td>{version}</td>
                </tr>
                """
        
        hosts_html += "</table>"
    
    # Génération du HTML final
    html = HTML_TEMPLATE.format(
        date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        num_hosts=num_hosts,
        num_open_ports=total_open_ports,
        hosts_html=hosts_html
    )
    
    return html

def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <nmap_xml_file>")
        sys.exit(1)
    
    xml_file = sys.argv[1]
    output_file = xml_file.replace('.xml', '_report.html')
    
    html_report = parse_and_generate_report(xml_file)
    
    with open(output_file, 'w') as f:
        f.write(html_report)
    
    print(f"[+] Rapport généré : {output_file}")

if __name__ == '__main__':
    main()
```

**Utilisation :**
```bash
chmod +x generate_html_report.py
nmap -sV localhost -oX scan.xml
./generate_html_report.py scan.xml
firefox scan_report.html
```

---

### 🎯 QUIZ NIVEAU 4

1. Quelle est la différence entre Nmap et Masscan ?
2. Comment intégrer Nmap dans un pipeline CI/CD ?
3. Quels sont les signes d'un scan Nmap dans les logs ?
4. Comment créer un rapport HTML personnalisé depuis XML ?
5. Quelle méthodologie suivre pour un audit professionnel ?

**Commandes à mémoriser (Niveau 4) :**
```bash
# Scan massif optimisé
sudo nmap -sS -T4 --min-rate 1000 -p- <subnet> -oA scan

# OSINT complet
nmap --script "dns-*,whois-*,ssl-cert" <target>

# Audit web complet
nmap --script "http-*" -p 80,443,8080,8443 <target>

# Export Metasploit
nmap -sV -oX scan.xml <target>

# Scan distribué
split -n l/4 targets.txt && parallel nmap -iL {} ::: targets_*
```

---

<a name="projet-final"></a>
## 🏆 PROJET FINAL : AUDIT DE SÉCURITÉ COMPLET

### Objectif
Réaliser un audit de sécurité complet d'une infrastructure simulée en combinant toutes les compétences acquises.

### Scénario
Vous êtes un consultant en sécurité engagé pour auditer l'infrastructure réseau d'une PME fictive. Vous devez :

1. Cartographier le réseau
2. Identifier les services exposés
3. Détecter les vulnérabilités
4. Proposer des recommandations
5. Fournir un rapport professionnel

### Infrastructure de Test
```bash
# Créer un environnement de test avec Docker
# docker-compose.yml

version: '3'
services:
  web:
    image: nginx:latest
    ports:
      - "80:80"
      - "443:443"
  
  db:
    image: mysql:5.7
    ports:
      - "3306:3306"
    environment:
      MYSQL_ROOT_PASSWORD: weakpassword
  
  ftp:
    image: fauria/vsftpd
    ports:
      - "21:21"
      - "21000-21010:21000-21010"
  
  ssh:
    image: linuxserver/openssh-server
    ports:
      - "2222:2222"
```

**Lancement :**
```bash
docker-compose up -d
```

### Mission : Script d'Audit Complet

Créez un script `audit_complet.sh` qui effectue :

```bash
#!/bin/bash
# audit_complet.sh - Projet Final

TARGET="${1:-127.0.0.1}"
REPORT_DIR="./audit_final_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$REPORT_DIR"

echo "========================================="
echo "  AUDIT DE SÉCURITÉ - PROJET FINAL"
echo "  Cible : $TARGET"
echo "  Date  : $(date)"
echo "========================================="

# À COMPLÉTER : Implémentez les phases suivantes

# Phase 1 : Reconnaissance passive
echo "[Phase 1/8] Reconnaissance passive"
# TODO: WHOIS, DNS, etc.

# Phase 2 : Découverte d'hôtes
echo "[Phase 2/8] Découverte d'hôtes"
# TODO: Ping scan, ARP scan

# Phase 3 : Scan de ports complet
echo "[Phase 3/8] Scan de ports"
# TODO: Scan SYN de tous les ports

# Phase 4 : Énumération de services
echo "[Phase 4/8] Énumération de services"
# TODO: Détection de versions

# Phase 5 : Détection d'OS
echo "[Phase 5/8] Détection de système d'exploitation"
# TODO: -O scan

# Phase 6 : Scan de vulnérabilités
echo "[Phase 6/8] Scan de vulnérabilités"
# TODO: Scripts vuln

# Phase 7 : Tests d'authentification
echo "[Phase 7/8] Tests d'authentification"
# TODO: Tests de passwords faibles

# Phase 8 : Génération du rapport
echo "[Phase 8/8] Génération du rapport"
# TODO: Compiler tous les résultats

echo "[+] Audit terminé : $REPORT_DIR"
```

### Livrables Attendus

1. **Script d'audit complet** fonctionnel
2. **Rapport HTML** avec toutes les vulnérabilités
3. **Fichier de recommandations** (Markdown)
4. **Preuve de concept** (screenshots ou logs)
5. **Documentation** du processus

### Critères d'Évaluation

- ✅ Tous les services sont découverts
- ✅ Les vulnérabilités sont identifiées
- ✅ Les recommandations sont pertinentes
- ✅ Le rapport est professionnel
- ✅ Le code est propre et commenté
- ✅ Les techniques d'évasion sont utilisées
- ✅ L'automatisation est complète

---

## 📚 RESSOURCES SUPPLÉMENTAIRES

### Documentation Officielle
- Site officiel : https://nmap.org
- Livre de référence : https://nmap.org/book/
- NSE Scripts : https://nmap.org/nsedoc/

### Commandes de Référence Rapide

```bash
# DÉCOUVERTE
nmap -sn <subnet>                  # Ping scan
nmap -sL <subnet>                  # Liste sans scanner

# SCANS DE BASE
nmap <target>                      # Scan basique (1000 ports)
nmap -p- <target>                  # Tous les ports
nmap -F <target>                   # Scan rapide (100 ports)

# DÉTECTION
nmap -sV <target>                  # Versions
sudo nmap -O <target>              # OS
sudo nmap -A <target>              # Agressif (tout)

# SCRIPTS
nmap -sC <target>                  # Scripts par défaut
nmap --script=<script> <target>    # Script spécifique
nmap --script=vuln <target>        # Vulnérabilités

# ÉVASION
sudo nmap -f <target>              # Fragmentation
nmap -D RND:10 <target>            # Decoys
sudo nmap -sS <target>             # SYN scan (furtif)

# PERFORMANCE
nmap -T4 <target>                  # Timing agressif
nmap --min-rate 300 <target>       # Rate minimum

# SORTIE
nmap -oN file.txt <target>         # Normal
nmap -oX file.xml <target>         # XML
nmap -oG file.grep <target>        # Greppable
nmap -oA basename <target>         # Tous
```

### Environnements de Pratique

1. **Metasploitable2** : VM vulnérable pour tests
2. **DVWA** : Application web vulnérable
3. **HackTheBox** : Plateformes d'entraînement
4. **TryHackMe** : Labs interactifs
5. **VulnHub** : VMs vulnérables

### Outils Complémentaires

- **Masscan** : Scanner ultra-rapide
- **Zmap** : Scanner Internet
- **Nikto** : Scanner web
- **Metasploit** : Framework d'exploitation
- **Wireshark** : Analyseur de paquets

---

## 🎓 CERTIFICATION ET PROGRESSION

### Parcours de Compétences

**Débutant (Niveau 1)** ✓
- Scan basique
- Détection de services
- Interprétation des résultats

**Intermédiaire (Niveau 2)** ✓
- Scans avancés
- Optimisation
- Scripts NSE basiques

**Confirmé (Niveau 3)** ✓
- Évasion IDS/IPS
- Automatisation
- Scripts NSE personnalisés

**Expert (Niveau 4)** ✓
- Audits professionnels
- Scans à grande échelle
- Intégration outils

### Prochaines Étapes

1. **Pratiquer** régulièrement sur des labs
2. **Participer** à des CTF (Capture The Flag)
3. **Contribuer** à la communauté NSE
4. **Se certifier** (CEH, OSCP, etc.)
5. **Lire** le code source de Nmap

---

## 📝 NOTES ET REMARQUES

### Aspects Légaux

⚠️ **IMPORTANT** : N'utilisez Nmap que sur :
- Vos propres systèmes
- Systèmes avec autorisation écrite
- Environnements de test dédiés

Le scanning non autorisé est **illégal** dans de nombreux pays.

### Bonnes Pratiques

1. **Toujours** demander une autorisation écrite
2. **Documenter** toutes vos actions
3. **Respecter** les horaires convenus
4. **Communiquer** les résultats de manière responsable
5. **Protéger** les données sensibles découvertes

---

## ✅ CHECKLIST DE PROGRESSION

- [ ] Niveau 1 complété
- [ ] Niveau 2 complété
- [ ] Niveau 3 complété
- [ ] Niveau 4 complété
- [ ] Projet final réalisé
- [ ] Script d'automatisation créé
- [ ] Script NSE personnalisé développé
- [ ] Rapport professionnel généré
- [ ] Documentation lue
- [ ] Environnements de pratique testés

---

**Félicitations !** 🎉

Vous avez maintenant toutes les connaissances pour maîtriser Nmap de A à Z. Continuez à pratiquer et à explorer !

**Auteur** : Claude AI
**Version** : 1.0
**Dernière mise à jour** : 2024

---

## ANNEXES

### Annexe A : Installation de libpcap depuis les sources

```bash
# Téléchargement
wget https://www.tcpdump.org/release/libpcap-1.10.4.tar.gz
tar -xzvf libpcap-1.10.4.tar.gz
cd libpcap-1.10.4

# Compilation
./configure
make
sudo make install
```

### Annexe B : Compilation de Nmap depuis les sources

```bash
# Dépendances
sudo apt install build-essential libssl-dev libpcap-dev -y

# Téléchargement
wget https://nmap.org/dist/nmap-7.94.tar.bz2
tar -xjvf nmap-7.94.tar.bz2
cd nmap-7.94

# Compilation
./configure
make
sudo make install
```

### Annexe C : Configuration de l'environnement de test sécurisé

```bash
# Créer un réseau virtuel isolé avec VirtualBox/VMware
# Installer plusieurs VMs avec différents OS
# Configurer des services vulnérables
# Documenter l'infrastructure

# Exemple avec Vagrant
vagrant init ubuntu/focal64
vagrant up
vagrant ssh
```

---

**FIN DU TP COMPLET**
