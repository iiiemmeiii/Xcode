# TP PROTOCOLES AVANCÉS - GUIDE COMPLET
## DNS • NAT • NTP • SSL/TLS • IMAP
### Terminal + Packet Tracer + GNS3

---

## 📚 RÉCAPITULATIF DE L'ORDRE D'APPRENTISSAGE

```
✅ NIVEAU 1 - FONDAMENTAUX (Fichiers précédents)
   1. ARP   - Résolution IP→MAC (4-5h)
   2. DHCP  - Configuration auto (5-6h)

🔄 NIVEAU 1 (suite) - DNS
   3. DNS   - Résolution de noms (6-7h)

🔄 NIVEAU 2 - INFRASTRUCTURE
   4. NAT   - Translation d'adresses (4-5h)
   5. NTP   - Synchronisation temps (3-4h)

🔄 NIVEAU 3 - SÉCURITÉ & APPLICATIONS
   6. SSL/TLS - Chiffrement (5-6h)
   7. IMAP    - Email (3-4h)

TOTAL: 30-36 heures
```

---

## 🟢 DNS (Domain Name System)

### Théorie DNS

```
=== FONCTIONNEMENT DNS ===

DNS traduit noms de domaine → adresses IP
www.example.com → 93.184.216.34

HIÉRARCHIE DNS:
.                        (root)
├── .com                 (TLD - Top Level Domain)
│   └── example.com      (Domaine)
│       └── www          (Sous-domaine)
├── .org
└── .fr

TYPES D'ENREGISTREMENTS:
A      : IPv4 (example.com → 192.0.2.1)
AAAA   : IPv6 (example.com → 2001:db8::1)
CNAME  : Alias (www → example.com)
MX     : Serveur mail (mail.example.com)
NS     : Serveur DNS autoritaire
TXT    : Texte arbitraire (SPF, DKIM)
PTR    : Résolution inverse (IP → nom)
SOA    : Start of Authority (info sur zone)

PROCESSUS DE RÉSOLUTION:
1. Client demande www.example.com
2. Vérif cache local
3. Si absent: requête DNS récursif
4. DNS récursif interroge:
   - Root servers (.)
   - TLD servers (.com)
   - Authoritative servers (example.com)
5. Réponse retournée et mise en cache

PORTS:
UDP 53 : Requêtes DNS standard
TCP 53 : Transferts de zone, requêtes >512 octets
```

### Configuration DNS - Linux

```bash
#!/bin/bash
# dns_server_setup.sh - Serveur DNS avec BIND9

# Installation
sudo apt install bind9 bind9utils bind9-doc -y

# Configuration zones
sudo tee /etc/bind/named.conf.local << 'ZONES'
// Zone directe
zone "lab.local" {
    type master;
    file "/etc/bind/db.lab.local";
};

// Zone inverse
zone "1.168.192.in-addr.arpa" {
    type master;
    file "/etc/bind/db.192.168.1";
};
ZONES

# Fichier de zone directe
sudo tee /etc/bind/db.lab.local << 'FORWARD'
$TTL    604800
@       IN      SOA     ns1.lab.local. admin.lab.local. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL

; Serveurs de noms
@       IN      NS      ns1.lab.local.

; Enregistrements A
ns1     IN      A       192.168.1.10
www     IN      A       192.168.1.20
mail    IN      A       192.168.1.30
ftp     IN      A       192.168.1.40

; Alias
web     IN      CNAME   www
FORWARD

# Fichier de zone inverse
sudo tee /etc/bind/db.192.168.1 << 'REVERSE'
$TTL    604800
@       IN      SOA     ns1.lab.local. admin.lab.local. (
                              1         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL

@       IN      NS      ns1.lab.local.

10      IN      PTR     ns1.lab.local.
20      IN      PTR     www.lab.local.
30      IN      PTR     mail.lab.local.
REVERSE

# Redémarrer
sudo systemctl restart bind9

# Tests
dig @localhost lab.local
nslookup www.lab.local localhost
```

### DNS dans Packet Tracer

```
=== DNS SERVER CONFIGURATION ===

1. Ajouter un serveur
   - Devices > End Devices > Server

2. Configurer DNS:
   - Services > DNS
   - Activer "DNS Service"
   - Ajouter enregistrements:
     * www.lab.com → 192.168.1.20
     * mail.lab.com → 192.168.1.30
   
3. Configurer PC client:
   - Desktop > IP Configuration
   - DNS Server: [IP du serveur DNS]

4. Tester:
   - Desktop > Web Browser
   - Taper: www.lab.com
   - Vérifier résolution

5. Mode Simulation:
   - Observer requête DNS (UDP 53)
   - Observer réponse DNS avec IP
```

### Commandes DNS Essentielles

```bash
# dig (Domain Information Groper)
dig example.com                    # Requête A
dig example.com MX                 # Enregistrements MX
dig example.com ANY                # Tous types
dig @8.8.8.8 example.com          # Serveur DNS spécifique
dig +trace example.com             # Tracer résolution
dig -x 93.184.216.34              # Résolution inverse

# nslookup
nslookup example.com
nslookup example.com 8.8.8.8      # Serveur spécifique
nslookup -type=MX example.com     # Type spécifique

# host
host example.com
host -t AAAA example.com          # IPv6
host 93.184.216.34                # Inverse

# Configuration client
cat /etc/resolv.conf               # Serveurs DNS
sudo systemctl restart systemd-resolved  # Redémarrer resolver
```

---

## 🟡 NAT (Network Address Translation)

### Théorie NAT

```
=== TYPES DE NAT ===

1. STATIC NAT (1:1):
   IP privée ↔ IP publique fixe
   192.168.1.10 ↔ 203.0.113.10
   Usage: Serveurs accessibles de l'extérieur

2. DYNAMIC NAT (pool):
   IP privée → IP publique (pool)
   192.168.1.x → {203.0.113.10-20}
   Usage: Entreprises avec plusieurs IP publiques

3. PAT (Port Address Translation) / NAT Overload:
   Plusieurs IP privées → 1 IP publique (ports différents)
   192.168.1.10:5000 → 203.0.113.1:50000
   192.168.1.20:5000 → 203.0.113.1:50001
   Usage: Domicile, PME (plus courant)

TABLE NAT:
Inside Local  | Inside Global | Outside Global | Outside Local
192.168.1.10  | 203.0.113.1   | 8.8.8.8        | 8.8.8.8
192.168.1.20  | 203.0.113.1   | 1.1.1.1        | 1.1.1.1
```

### NAT sur Linux (iptables)

```bash
#!/bin/bash
# nat_setup.sh - Configuration NAT sur Linux

# Interface WAN (externe)
WAN="eth0"
# Interface LAN (interne)
LAN="eth1"

echo "=== CONFIGURATION NAT ==="

# 1. Activer IP forwarding
echo 1 > /proc/sys/net/ipv4/ip_forward

# Permanent
echo "net.ipv4.ip_forward=1" | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# 2. PAT (Masquerade) - NAT sortant
sudo iptables -t nat -A POSTROUTING -o $WAN -j MASQUERADE

# 3. Static NAT - Exemple serveur web
# Rediriger port 80 externe vers 192.168.1.10:80
sudo iptables -t nat -A PREROUTING -i $WAN -p tcp --dport 80 \
    -j DNAT --to-destination 192.168.1.10:80

# 4. Port Forwarding
sudo iptables -t nat -A PREROUTING -i $WAN -p tcp --dport 2222 \
    -j DNAT --to-destination 192.168.1.20:22

# 5. Sauvegarder règles
sudo iptables-save > /etc/iptables/rules.v4

# Vérifier
sudo iptables -t nat -L -n -v

echo "✓ NAT configuré"
echo "  WAN: $WAN"
echo "  LAN: $LAN"
echo "  Masquerade actif"
```

### NAT dans Packet Tracer

```
=== CONFIGURATION NAT CISCO ===

Topologie:
LAN (192.168.1.0/24) → Router (NAT) → Internet

Router> enable
Router# configure terminal

! Définir interfaces inside/outside
Router(config)# interface GigabitEthernet0/0
Router(config-if)# ip address 192.168.1.1 255.255.255.0
Router(config-if)# ip nat inside
Router(config-if)# no shutdown
Router(config-if)# exit

Router(config)# interface GigabitEthernet0/1
Router(config-if)# ip address 203.0.113.1 255.255.255.0
Router(config-if)# ip nat outside
Router(config-if)# no shutdown
Router(config-if)# exit

! PAT (Overload)
Router(config)# access-list 1 permit 192.168.1.0 0.0.0.255
Router(config)# ip nat inside source list 1 interface GigabitEthernet0/1 overload

! Static NAT (serveur web)
Router(config)# ip nat inside source static 192.168.1.10 203.0.113.10

! Port Forwarding
Router(config)# ip nat inside source static tcp 192.168.1.20 80 203.0.113.1 8080

! Vérifier
Router# show ip nat translations
Router# show ip nat statistics
Router# debug ip nat
```

---

## 🟡 NTP (Network Time Protocol)

### Théorie NTP

```
=== HIÉRARCHIE NTP (STRATA) ===

Stratum 0: Horloge de référence (GPS, atomique)
Stratum 1: Serveurs connectés à Stratum 0
Stratum 2: Serveurs synchronisés avec Stratum 1
...
Stratum 15: Max

MODES NTP:
- Client/Server
- Peer (symétrique)
- Broadcast/Multicast

PORTS:
UDP 123
```

### Configuration NTP - Linux

```bash
#!/bin/bash
# ntp_setup.sh - Configuration NTP

# Installation chrony (moderne) ou ntp
sudo apt install chrony -y

# Configuration
sudo tee /etc/chrony/chrony.conf << 'NTP'
# Serveurs NTP publics
server 0.pool.ntp.org iburst
server 1.pool.ntp.org iburst
server 2.pool.ntp.org iburst
server 3.pool.ntp.org iburst

# Stratum si aucun serveur accessible
local stratum 10

# Autoriser clients du LAN
allow 192.168.1.0/24

# Fichier drift
driftfile /var/lib/chrony/drift

# Logs
logdir /var/log/chrony
NTP

# Redémarrer
sudo systemctl restart chrony
sudo systemctl enable chrony

# Vérifier
chronyc tracking
chronyc sources -v
timedatectl status

# Forcer synchronisation
sudo chronyc makestep

echo "✓ NTP configuré"
```

### NTP dans Packet Tracer

```
=== NTP CONFIGURATION CISCO ===

! SERVEUR NTP
Router(config)# clock timezone CET 1
Router(config)# clock summer-time CEST recurring
Router(config)# ntp master 3

! CLIENT NTP
Router(config)# ntp server 192.168.1.1

! Vérifier
Router# show ntp status
Router# show ntp associations
Router# show clock
```

### Commandes NTP

```bash
# Vérifier synchronisation
timedatectl
ntpq -p                    # État peers NTP
chronyc sources            # Sources de temps

# Test serveur NTP
ntpdate -q pool.ntp.org    # Query seulement
sntp -t 5 pool.ntp.org     # Test SNTP

# Définir timezone
sudo timedatectl set-timezone Europe/Paris
```

---

## 🔴 SSL/TLS (Secure Sockets Layer / Transport Layer Security)

### Théorie SSL/TLS

```
=== VERSIONS ===
SSL 1.0 - Jamais publié
SSL 2.0 - Obsolète (1995)
SSL 3.0 - Obsolète (1996) - Vulnérable POODLE
TLS 1.0 - Déprécié (1999)
TLS 1.1 - Déprécié (2006)
TLS 1.2 - OK (2008)
TLS 1.3 - Recommandé (2018)

=== HANDSHAKE TLS 1.2 ===

Client                    Server
  | ClientHello              |
  |------------------------->|
  |         ServerHello      |
  |         Certificate      |
  |    ServerKeyExchange     |
  |       ServerHelloDone    |
  |<-------------------------|
  | ClientKeyExchange        |
  | ChangeCipherSpec         |
  | Finished                 |
  |------------------------->|
  |      ChangeCipherSpec    |
  |          Finished        |
  |<-------------------------|
  | Application Data         |
  |<------------------------>|

=== COMPOSANTS ===

1. CERTIFICAT X.509:
   - Clé publique
   - Identité (CN, OU, O, C)
   - Signature CA
   - Validité (dates)
   
2. CHAÎNE DE CONFIANCE:
   Root CA → Intermediate CA → End Certificate

3. CIPHER SUITES:
   Exemple: TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
   - ECDHE: Échange clé
   - RSA: Authentification
   - AES_256_GCM: Chiffrement
   - SHA384: Intégrité
```

### Génération Certificats SSL

```bash
#!/bin/bash
# ssl_certificate_generation.sh

echo "=== GÉNÉRATION CERTIFICATS SSL ==="

# 1. Clé privée Root CA
openssl genrsa -out ca.key 4096

# 2. Certificat Root CA
openssl req -x509 -new -nodes -key ca.key -sha256 -days 3650 \
    -out ca.crt \
    -subj "/C=FR/ST=France/L=Paris/O=Lab/CN=Lab Root CA"

# 3. Clé privée serveur
openssl genrsa -out server.key 2048

# 4. CSR (Certificate Signing Request)
openssl req -new -key server.key -out server.csr \
    -subj "/C=FR/ST=France/L=Paris/O=Lab/CN=www.lab.local"

# 5. Signer le certificat avec CA
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key \
    -CAcreateserial -out server.crt -days 365 -sha256

# 6. Vérifier
openssl x509 -in server.crt -text -noout
openssl verify -CAfile ca.crt server.crt

# 7. Créer PEM (clé + cert)
cat server.key server.crt > server.pem

echo "✓ Certificats créés:"
echo "  CA: ca.crt, ca.key"
echo "  Serveur: server.crt, server.key, server.pem"
```

### Configuration Serveur Web HTTPS

```bash
# NGINX avec SSL
sudo tee /etc/nginx/sites-available/ssl-site << 'NGINX'
server {
    listen 443 ssl http2;
    server_name www.lab.local;
    
    ssl_certificate /etc/ssl/certs/server.crt;
    ssl_certificate_key /etc/ssl/private/server.key;
    
    # TLS versions
    ssl_protocols TLSv1.2 TLSv1.3;
    
    # Cipher suites (sécurisés)
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256';
    ssl_prefer_server_ciphers on;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=31536000" always;
    
    location / {
        root /var/www/html;
        index index.html;
    }
}

# Redirection HTTP → HTTPS
server {
    listen 80;
    server_name www.lab.local;
    return 301 https://$server_name$request_uri;
}
NGINX

sudo nginx -t
sudo systemctl reload nginx
```

### Tests SSL/TLS

```bash
# Test connexion SSL
openssl s_client -connect www.example.com:443 -showcerts

# Vérifier protocoles supportés
nmap --script ssl-enum-ciphers -p 443 example.com

# Tester avec testssl.sh
git clone https://github.com/drwetter/testssl.sh.git
cd testssl.sh
./testssl.sh https://example.com

# Vérifier certificat
echo | openssl s_client -connect example.com:443 2>/dev/null | \
    openssl x509 -noout -dates -subject

# Avec curl
curl -v https://example.com
curl --cacert ca.crt https://www.lab.local
```

---

## 🔴 IMAP (Internet Message Access Protocol)

### Théorie IMAP

```
=== IMAP vs POP3 ===

IMAP (Port 143/993):
- Messages restent sur serveur
- Synchronisation multi-appareils
- Gestion dossiers
- Accès partiel messages
- Usage: Email moderne

POP3 (Port 110/995):
- Télécharge et supprime
- Un seul appareil
- Pas de sync
- Usage: Email simple

=== COMMANDES IMAP ===

LOGIN - Authentification
SELECT - Sélectionner boîte
FETCH - Récupérer message
SEARCH - Chercher messages
STORE - Modifier flags
EXPUNGE - Supprimer définitivement
LOGOUT - Déconnexion

PORTS:
143 : IMAP non chiffré
993 : IMAPS (SSL/TLS)
```

### Installation Serveur IMAP (Dovecot)

```bash
#!/bin/bash
# imap_server_setup.sh

# Installation
sudo apt install dovecot-imapd dovecot-pop3d -y

# Configuration
sudo tee /etc/dovecot/dovecot.conf << 'DOVECOT'
# Protocoles activés
protocols = imap pop3

# Écoute
listen = *

# SSL
ssl = yes
ssl_cert = </etc/ssl/certs/server.crt
ssl_key = </etc/ssl/private/server.key

# Authentification
disable_plaintext_auth = yes
auth_mechanisms = plain login

# Mailbox
mail_location = maildir:~/Maildir

# Logs
log_path = /var/log/dovecot.log
DOVECOT

# Redémarrer
sudo systemctl restart dovecot
sudo systemctl enable dovecot

# Créer utilisateur test
sudo useradd -m testuser
echo "testuser:password" | sudo chpasswd

# Initialiser Maildir
sudo -u testuser maildirmake.dovecot ~/Maildir

echo "✓ Serveur IMAP configuré"
echo "  IMAP: Port 143"
echo "  IMAPS: Port 993"
```

### Client IMAP (Terminal)

```bash
# Test connexion IMAP
telnet localhost 143
# ou
openssl s_client -connect localhost:993

# Commandes IMAP:
a001 LOGIN testuser password
a002 LIST "" "*"
a003 SELECT INBOX
a004 FETCH 1 BODY[]
a005 LOGOUT

# Avec mutt (client email terminal)
sudo apt install mutt -y

cat > ~/.muttrc << 'MUTT'
set imap_user = "testuser"
set imap_pass = "password"
set folder = "imaps://localhost:993"
set spoolfile = "+INBOX"
set ssl_starttls = yes
set ssl_force_tls = yes
MUTT

mutt
```

### Python IMAP Client

```python
#!/usr/bin/env python3
# imap_client.py - Client IMAP simple

import imaplib
import email
from email.header import decode_header

def connect_imap(server, username, password):
    """Connexion IMAP"""
    
    # Connexion SSL
    mail = imaplib.IMAP4_SSL(server, 993)
    mail.login(username, password)
    
    return mail

def list_mailboxes(mail):
    """Lister boîtes mail"""
    
    status, mailboxes = mail.list()
    
    for mailbox in mailboxes:
        print(mailbox.decode())

def read_emails(mail, folder='INBOX', num=5):
    """Lire derniers emails"""
    
    mail.select(folder)
    
    # Chercher tous les emails
    status, messages = mail.search(None, 'ALL')
    
    email_ids = messages[0].split()
    
    # Derniers emails
    for email_id in email_ids[-num:]:
        
        status, msg_data = mail.fetch(email_id, '(RFC822)')
        
        for response_part in msg_data:
            if isinstance(response_part, tuple):
                
                msg = email.message_from_bytes(response_part[1])
                
                # Sujet
                subject = decode_header(msg["Subject"])[0][0]
                if isinstance(subject, bytes):
                    subject = subject.decode()
                
                # De
                from_ = msg.get("From")
                
                print(f"\nEmail ID: {email_id.decode()}")
                print(f"Sujet: {subject}")
                print(f"De: {from_}")
                print("-" * 50)

# Exemple usage
if __name__ == "__main__":
    
    server = "localhost"
    username = "testuser"
    password = "password"
    
    try:
        mail = connect_imap(server, username, password)
        
        print("Boîtes mail:")
        list_mailboxes(mail)
        
        print("\n" + "="*50)
        print("Derniers emails:")
        read_emails(mail)
        
        mail.logout()
        
    except Exception as e:
        print(f"Erreur: {e}")
```

---

## 📊 TABLEAU RÉCAPITULATIF

| Protocole | Port(s)    | Couche | Prérequis    | Usage Principal              |
|-----------|------------|--------|--------------|------------------------------|
| ARP       | -          | 2      | Ethernet     | Résolution IP→MAC            |
| DHCP      | 67/68 UDP  | 7      | UDP          | Config auto IP               |
| DNS       | 53 UDP/TCP | 7      | UDP/TCP      | Résolution noms              |
| NAT       | -          | 3      | IP, Routage  | Partage IP publique          |
| NTP       | 123 UDP    | 7      | UDP          | Synchronisation temps        |
| SSL/TLS   | 443 TCP    | 5-6    | TCP          | Chiffrement communications   |
| IMAP      | 143/993    | 7      | TCP, SSL/TLS | Accès email                  |

---

## 🎯 EXERCICES PRATIQUES INTÉGRÉS

### Exercice Final : Infrastructure Complète

```
=== TOPOLOGIE GLOBALE PACKET TRACER ===

Internet
   |
   | (NAT)
Router (DNS, NTP, DHCP relay)
   |
Switch
   |
   ├── DHCP Server
   ├── DNS Server  
   ├── Mail Server (IMAP/SMTP avec SSL/TLS)
   ├── NTP Server
   └── Clients (PC1, PC2, PC3)

OBJECTIFS:
1. DHCP distribue IPs automatiquement
2. DNS résout noms locaux
3. NAT permet accès Internet
4. NTP synchronise tous les équipements
5. Mail avec IMAP/SSL fonctionnel
6. ARP fonctionne correctement

VÉRIFICATIONS:
- PC obtient IP via DHCP
- PC résout DNS (nslookup)
- PC ping Internet (via NAT)
- Temps synchronisé (show clock)
- Email accessible via IMAP
- Table ARP complète
```

---

## 🛠️ SCRIPTS UTILITAIRES

### Script de Diagnostic Réseau Complet

```bash
#!/bin/bash
# network_diagnosis.sh - Diagnostic complet

echo "=== DIAGNOSTIC RÉSEAU COMPLET ==="

echo -e "\n[1] ARP Table:"
arp -n | head -10

echo -e "\n[2] IP Configuration:"
ip addr show | grep -E "inet |^[0-9]:"

echo -e "\n[3] DHCP Lease:"
cat /var/lib/dhcp/dhclient.leases | grep -E "lease|expire"

echo -e "\n[4] DNS Configuration:"
cat /etc/resolv.conf | grep nameserver

echo -e "\n[5] DNS Test:"
dig google.com +short

echo -e "\n[6] NAT Status (si routeur):"
sudo iptables -t nat -L -n | head -10

echo -e "\n[7] NTP Status:"
chronyc tracking 2>/dev/null || ntpq -p 2>/dev/null

echo -e "\n[8] SSL Certificates:"
ls -lh /etc/ssl/certs/ | head -5

echo -e "\n[9] Ports en écoute:"
sudo ss -tulpn | grep -E ":(53|67|68|123|143|993|443)"

echo -e "\n[10] Routing Table:"
ip route show

echo -e "\n✓ Diagnostic terminé"
```

---

## 📚 RESSOURCES ET RÉFÉRENCES

### RFCs Importantes
- RFC 826 : ARP
- RFC 2131 : DHCP
- RFC 1035 : DNS
- RFC 3022 : NAT
- RFC 5905 : NTPv4
- RFC 8446 : TLS 1.3
- RFC 3501 : IMAP4

### Commandes Essentielles par Protocole

```bash
# ARP
arp -n, ip neigh show

# DHCP
dhclient, dhcpd, show ip dhcp binding

# DNS
dig, nslookup, host, named

# NAT
iptables -t nat, show ip nat translations

# NTP
chronyc, ntpq, timedatectl

# SSL/TLS
openssl s_client, testssl.sh

# IMAP
telnet/openssl + port 143/993
```

---

## ✅ CHECKLIST FINALE

### Connaissances Théoriques
- [ ] Comprendre hiérarchie DNS
- [ ] Maîtriser processus DORA DHCP
- [ ] Expliquer différence NAT/PAT
- [ ] Comprendre stratum NTP
- [ ] Expliquer handshake TLS
- [ ] Différencier IMAP/POP3
- [ ] Comprendre résolution ARP

### Compétences Pratiques
- [ ] Configurer serveur DHCP
- [ ] Configurer serveur DNS (zones)
- [ ] Implémenter NAT/PAT
- [ ] Synchroniser NTP
- [ ] Générer certificats SSL
- [ ] Configurer serveur IMAP
- [ ] Analyser trafic avec Wireshark

### Packet Tracer
- [ ] Topologie DHCP fonctionnelle
- [ ] DNS résolvant noms
- [ ] NAT permettant Internet
- [ ] NTP synchronisant équipements
- [ ] Infrastructure complète

### Sécurité
- [ ] Implémenter DHCP snooping
- [ ] Protéger contre ARP spoofing
- [ ] Sécuriser DNS (DNSSEC)
- [ ] Configurer SSL/TLS fort
- [ ] IMAPS au lieu d'IMAP

---

**FIN DU TP COMPLET**

**Durée totale :** 30-36 heures  
**Niveau atteint :** Expert protocoles réseau  
**Certification :** Prêt pour CCNA, Linux+, Network+

🎉 **Félicitations !** Vous maîtrisez maintenant les protocoles réseau essentiels !
