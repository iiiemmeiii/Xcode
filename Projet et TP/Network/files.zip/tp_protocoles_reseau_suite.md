# TP COMPLET : MAÎTRISE DES PROTOCOLES RÉSEAU (SUITE)
## HTTP • HTTPS • SSH • ANALYSE AVANCÉE
### Partie 2/2 - Niveaux 3 à 5

---

<a name="niveau-3"></a>
## 🟠 NIVEAU 3 : HTTP ET HTTPS (5-6 heures)

### Objectifs
- Maîtriser le protocole HTTP
- Comprendre HTTPS et TLS/SSL
- Analyser les requêtes et réponses
- Sécuriser les communications web

---

### Partie 3.1 : Protocole HTTP (HyperText Transfer Protocol)

#### Exercice 3.1.1 : Structure HTTP

```
=== HTTP/1.1 REQUEST ===

GET /index.html HTTP/1.1
Host: www.example.com
User-Agent: Mozilla/5.0 (Linux)
Accept: text/html,application/xhtml+xml
Accept-Language: fr-FR,fr;q=0.9,en;q=0.8
Accept-Encoding: gzip, deflate
Connection: keep-alive

[Corps de la requête pour POST/PUT]

=== HTTP/1.1 RESPONSE ===

HTTP/1.1 200 OK
Date: Mon, 16 Feb 2026 10:00:00 GMT
Server: Apache/2.4.52 (Ubuntu)
Content-Type: text/html; charset=UTF-8
Content-Length: 1234
Connection: keep-alive

<!DOCTYPE html>
<html>
...
</html>

=== MÉTHODES HTTP ===

GET     : Récupérer une ressource
POST    : Soumettre des données
PUT     : Remplacer une ressource
DELETE  : Supprimer une ressource
HEAD    : Comme GET mais sans le corps
OPTIONS : Obtenir les méthodes supportées
PATCH   : Modification partielle
CONNECT : Établir un tunnel (proxy)
TRACE   : Diagnostic (écho de la requête)

=== CODES DE STATUT ===

1xx - Informatif
    100 Continue

2xx - Succès
    200 OK
    201 Created
    204 No Content

3xx - Redirection
    301 Moved Permanently
    302 Found (Redirection temporaire)
    304 Not Modified

4xx - Erreur client
    400 Bad Request
    401 Unauthorized
    403 Forbidden
    404 Not Found
    429 Too Many Requests

5xx - Erreur serveur
    500 Internal Server Error
    502 Bad Gateway
    503 Service Unavailable
```

---

#### Exercice 3.1.2 : Capture et analyse HTTP

```bash
# Préparer un serveur web
sudo systemctl start apache2

# Créer une page de test
echo "<h1>Test HTTP</h1><p>Capture en cours...</p>" | sudo tee /var/www/html/test.html

# Terminal 1: Capturer le trafic HTTP
sudo tcpdump -i any 'tcp port 80' -A -s 0 -w http_capture.pcap

# Terminal 2: Faire des requêtes HTTP
curl http://localhost/test.html
curl -I http://localhost/test.html  # HEAD request
curl -X POST http://localhost/test.html -d "param=value"

# Arrêter la capture (Ctrl+C)

# Analyser avec tcpdump
tcpdump -r http_capture.pcap -A | grep -A 10 "GET\|POST\|HTTP"

# Analyser avec tshark
tshark -r http_capture.pcap -Y "http" -V

# Extraire uniquement les requêtes HTTP
tshark -r http_capture.pcap -Y "http.request" -T fields \
    -e http.request.method \
    -e http.host \
    -e http.request.uri

# Extraire uniquement les réponses HTTP
tshark -r http_capture.pcap -Y "http.response" -T fields \
    -e http.response.code \
    -e http.content_type
```

---

#### Exercice 3.1.3 : Client HTTP manuel avec telnet/netcat

```bash
# Connexion HTTP manuelle avec telnet
telnet localhost 80

# Taper la requête HTTP (puis Entrée deux fois):
GET /test.html HTTP/1.1
Host: localhost

# Avec netcat
echo -e "GET /test.html HTTP/1.1\r\nHost: localhost\r\n\r\n" | nc localhost 80

# Requête POST
echo -e "POST /test.html HTTP/1.1\r\nHost: localhost\r\nContent-Length: 11\r\n\r\nparam=value" | nc localhost 80

# Requête HEAD
echo -e "HEAD /test.html HTTP/1.1\r\nHost: localhost\r\n\r\n" | nc localhost 80

# Requête OPTIONS
echo -e "OPTIONS * HTTP/1.1\r\nHost: localhost\r\n\r\n" | nc localhost 80
```

---

#### Exercice 3.1.4 : Serveur HTTP minimal en Python

```python
#!/usr/bin/env python3
# http_server_minimal.py - Serveur HTTP basique

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
from urllib.parse import parse_qs, urlparse

class SimpleHTTPHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        """Gérer les requêtes GET"""
        # Parser l'URL
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        
        print(f"GET {path}")
        print(f"Query params: {query}")
        print(f"Headers: {dict(self.headers)}")
        
        # Répondre
        if path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<h1>Serveur HTTP</h1><p>Bienvenue!</p>")
            
        elif path == "/api/data":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            data = {"message": "Hello", "params": query}
            self.wfile.write(json.dumps(data).encode())
            
        else:
            self.send_response(404)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<h1>404 Not Found</h1>")
    
    def do_POST(self):
        """Gérer les requêtes POST"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode()
        
        print(f"POST {self.path}")
        print(f"Headers: {dict(self.headers)}")
        print(f"Body: {body}")
        
        # Répondre
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        
        response = {
            "message": "Data received",
            "received": body
        }
        self.wfile.write(json.dumps(response).encode())
    
    def do_PUT(self):
        """Gérer les requêtes PUT"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode()
        
        print(f"PUT {self.path}")
        print(f"Body: {body}")
        
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        
        response = {"message": "Resource updated"}
        self.wfile.write(json.dumps(response).encode())
    
    def do_DELETE(self):
        """Gérer les requêtes DELETE"""
        print(f"DELETE {self.path}")
        
        self.send_response(204)  # No Content
        self.end_headers()
    
    def do_OPTIONS(self):
        """Gérer les requêtes OPTIONS (CORS)"""
        self.send_response(200)
        self.send_header("Allow", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

def main():
    port = 8080
    server = HTTPServer(('0.0.0.0', port), SimpleHTTPHandler)
    print(f"Serveur HTTP sur le port {port}")
    print("Ctrl+C pour arrêter")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur")
        server.shutdown()

if __name__ == "__main__":
    main()
```

**Tests :**
```bash
chmod +x http_server_minimal.py
python3 http_server_minimal.py &
SERVER_PID=$!

# Tests avec curl
curl http://localhost:8080/
curl http://localhost:8080/api/data?name=test
curl -X POST http://localhost:8080/api/data -d "key=value"
curl -X PUT http://localhost:8080/api/data -d "updated=data"
curl -X DELETE http://localhost:8080/api/data
curl -X OPTIONS http://localhost:8080/

kill $SERVER_PID
```

---

#### Exercice 3.1.5 : Headers HTTP importants

```bash
#!/bin/bash
# http_headers_demo.sh - Démonstration des headers HTTP

URL="http://localhost:8080"

echo "=== HEADERS DE REQUÊTE ==="

# User-Agent
echo -e "\n[1] User-Agent"
curl -H "User-Agent: MyCustomBot/1.0" $URL -v 2>&1 | grep "User-Agent"

# Accept
echo -e "\n[2] Accept"
curl -H "Accept: application/json" $URL -v 2>&1 | grep "Accept:"

# Accept-Encoding
echo -e "\n[3] Accept-Encoding"
curl -H "Accept-Encoding: gzip, deflate" $URL -v 2>&1 | grep "Accept-Encoding"

# Authorization
echo -e "\n[4] Authorization"
curl -H "Authorization: Bearer token123456" $URL -v 2>&1 | grep "Authorization"

# Cookie
echo -e "\n[5] Cookie"
curl -H "Cookie: session=abc123; user=john" $URL -v 2>&1 | grep "Cookie"

# Referer
echo -e "\n[6] Referer"
curl -H "Referer: http://google.com" $URL -v 2>&1 | grep "Referer"

echo -e "\n\n=== HEADERS DE RÉPONSE ==="

# Cache-Control
echo -e "\n[7] Cache-Control"
curl -I $URL 2>&1 | grep -i "cache-control"

# Content-Type
echo -e "\n[8] Content-Type"
curl -I $URL 2>&1 | grep -i "content-type"

# Set-Cookie
echo -e "\n[9] Set-Cookie"
curl -I http://httpbin.org/cookies/set?session=test 2>&1 | grep -i "set-cookie"

# CORS Headers
echo -e "\n[10] CORS Headers"
curl -X OPTIONS $URL -v 2>&1 | grep -i "access-control"
```

---

#### Exercice 3.1.6 : HTTP/2 vs HTTP/1.1

```bash
# Vérifier le support HTTP/2
curl -I --http2 https://www.google.com

# Comparer HTTP/1.1 vs HTTP/2
echo "=== HTTP/1.1 ==="
time curl -I https://www.google.com

echo -e "\n=== HTTP/2 ==="
time curl -I --http2 https://www.google.com

# Avec tcpdump (HTTPS, donc chiffré)
sudo tcpdump -i any 'tcp port 443' -w http2_test.pcap &
TCPDUMP_PID=$!

curl --http2 https://www.google.com > /dev/null 2>&1

sleep 2
sudo kill $TCPDUMP_PID

# Analyser
tshark -r http2_test.pcap -Y "http2" | head -20
```

**Différences HTTP/2 :**
```
HTTP/1.1:
- Texte clair
- Une requête par connexion
- Headers en texte
- Pas de multiplexing

HTTP/2:
- Binaire
- Multiplexing (plusieurs requêtes simultanées)
- Compression des headers (HPACK)
- Server Push
- Priorisation des streams
```

---

### Partie 3.2 : HTTPS et TLS/SSL

#### Exercice 3.2.1 : Comprendre TLS/SSL

```
=== TLS HANDSHAKE (Simplified) ===

Client                                Server
  |                                     |
  | ClientHello                         |
  |------------------------------------>|  1. Propose cipher suites, version
  |                                     |
  |           ServerHello               |
  |           Certificate               |
  |           ServerHelloDone           |
  |<------------------------------------|  2. Choisit cipher, envoie certificat
  |                                     |
  | ClientKeyExchange                   |
  | ChangeCipherSpec                    |
  | Finished                            |
  |------------------------------------>|  3. Échange de clés, activation chiffrement
  |                                     |
  |           ChangeCipherSpec          |
  |           Finished                  |
  |<------------------------------------|  4. Confirmation chiffrement
  |                                     |
  |   ENCRYPTED APPLICATION DATA        |
  |<----------------------------------->|
  
=== VERSIONS SSL/TLS ===

SSL 1.0  - Jamais publié
SSL 2.0  - 1995 (OBSOLÈTE, vulnérabilités)
SSL 3.0  - 1996 (OBSOLÈTE, POODLE attack)
TLS 1.0  - 1999 (Déprécié)
TLS 1.1  - 2006 (Déprécié)
TLS 1.2  - 2008 (Encore utilisé)
TLS 1.3  - 2018 (Recommandé)
```

---

#### Exercice 3.2.2 : Créer un certificat auto-signé

```bash
#!/bin/bash
# create_self_signed_cert.sh - Créer un certificat SSL auto-signé

echo "=== Création d'un certificat auto-signé ==="

# Créer le répertoire
mkdir -p ~/ssl_certs
cd ~/ssl_certs

# Générer la clé privée (2048 bits)
echo "[1] Génération de la clé privée..."
openssl genrsa -out server.key 2048

# Générer une demande de signature de certificat (CSR)
echo "[2] Génération du CSR..."
openssl req -new -key server.key -out server.csr -subj "/C=FR/ST=France/L=Paris/O=TestOrg/CN=localhost"

# Générer le certificat auto-signé (valide 365 jours)
echo "[3] Génération du certificat auto-signé..."
openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt

# Afficher les informations du certificat
echo -e "\n=== Informations du certificat ==="
openssl x509 -in server.crt -text -noout | head -30

# Vérifier le certificat
echo -e "\n=== Vérification ==="
openssl verify -CAfile server.crt server.crt

echo -e "\n[✓] Certificat créé :"
echo "    Clé privée : ~/ssl_certs/server.key"
echo "    Certificat : ~/ssl_certs/server.crt"
```

```bash
chmod +x create_self_signed_cert.sh
./create_self_signed_cert.sh
```

---

#### Exercice 3.2.3 : Serveur HTTPS en Python

```python
#!/usr/bin/env python3
# https_server.py - Serveur HTTPS simple

from http.server import HTTPServer, SimpleHTTPRequestHandler
import ssl
import os

def main():
    port = 8443
    
    # Chemins des certificats
    certfile = os.path.expanduser("~/ssl_certs/server.crt")
    keyfile = os.path.expanduser("~/ssl_certs/server.key")
    
    if not os.path.exists(certfile) or not os.path.exists(keyfile):
        print("Erreur: Certificats non trouvés")
        print("Exécutez d'abord create_self_signed_cert.sh")
        return
    
    # Créer le serveur
    server = HTTPServer(('0.0.0.0', port), SimpleHTTPRequestHandler)
    
    # Configurer SSL
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile, keyfile)
    
    server.socket = context.wrap_socket(server.socket, server_side=True)
    
    print(f"Serveur HTTPS sur le port {port}")
    print(f"Accès : https://localhost:{port}")
    print("Note: Votre navigateur affichera un avertissement (certificat auto-signé)")
    print("\nCtrl+C pour arrêter")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur")
        server.shutdown()

if __name__ == "__main__":
    main()
```

**Test :**
```bash
chmod +x https_server.py
python3 https_server.py &
SERVER_PID=$!

# Test avec curl (ignorer la vérification du certificat)
curl -k https://localhost:8443

# Voir les détails du certificat
curl -kv https://localhost:8443 2>&1 | grep -A 10 "Server certificate"

# Avec openssl
openssl s_client -connect localhost:8443 -showcerts

kill $SERVER_PID
```

---

#### Exercice 3.2.4 : Analyse du handshake TLS

```bash
# Capturer le handshake TLS
sudo tcpdump -i any 'tcp port 443' -w tls_handshake.pcap &
TCPDUMP_PID=$!

# Faire une requête HTTPS
curl https://www.google.com > /dev/null 2>&1

sleep 2
sudo kill $TCPDUMP_PID

# Analyser avec tshark
echo "=== Messages TLS capturés ==="
tshark -r tls_handshake.pcap -Y "tls.handshake" -T fields \
    -e frame.number \
    -e tls.handshake.type

# Détails du ClientHello
echo -e "\n=== ClientHello ==="
tshark -r tls_handshake.pcap -Y "tls.handshake.type == 1" -V | grep -A 20 "Handshake Protocol"

# Détails du ServerHello
echo -e "\n=== ServerHello ==="
tshark -r tls_handshake.pcap -Y "tls.handshake.type == 2" -V | grep -A 20 "Handshake Protocol"

# Analyser les cipher suites
echo -e "\n=== Cipher Suites ==="
tshark -r tls_handshake.pcap -Y "tls.handshake.type == 1" -V | grep -i "cipher suite"
```

---

#### Exercice 3.2.5 : Test de configuration SSL/TLS

```bash
#!/bin/bash
# ssl_test.sh - Tester la configuration SSL/TLS d'un serveur

TARGET="${1:-www.google.com:443}"

echo "=== Test SSL/TLS de $TARGET ==="

# Test 1: Version TLS supportées
echo -e "\n[1] Versions TLS supportées"
for version in ssl2 ssl3 tls1 tls1_1 tls1_2 tls1_3; do
    result=$(openssl s_client -connect $TARGET -${version//_/.} </dev/null 2>&1 | grep -o "Protocol.*")
    if [ -n "$result" ]; then
        echo "  ✓ ${version//_/.} : Supporté"
    else
        echo "  ✗ ${version//_/.} : Non supporté"
    fi
done

# Test 2: Certificat
echo -e "\n[2] Informations du certificat"
openssl s_client -connect $TARGET -showcerts </dev/null 2>&1 | \
    openssl x509 -noout -subject -issuer -dates 2>/dev/null

# Test 3: Cipher suites
echo -e "\n[3] Cipher suites négociées"
openssl s_client -connect $TARGET </dev/null 2>&1 | grep "Cipher.*:"

# Test 4: Vérification de la chaîne de certificats
echo -e "\n[4] Chaîne de certificats"
openssl s_client -connect $TARGET -showcerts </dev/null 2>&1 | \
    grep -A 2 "Certificate chain"

# Test 5: OCSP Stapling
echo -e "\n[5] OCSP Stapling"
openssl s_client -connect $TARGET -status </dev/null 2>&1 | grep -i "OCSP"

echo -e "\n=== Test terminé ==="
```

```bash
chmod +x ssl_test.sh
./ssl_test.sh www.google.com:443
./ssl_test.sh github.com:443
```

---

#### Exercice 3.2.6 : Vulnérabilités SSL/TLS communes

```bash
#!/bin/bash
# ssl_vuln_check.sh - Vérifier les vulnérabilités SSL/TLS

TARGET="$1"

if [ -z "$TARGET" ]; then
    echo "Usage: $0 <host:port>"
    exit 1
fi

echo "=== Vérification des vulnérabilités SSL/TLS ==="
echo "Cible: $TARGET"
echo ""

# 1. POODLE (SSLv3)
echo "[1] POODLE (CVE-2014-3566)"
if openssl s_client -connect $TARGET -ssl3 </dev/null 2>&1 | grep -q "Cipher"; then
    echo "  ⚠️  VULNÉRABLE - SSLv3 activé"
else
    echo "  ✓ Protégé - SSLv3 désactivé"
fi

# 2. BEAST (TLS 1.0)
echo ""
echo "[2] BEAST (CVE-2011-3389)"
if openssl s_client -connect $TARGET -tls1 </dev/null 2>&1 | grep -q "Cipher"; then
    echo "  ⚠️  Potentiellement vulnérable - TLS 1.0 activé"
else
    echo "  ✓ Protégé - TLS 1.0 désactivé"
fi

# 3. Heartbleed (OpenSSL)
echo ""
echo "[3] Heartbleed (CVE-2014-0160)"
echo "  Note: Test nécessite un outil spécialisé"

# 4. Weak ciphers
echo ""
echo "[4] Cipher suites faibles"
WEAK_CIPHERS=$(openssl s_client -connect $TARGET -cipher 'EXPORT:LOW:NULL:aNULL' </dev/null 2>&1 | grep "Cipher")
if [ -n "$WEAK_CIPHERS" ]; then
    echo "  ⚠️  Ciphers faibles détectés"
else
    echo "  ✓ Pas de ciphers faibles"
fi

# 5. Forward Secrecy
echo ""
echo "[5] Perfect Forward Secrecy"
FS_CIPHER=$(openssl s_client -connect $TARGET </dev/null 2>&1 | grep "Cipher" | grep -E "DHE|ECDHE")
if [ -n "$FS_CIPHER" ]; then
    echo "  ✓ Forward Secrecy supporté"
else
    echo "  ⚠️  Forward Secrecy non supporté"
fi

echo ""
echo "=== Analyse terminée ==="
echo "Note: Utilisez 'testssl.sh' pour une analyse complète"
```

---

### Partie 3.3 : Outils d'Analyse HTTP/HTTPS

#### Exercice 3.3.1 : curl avancé

```bash
#!/bin/bash
# curl_advanced.sh - Techniques avancées avec curl

URL="https://httpbin.org"

echo "=== CURL AVANCÉ ==="

# 1. Méthodes HTTP
echo -e "\n[1] Différentes méthodes"
curl -X GET $URL/get
curl -X POST $URL/post -d "key=value"
curl -X PUT $URL/put -d "data"
curl -X DELETE $URL/delete
curl -X PATCH $URL/patch -d "update"

# 2. Headers personnalisés
echo -e "\n[2] Headers personnalisés"
curl -H "X-Custom-Header: value" \
     -H "Authorization: Bearer token" \
     $URL/headers

# 3. Cookies
echo -e "\n[3] Cookies"
curl -b "session=abc123" $URL/cookies
curl -c cookies.txt $URL/cookies/set?session=test
curl -b cookies.txt $URL/cookies

# 4. Authentification
echo -e "\n[4] Authentification"
curl -u username:password $URL/basic-auth/username/password
curl -H "Authorization: Bearer token123" $URL/bearer

# 5. Upload de fichier
echo -e "\n[5] Upload fichier"
echo "test data" > test.txt
curl -F "file=@test.txt" $URL/post

# 6. JSON
echo -e "\n[6] JSON"
curl -H "Content-Type: application/json" \
     -d '{"name":"John","age":30}' \
     $URL/post

# 7. Suivre les redirections
echo -e "\n[7] Redirections"
curl -L $URL/redirect/3

# 8. Timeout
echo -e "\n[8] Timeout"
curl --max-time 5 $URL/delay/10

# 9. Proxy
echo -e "\n[9] Proxy (exemple)"
# curl -x http://proxy:8080 $URL/get

# 10. Verbose et debug
echo -e "\n[10] Debug"
curl -v $URL/get 2>&1 | head -30
curl --trace trace.txt $URL/get

# 11. Limitation de bande passante
echo -e "\n[11] Limite bande passante"
curl --limit-rate 100K $URL/stream-bytes/1000000

# 12. User-Agent
echo -e "\n[12] User-Agent"
curl -A "Mozilla/5.0 CustomBot" $URL/user-agent

# 13. Compression
echo -e "\n[13] Compression"
curl --compressed $URL/gzip

# 14. Timing
echo -e "\n[14] Timing détaillé"
curl -w "\nTime: %{time_total}s\nSpeed: %{speed_download} bytes/s\n" \
     -o /dev/null -s $URL/get

# Nettoyer
rm -f test.txt cookies.txt trace.txt

echo -e "\n=== Tests terminés ==="
```

---

#### Exercice 3.3.2 : httpie - Alternative à curl

```bash
# Installation
sudo apt install httpie -y

# Syntaxe plus simple que curl

# GET
http GET https://httpbin.org/get

# POST avec JSON (automatique)
http POST https://httpbin.org/post name=John age:=30

# Headers
http GET https://httpbin.org/headers X-Custom:value

# Authentification
http -a username:password GET https://httpbin.org/basic-auth/username/password

# Upload
http --form POST https://httpbin.org/post file@test.txt

# Download
http --download https://httpbin.org/image/png

# Session
http --session=mysession https://httpbin.org/cookies/set?session=abc
http --session=mysession https://httpbin.org/cookies

# Verbose
http -v GET https://httpbin.org/get
```

---

### 🎯 QUIZ NIVEAU 3

1. Quelles sont les différences entre HTTP/1.1 et HTTP/2 ?
2. Que signifie le code de statut HTTP 301 ? Et 404 ?
3. Quelle est la différence entre SSL et TLS ?
4. Qu'est-ce qu'un certificat auto-signé ?
5. Quelles sont les étapes du TLS handshake ?
6. Pourquoi TLS 1.3 est-il plus rapide que TLS 1.2 ?
7. Que fait le header HTTP "Accept-Encoding" ?
8. Qu'est-ce que HTTPS en réalité (protocoles combinés) ?

**Commandes à mémoriser (Niveau 3) :**
```bash
curl https://example.com                     # Requête HTTPS
curl -I https://example.com                  # Headers seulement
curl -X POST -d "data" https://api.com      # POST request
openssl s_client -connect host:443          # Test SSL
openssl x509 -in cert.crt -text             # Lire certificat
sudo tcpdump -i any 'tcp port 443' -w f.pcap # Capture HTTPS
```

---

<a name="niveau-4"></a>
## 🔴 NIVEAU 4 : SSH (4-5 heures)

### Objectifs
- Maîtriser SSH (Secure Shell)
- Configurer l'authentification par clés
- Utiliser les tunnels SSH
- Sécuriser les connexions SSH

---

### Partie 4.1 : Protocole SSH

#### Exercice 4.1.1 : Architecture SSH

```
=== SSH PROTOCOL LAYERS ===

┌─────────────────────────────────────┐
│  SSH Application Layer              │
│  (scp, sftp, ssh-agent, etc.)       │
├─────────────────────────────────────┤
│  SSH Connection Protocol            │
│  (Channels, X11, port forwarding)   │
├─────────────────────────────────────┤
│  SSH Authentication Protocol        │
│  (Password, Public Key, etc.)       │
├─────────────────────────────────────┤
│  SSH Transport Layer Protocol       │
│  (Encryption, Integrity, Compression)│
├─────────────────────────────────────┤
│  TCP (port 22)                      │
└─────────────────────────────────────┘

=== SSH CONNECTION FLOW ===

Client                          Server
  |                               |
  | TCP Connect (port 22)         |
  |------------------------------>|
  |                               |
  | Version Exchange              |
  |<----------------------------->|
  |                               |
  | Key Exchange (DH)             |
  |<----------------------------->|
  |                               |
  | Authentication                |
  |------------------------------>|
  |                               |
  | Session Requests              |
  |<----------------------------->|
  |                               |
  | Encrypted Channel             |
  |<=============================|
```

---

#### Exercice 4.1.2 : Configuration SSH basique

```bash
# Vérifier que SSH est installé
ssh -V
dpkg -l | grep openssh

# Installer si nécessaire
sudo apt install openssh-server openssh-client -y

# Démarrer le service SSH
sudo systemctl start ssh
sudo systemctl enable ssh

# Vérifier le status
sudo systemctl status ssh

# Vérifier que le port 22 est en écoute
sudo ss -tlpn | grep :22

# Configuration serveur SSH
sudo cat /etc/ssh/sshd_config | grep -v "^#" | grep -v "^$"

# Configuration client SSH
cat ~/.ssh/config 2>/dev/null || echo "Pas de config client"
```

---

#### Exercice 4.1.3 : Connexion SSH basique

```bash
# Se connecter en local (pour test)
ssh localhost

# Se connecter avec un utilisateur spécifique
ssh username@hostname

# Se connecter sur un port différent
ssh -p 2222 username@hostname

# Exécuter une commande à distance
ssh username@hostname "ls -la /tmp"
ssh username@hostname "uname -a"

# Mode verbose (debug)
ssh -v username@hostname
ssh -vv username@hostname  # Plus de détails
ssh -vvv username@hostname # Maximum de détails

# Spécifier l'algorithme de chiffrement
ssh -c aes256-ctr username@hostname

# Désactiver la vérification de host key (à éviter en production!)
ssh -o StrictHostKeyChecking=no username@hostname

# Spécifier l'identité (clé privée)
ssh -i ~/.ssh/my_key username@hostname
```

---

#### Exercice 4.1.4 : Authentification par clés SSH

```bash
#!/bin/bash
# ssh_key_setup.sh - Configuration de l'authentification par clés

echo "=== Configuration authentification SSH par clés ==="

# 1. Générer une paire de clés RSA
echo "[1] Génération de la paire de clés RSA..."
ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa_test -C "test@example.com" -N ""

# 2. Générer une paire de clés Ed25519 (plus moderne)
echo "[2] Génération de la paire de clés Ed25519..."
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519_test -C "test@example.com" -N ""

# 3. Afficher les clés
echo -e "\n[3] Clés générées:"
ls -lh ~/.ssh/id_*test*

# 4. Afficher la clé publique
echo -e "\n[4] Clé publique RSA:"
cat ~/.ssh/id_rsa_test.pub

# 5. Copier la clé sur le serveur (méthode manuelle)
echo -e "\n[5] Pour copier la clé sur un serveur:"
echo "ssh-copy-id -i ~/.ssh/id_rsa_test.pub user@server"

# 6. Ou manuellement
echo -e "\n[6] Ou manuellement:"
echo "cat ~/.ssh/id_rsa_test.pub | ssh user@server 'mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys'"

# 7. Test de connexion locale
echo -e "\n[7] Test connexion locale:"
mkdir -p ~/.ssh
cat ~/.ssh/id_rsa_test.pub >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys

ssh -i ~/.ssh/id_rsa_test -o StrictHostKeyChecking=no localhost "echo 'Connexion SSH par clé réussie!'"

echo -e "\n[✓] Configuration terminée"
```

**Types de clés SSH :**
```bash
# RSA (classique, 2048-4096 bits)
ssh-keygen -t rsa -b 4096

# DSA (déprécié, ne pas utiliser)
# ssh-keygen -t dsa

# ECDSA (courbes elliptiques)
ssh-keygen -t ecdsa -b 521

# Ed25519 (recommandé, moderne, rapide)
ssh-keygen -t ed25519

# Avec passphrase
ssh-keygen -t ed25519 -f ~/.ssh/my_key

# Sans passphrase (automatisation)
ssh-keygen -t ed25519 -f ~/.ssh/my_key -N ""

# Convertir une clé privée au format PEM
ssh-keygen -p -f ~/.ssh/id_rsa -m pem
```

---

#### Exercice 4.1.5 : Configuration avancée SSH

**Fichier ~/.ssh/config :**
```bash
cat << 'EOF' > ~/.ssh/config
# Configuration SSH

# Valeurs par défaut
Host *
    ServerAliveInterval 60
    ServerAliveCountMax 3
    Compression yes
    ForwardAgent no

# Serveur de production
Host prod
    HostName 192.168.1.100
    User admin
    Port 22
    IdentityFile ~/.ssh/id_rsa_prod
    ForwardAgent yes

# Serveur de développement
Host dev
    HostName dev.example.com
    User developer
    Port 2222
    IdentityFile ~/.ssh/id_rsa_dev

# Bastion/Jump host
Host bastion
    HostName bastion.example.com
    User jumpuser
    IdentityFile ~/.ssh/id_rsa_bastion

# Serveur derrière le bastion
Host internal
    HostName 10.0.0.50
    User admin
    ProxyJump bastion
    IdentityFile ~/.ssh/id_rsa_internal

# Localhost avec clé spécifique
Host local-test
    HostName localhost
    User $USER
    IdentityFile ~/.ssh/id_rsa_test
    StrictHostKeyChecking no

# Wildcard pour sous-domaine
Host *.example.com
    User common_user
    IdentityFile ~/.ssh/id_rsa_common
EOF

chmod 600 ~/.ssh/config

# Utilisation
ssh prod      # Se connecte à 192.168.1.100
ssh dev       # Se connecte à dev.example.com:2222
ssh internal  # Passe par le bastion
```

**Configuration serveur SSH (/etc/ssh/sshd_config) :**
```bash
sudo tee /etc/ssh/sshd_config.d/custom.conf << 'EOF'
# Configuration SSH serveur personnalisée

# Port (changer pour plus de sécurité)
Port 22

# Adresses d'écoute
#ListenAddress 0.0.0.0
#ListenAddress ::

# Authentification
PermitRootLogin no                    # Interdire root
PasswordAuthentication yes            # Autoriser mot de passe
PubkeyAuthentication yes              # Autoriser clés publiques
AuthorizedKeysFile .ssh/authorized_keys

# Délais
LoginGraceTime 60
ClientAliveInterval 300
ClientAliveCountMax 2

# Sécurité
PermitEmptyPasswords no
MaxAuthTries 3
MaxSessions 10

# Forwarding
AllowTcpForwarding yes
X11Forwarding no
AllowAgentForwarding yes

# Environnement
PermitUserEnvironment no
AcceptEnv LANG LC_*

# Logging
SyslogFacility AUTH
LogLevel VERBOSE

# Restriction par utilisateur/groupe
#AllowUsers user1 user2
#AllowGroups sshusers
#DenyUsers baduser
#DenyGroups notsshusers
EOF

# Tester la configuration
sudo sshd -t

# Recharger SSH
sudo systemctl reload ssh
```

---

### Partie 4.2 : Tunnels SSH

#### Exercice 4.2.1 : Port Forwarding Local

```bash
# LOCAL PORT FORWARDING
# -L [bind_address:]local_port:remote_host:remote_port

# Exemple 1: Accéder à un service distant via SSH
# Forward local:8080 -> remote:80
ssh -L 8080:localhost:80 user@server

# Maintenant, http://localhost:8080 accède au port 80 du serveur distant

# Exemple 2: Accéder à une base de données distante
ssh -L 3306:localhost:3306 user@dbserver
# Connectez-vous à MySQL sur localhost:3306

# Exemple 3: Multiple forwards
ssh -L 8080:localhost:80 \
    -L 3306:localhost:3306 \
    -L 6379:localhost:6379 \
    user@server

# En arrière-plan
ssh -f -N -L 8080:localhost:80 user@server
# -f : background
# -N : ne pas exécuter de commande

# Exemple pratique complet
cat << 'EOF' > ssh_tunnel_local.sh
#!/bin/bash
# Tunnel SSH local pour accéder à un service web distant

SERVER="user@remote-server"
LOCAL_PORT=8080
REMOTE_PORT=80

echo "Création tunnel SSH local..."
echo "Local: http://localhost:$LOCAL_PORT -> Remote: $REMOTE_PORT"

ssh -f -N -L ${LOCAL_PORT}:localhost:${REMOTE_PORT} ${SERVER}

if [ $? -eq 0 ]; then
    echo "✓ Tunnel créé"
    echo "Accédez au service via http://localhost:$LOCAL_PORT"
    echo ""
    echo "Pour fermer le tunnel:"
    echo "pkill -f 'ssh.*-L ${LOCAL_PORT}'"
else
    echo "✗ Erreur lors de la création du tunnel"
fi
EOF

chmod +x ssh_tunnel_local.sh
```

---

#### Exercice 4.2.2 : Port Forwarding Remote

```bash
# REMOTE PORT FORWARDING
# -R [bind_address:]remote_port:local_host:local_port

# Exemple: Exposer un service local à un serveur distant
# Le serveur distant peut accéder à votre localhost:80 via son port 8080
ssh -R 8080:localhost:80 user@server

# Cas d'usage: Développement web
# Vous développez en local (port 3000), le serveur distant peut y accéder
ssh -R 8080:localhost:3000 user@server

# En arrière-plan
ssh -f -N -R 8080:localhost:3000 user@server

# Exemple pratique
cat << 'EOF' > ssh_tunnel_remote.sh
#!/bin/bash
# Tunnel SSH remote pour exposer un service local

SERVER="user@remote-server"
REMOTE_PORT=8080
LOCAL_PORT=3000

echo "Création tunnel SSH remote..."
echo "Remote:$REMOTE_PORT -> Local: http://localhost:$LOCAL_PORT"

ssh -f -N -R ${REMOTE_PORT}:localhost:${LOCAL_PORT} ${SERVER}

if [ $? -eq 0 ]; then
    echo "✓ Tunnel créé"
    echo "Le serveur distant peut accéder à votre service via :$REMOTE_PORT"
else
    echo "✗ Erreur"
fi
EOF

chmod +x ssh_tunnel_remote.sh
```

---

#### Exercice 4.2.3 : Dynamic Port Forwarding (SOCKS Proxy)

```bash
# DYNAMIC PORT FORWARDING
# -D [bind_address:]port

# Créer un proxy SOCKS5
ssh -D 1080 user@server

# Maintenant, configurez vos applications pour utiliser SOCKS5 proxy:
# localhost:1080

# En arrière-plan
ssh -f -N -D 1080 user@server

# Utiliser avec curl
curl --socks5 localhost:1080 http://example.com

# Utiliser avec Firefox
# Préférences -> Réseau -> Paramètres de connexion
# SOCKS5: localhost:1080

# Script complet
cat << 'EOF' > ssh_socks_proxy.sh
#!/bin/bash
# Créer un proxy SOCKS5 via SSH

SERVER="user@remote-server"
SOCKS_PORT=1080

echo "Création proxy SOCKS5..."

ssh -f -N -D ${SOCKS_PORT} ${SERVER}

if [ $? -eq 0 ]; then
    echo "✓ Proxy SOCKS5 actif sur localhost:$SOCKS_PORT"
    echo ""
    echo "Configuration:"
    echo "  Type: SOCKS5"
    echo "  Host: localhost"
    echo "  Port: $SOCKS_PORT"
    echo ""
    echo "Test avec curl:"
    echo "  curl --socks5 localhost:$SOCKS_PORT http://ifconfig.me"
    echo ""
    echo "Pour fermer:"
    echo "  pkill -f 'ssh.*-D ${SOCKS_PORT}'"
else
    echo "✗ Erreur"
fi
EOF

chmod +x ssh_socks_proxy.sh

# Utilisation avancée avec proxychains
sudo apt install proxychains4 -y

# Configurer proxychains
sudo tee /etc/proxychains4.conf << 'CONFIG'
strict_chain
proxy_dns
remote_dns_subnet 224
tcp_read_time_out 15000
tcp_connect_time_out 8000

[ProxyList]
socks5  127.0.0.1 1080
CONFIG

# Maintenant, utilisez proxychains avec n'importe quelle commande
proxychains curl http://ifconfig.me
proxychains wget http://example.com
proxychains nmap -sT target.com
```

---

#### Exercice 4.2.4 : Jump Host / Bastion

```bash
# JUMP HOST (ProxyJump)

# Méthode 1: Option -J
ssh -J bastion-host target-host

# Méthode 2: Multiple jumps
ssh -J jump1,jump2,jump3 target-host

# Méthode 3: ProxyCommand (ancienne méthode)
ssh -o ProxyCommand="ssh -W %h:%p bastion-host" target-host

# Configuration dans ~/.ssh/config
cat << 'EOF' >> ~/.ssh/config

# Bastion host
Host bastion
    HostName bastion.example.com
    User jumpuser
    IdentityFile ~/.ssh/id_rsa_bastion

# Serveur interne accessible via bastion
Host internal-server
    HostName 10.0.0.100
    User admin
    ProxyJump bastion
    IdentityFile ~/.ssh/id_rsa_internal

# Ou avec ProxyCommand
Host internal-server2
    HostName 10.0.0.101
    User admin
    ProxyCommand ssh -W %h:%p bastion
    IdentityFile ~/.ssh/id_rsa_internal
EOF

# Utilisation
ssh internal-server  # Passe automatiquement par le bastion

# Copie de fichiers via bastion
scp -o ProxyJump=bastion file.txt internal-server:/tmp/
```

---

### Partie 4.3 : Sécurisation SSH

#### Exercice 4.3.1 : Durcissement de la configuration

```bash
#!/bin/bash
# ssh_hardening.sh - Durcir la configuration SSH

echo "=== Durcissement SSH ==="

# Backup de la config actuelle
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup.$(date +%Y%m%d)

# Configuration durcie
sudo tee /etc/ssh/sshd_config.d/hardening.conf << 'EOF'
# === SSH Hardening Configuration ===

# 1. Changer le port par défaut (security by obscurity)
#Port 2222

# 2. Limiter les utilisateurs
#AllowUsers user1 user2
#AllowGroups sshusers

# 3. Désactiver root login
PermitRootLogin no

# 4. Désactiver l'authentification par mot de passe
#PasswordAuthentication no
#ChallengeResponseAuthentication no
#UsePAM no

# 5. Forcer l'authentification par clé
PubkeyAuthentication yes

# 6. Désactiver les mots de passe vides
PermitEmptyPasswords no

# 7. Limiter les tentatives d'authentification
MaxAuthTries 3
MaxSessions 2

# 8. Timeout de connexion
LoginGraceTime 30
ClientAliveInterval 300
ClientAliveCountMax 2

# 9. Désactiver les fonctionnalités non nécessaires
X11Forwarding no
PermitUserEnvironment no
PermitTunnel no

# 10. Protocole SSH v2 uniquement (défaut dans les versions récentes)
#Protocol 2

# 11. Algorithmes cryptographiques forts
# Ciphers
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr

# MACs
MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256

# Key Exchange Algorithms
KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group-exchange-sha256

# Host Key Algorithms
HostKeyAlgorithms ssh-ed25519,rsa-sha2-512,rsa-sha2-256

# 12. Logging verbeux
LogLevel VERBOSE

# 13. Banner
Banner /etc/ssh/banner.txt
EOF

# Créer un banner
sudo tee /etc/ssh/banner.txt << 'BANNER'
***************************************************************************
                     AUTHORIZED ACCESS ONLY
***************************************************************************
This system is for authorized use only. All activity is logged and
monitored. Unauthorized access is strictly prohibited.
***************************************************************************
BANNER

# Tester la configuration
echo ""
echo "Test de la configuration..."
sudo sshd -t

if [ $? -eq 0 ]; then
    echo "✓ Configuration valide"
    echo ""
    echo "Pour appliquer les changements:"
    echo "  sudo systemctl reload ssh"
else
    echo "✗ Erreur dans la configuration"
fi

echo ""
echo "Configuration sauvegardée dans: /etc/ssh/sshd_config.backup.$(date +%Y%m%d)"
```

---

#### Exercice 4.3.2 : fail2ban pour SSH

```bash
# Installation de fail2ban
sudo apt install fail2ban -y

# Configuration pour SSH
sudo tee /etc/fail2ban/jail.d/sshd.conf << 'EOF'
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600
findtime = 600
EOF

# Démarrer fail2ban
sudo systemctl restart fail2ban
sudo systemctl enable fail2ban

# Vérifier le status
sudo fail2ban-client status
sudo fail2ban-client status sshd

# Voir les IPs bannies
sudo fail2ban-client get sshd banned

# Débannir une IP
# sudo fail2ban-client set sshd unbanip <IP>
```

---

#### Exercice 4.3.3 : Surveillance SSH

```bash
#!/bin/bash
# ssh_monitoring.sh - Monitorer les connexions SSH

echo "=== Surveillance SSH ==="

# 1. Connexions actives
echo "[1] Connexions SSH actives:"
who | grep pts

# 2. Historique des connexions
echo -e "\n[2] Dernières connexions:"
last -a | head -20

# 3. Tentatives de connexion échouées
echo -e "\n[3] Tentatives échouées récentes:"
sudo grep "Failed password" /var/log/auth.log | tail -10

# 4. Connexions réussies
echo -e "\n[4] Connexions réussies récentes:"
sudo grep "Accepted publickey\|Accepted password" /var/log/auth.log | tail -10

# 5. IPs se connectant
echo -e "\n[5] Top IPs se connectant:"
sudo grep "sshd" /var/log/auth.log | grep -oP 'from \K[0-9.]+' | sort | uniq -c | sort -rn | head -10

# 6. Utilisateurs se connectant
echo -e "\n[6] Top utilisateurs:"
sudo grep "Accepted" /var/log/auth.log | grep -oP 'for \K\w+' | sort | uniq -c | sort -rn

# 7. Sessions actives détaillées
echo -e "\n[7] Sessions actives détaillées:"
ss -tnp | grep :22

# Monitoring en temps réel
echo -e "\n[8] Surveillance en temps réel (Ctrl+C pour arrêter):"
# sudo tail -f /var/log/auth.log | grep sshd
```

---

### Partie 4.4 : Outils SSH Avancés

#### Exercice 4.4.1 : scp - Copie sécurisée

```bash
# SCP - Secure Copy

# Copier un fichier local vers distant
scp file.txt user@server:/path/to/destination/

# Copier un fichier distant vers local
scp user@server:/path/to/file.txt ./

# Copier un répertoire (récursif)
scp -r /local/directory user@server:/remote/path/

# Avec port personnalisé
scp -P 2222 file.txt user@server:/path/

# Avec compression
scp -C large_file.txt user@server:/path/

# Limiter la bande passante (Ko/s)
scp -l 1000 file.txt user@server:/path/

# Préserver les attributs
scp -p file.txt user@server:/path/

# Verbose
scp -v file.txt user@server:/path/

# Via jump host
scp -o ProxyJump=bastion file.txt internal-server:/path/

# Multiple fichiers
scp file1.txt file2.txt user@server:/path/

# Wildcard
scp *.txt user@server:/path/

# Entre deux serveurs distants
scp user1@server1:/path/file.txt user2@server2:/path/
```

---

#### Exercice 4.4.2 : sftp - FTP sécurisé

```bash
# SFTP - Secure FTP

# Connexion interactive
sftp user@server

# Commandes dans sftp:
# ls          - Lister fichiers distants
# lls         - Lister fichiers locaux
# cd          - Changer répertoire distant
# lcd         - Changer répertoire local
# pwd         - Répertoire distant actuel
# lpwd        - Répertoire local actuel
# get         - Télécharger
# put         - Uploader
# mget        - Télécharger multiple
# mput        - Uploader multiple
# mkdir       - Créer répertoire distant
# rmdir       - Supprimer répertoire distant
# rm          - Supprimer fichier distant
# chmod       - Changer permissions
# exit        - Quitter

# Batch mode (script)
cat << 'EOF' > sftp_script.txt
cd /remote/path
lcd /local/path
put file.txt
get remote_file.txt
bye
EOF

sftp -b sftp_script.txt user@server

# One-liner
echo "get /remote/file.txt" | sftp user@server

# Non-interactif avec sshpass (si mot de passe nécessaire)
# sudo apt install sshpass
# sshpass -p 'password' sftp user@server << EOF
# get /remote/file.txt
# bye
# EOF
```

---

#### Exercice 4.4.3 : rsync via SSH

```bash
# RSYNC - Synchronisation efficace via SSH

# Syntaxe de base
rsync -avz /local/path/ user@server:/remote/path/

# Options importantes:
# -a : archive mode (préserve permissions, timestamps, etc.)
# -v : verbose
# -z : compression
# -h : human-readable
# -P : progress + partial (reprendre transferts interrompus)
# -r : récursif
# -n : dry-run (simulation)
# --delete : supprimer fichiers n'existant plus dans source

# Exemples pratiques

# 1. Synchroniser un répertoire
rsync -avzh --progress /local/dir/ user@server:/remote/dir/

# 2. Avec suppression des fichiers supprimés
rsync -avzh --delete /local/dir/ user@server:/remote/dir/

# 3. Exclure certains fichiers
rsync -avzh --exclude '*.log' --exclude 'temp/' /local/ user@server:/remote/

# 4. Dry-run (test)
rsync -avzhn /local/ user@server:/remote/

# 5. Limiter la bande passante (Ko/s)
rsync -avzh --bwlimit=1000 /local/ user@server:/remote/

# 6. Via SSH sur port personnalisé
rsync -avzh -e "ssh -p 2222" /local/ user@server:/remote/

# 7. Via jump host
rsync -avzh -e "ssh -J bastion" /local/ internal:/remote/

# 8. Synchroniser depuis distant vers local
rsync -avzh user@server:/remote/ /local/

# 9. Backup incrémental
rsync -avzh --backup --backup-dir=/backup/$(date +%Y%m%d) \
    /source/ /destination/

# 10. Statistiques détaillées
rsync -avzh --stats /local/ user@server:/remote/

# Script de backup automatique
cat << 'EOF' > rsync_backup.sh
#!/bin/bash
# Script de backup avec rsync

SOURCE="/data/"
DEST="user@backup-server:/backups/$(hostname)/"
LOG="/var/log/rsync_backup.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

echo "[$DATE] Début backup" >> $LOG

rsync -avzh --delete \
    --exclude 'cache/' \
    --exclude '*.tmp' \
    --log-file=$LOG \
    $SOURCE $DEST

if [ $? -eq 0 ]; then
    echo "[$DATE] Backup réussi" >> $LOG
else
    echo "[$DATE] Backup échoué" >> $LOG
fi
EOF

chmod +x rsync_backup.sh

# Ajouter au cron pour backup automatique
# crontab -e
# 0 2 * * * /path/to/rsync_backup.sh
```

---

#### Exercice 4.4.4 : ssh-agent - Gestion des clés

```bash
# SSH-AGENT - Gérer les clés en mémoire

# Démarrer ssh-agent
eval $(ssh-agent)

# Ajouter une clé
ssh-add ~/.ssh/id_rsa

# Ajouter avec timeout (secondes)
ssh-add -t 3600 ~/.ssh/id_rsa  # Expire après 1 heure

# Lister les clés chargées
ssh-add -l

# Supprimer une clé
ssh-add -d ~/.ssh/id_rsa

# Supprimer toutes les clés
ssh-add -D

# Tester l'agent
ssh-add -l

# Script de démarrage automatique
cat << 'EOF' >> ~/.bashrc

# SSH Agent
if [ -z "$SSH_AUTH_SOCK" ]; then
    eval $(ssh-agent -s) > /dev/null
    ssh-add ~/.ssh/id_rsa 2>/dev/null
fi
EOF

# ForwardAgent (utiliser l'agent sur serveur distant)
# Dans ~/.ssh/config:
# Host server
#     ForwardAgent yes

# Ou en ligne de commande
ssh -A user@server
```

---

### 🎯 QUIZ NIVEAU 4

1. Quelle est la différence entre authentification par mot de passe et par clé ?
2. Comment fonctionne un tunnel SSH local (-L) ?
3. Quelle est la différence entre scp et rsync ?
4. Que fait la commande `ssh -D` ?
5. Pourquoi désactiver PermitRootLogin ?
6. Qu'est-ce qu'un jump host / bastion ?
7. Comment fail2ban protège-t-il SSH ?
8. Quelle est la différence entre port 22 et un port personnalisé ?

**Commandes à mémoriser (Niveau 4) :**
```bash
ssh user@host                              # Connexion SSH
ssh-keygen -t ed25519                     # Générer clé
ssh-copy-id user@host                     # Copier clé publique
ssh -L 8080:localhost:80 user@host        # Tunnel local
ssh -R 8080:localhost:80 user@host        # Tunnel remote
ssh -D 1080 user@host                     # Proxy SOCKS
scp file.txt user@host:/path/             # Copie sécurisée
rsync -avz /local/ user@host:/remote/     # Synchro
```

---

**[CONTINUE DANS LE PROCHAIN MESSAGE AVEC NIVEAU 5 ET PROJET FINAL...]**

Le fichier est maintenant à ~17000 lignes ! Voulez-vous que je termine avec le Niveau 5 (Analyse Avancée) et le Projet Final ?
